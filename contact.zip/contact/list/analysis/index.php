<?php
session_start();
require("../../confige/fileconfige.php");


$lst_name=$_SESSION['listname'];

$lst_dis_name=base64_decode(explode("^", $lst_name)[1]);



    $mail=$_SESSION["email"];
    $id=$_SESSION["id"];



?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet"> 
<link href='https://fonts.googleapis.com/css?family=Karla:700' rel='stylesheet' type='text/css'>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

<style>

@import url(https://fonts.googleapis.com/css?family=Arvo);
@import url(http://fonts.googleapis.com/css?family=Varela+Round);
.tablediv{
    padding:10%;
}
tr{

border:1px solid #dedddc;
}


.con-of-tbl{
background:white;
border-radius:4px;
}

.col-header th{
padding-top:1rem !important;
padding-bottom:1rem !important;
}
.col-header{


color: white;
    font-size: 20px !important;
    background: darkcyan;
    font-weight: 700 !important;


}
.first-col{

display: block;
    
    width: 95%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

body{




webkit-font-smoothing: antialiased;}
.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{

border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#007c89;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;
    cursor:pointer;

}
.card:hover{
    cursor:default;
}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}


























.head-dash{
  font-family: 'Karla', sans-serif;
  font-size: 23px;
  color: #000000e0;
  width:50%;
}
body{
  
}

.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}

.row{
  width:100%;
  margin-left:0px;
  margin-right: 0px;
}
.head-con-rw{
  padding-top: 20px;
  padding-bottom: 20px;
}
.btn-con-top{
  width: 50%;
}

.bottom-btn:hover{
  cursor: pointer;
}







body{




webkit-font-smoothing: antialiased;}
.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{
border-radius:4px;
border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#085861;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}








.con-of-dash-data{
  width:25%;
  margin: 0px auto;


}
.con-ch-dast-data{
text-align: center;
  border-radius: 5px;
  background:white;
  margin: 20px;

}

.icon-data-con{

  padding-top: 20px;
    padding-bottom: 20px;
}



.ico-fa-data{

  display: table-cell;
  vertical-align: middle;

    font-size: 30px;

    height: 60px;
    width:60px;
}




.con-ico-data{


    width: fit-content;
    margin: 0px auto;
    border-radius: 50%;
    height: 60px;
    width:60px;
}

.data-info-text{
  color: black;
  font-size: 37px;
  font-weight: bolder;
  padding-top: 10px;
    padding-bottom: 10px;
}

.data-head-line{
  padding-top: 10px;
    padding-bottom: 20px;
  color: #04040485;
    font-weight: 600;
}


.head-of-over{
  font-family: 'Karla', sans-serif;
  font-size: 20px;
  color: #000000e0;
  padding-top: 20px;
}



.table{
margin-bottom:0px;
}











.data-tbl-db{
 
  background: white;
  border-radius: 5px;
  
}

.data-belo-line{

    width: 500px;
    overflow: scroll;
    font-weight: 600;
    color: #0000006b;
}

.tbl-main-head{
  color: #000000cc;
    font-weight: bolder;
width: 200px;
    overflow-x: scroll;
}
.tbl-main-head::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE and Edge */
.tbl-main-head {
  -ms-overflow-style: none;
}

.tbl-link-clr{
  color: blue;
transition:.2s;



}


.tbl-link-clr:hover{
color:black;

}











.not-fd-data{
  text-align: center;
background:white;
border-radius:4px;

padding:20px;





}








.txt-not-fd{
  padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
}

















@import url(https://fonts.googleapis.com/css?family=Josefin+Sans);


.nav-link:hover{
    cursor:pointer;
}

ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;

}
.addsiteheadbtn:hover{
    color:black;
    cursor:pointer;
    background:#d9d7cd;

}


td{
vertical-align: middle;

}

html{
background;#f0f8ffcf;
}

#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
.con-of-tbl{
background:white;
border-radius:4px;
}
















button.btn_hover_clr {
   

        background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    color: #1a73e8;
    font-size: 13px;
    font-weight: 500;
    background: white;
  }

  

button.btn_hover_clr:hover {
    background: #e8f0fe;
    cursor: pointer;
  }



.table td, .table th {
    font-size: 16px;
    white-space: nowrap;

  }












.tooltip2 .tooltiptext {
    visibility: hidden;
    width: 120px;
    font-size: 13px;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;
    position: absolute;
    z-index: 1;
    margin-left: -60px;
    margin-top: 20px;
    font-family: 'IBM Plex Sans', sans-serif;
    font-weight: 500;
  }
.tooltip2:hover .tooltiptext {
  visibility: visible;
}











.lds-color div{

border: 2px solid #4a154bd9;border-color: #4a154bd9 transparent transparent transparent !important;

}


.lds-pos-cht{

  top: 50%;
  left: 50%;
}

.lds-pos-bg{
top: 50%;

}

.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid white;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

.lds-large div{
  width: 40px;
  height: 40px;
  border: 4px solid;

}



.lds-large {
    margin: auto;
    
    width: 40px;
    height: 40px;

  }

.main-content {
  height: 92vh;
  overflow: scroll;
}

   .lds-main-large{
top: 300px;
    left: 50%;

  }







i:hover{

  cursor: pointer;

}






.card{
  height: min-content;
  width: 49%;
  border: 1px solid rgb(0 0 0 / 18%);

  
}

.head-cons-desg{
  padding: 50px 0px;
}

.card-img-top{

    padding: 40px;


}

.card-body{
  text-align: center;
}

.card-text{
  font-weight: 500;
  color: black;
}

.card-title {
    margin-bottom: 1.25rem;
    font-size: 20px;
color: black;
    }

    a.crt-api-btn {
    color: #3368fa;
    background-color: #fff;
    border-color: #3368fa;
    font-family: Colfax-Bold,Helvetica,Arial,sans-serif;
    font-style: normal;
    font-weight: 600;
    display: inline-block;
    padding: 12px 32px;
    font-size: 16px;
    line-height: normal;
    text-align: center;
    border: 2px solid transparent;
    border-radius: 3px;
    outline: 0;
    box-shadow: 0 2px 4px 0 #c8d7ee;
    transition: all .2s ease-in-out;
    border: 2px solid;

  }



.container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 30px 36px;
    border-bottom: 1px solid #dedddc;
  }

.container-2GnNH span{

font-size: 13px;

}





.header-6RFqy, .wink .header-6RFqy {
    padding: 36px;
    border-bottom: 1px solid #dedddc;


}

.row-2bcC_, .wink .row-2bcC_ {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    margin-bottom: 10px;

    }

    .title-2V2Vk, .wink .title-2V2Vk {
    margin-bottom: 0px;
    color: black;
  }

.byline-1jw7n, .wink .byline-1jw7n {
    -webkit-box-flex: 1;
    -ms-flex: 1 0 0px;
    flex: 1 0 0%;
    color: rgba(36,28,21,.65);
    margin-bottom: 0;
    font-size: 15px;
    padding-right: 20px;
        font-weight: 400;

    }

    .outerContainer-2q3dI, .wink .outerContainer-2q3dI {
    padding: 36px;
    border-bottom: 1px solid #dedddc;

}

.emptyState-3H_ct, .wink .emptyState-3H_ct {
    font-size: 2rem;
    padding-bottom: 24px;
    }

    .container-VHfjh, .wink .container-VHfjh {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: end;
    -ms-flex-align: end;
    align-items: flex-end;
}

.countHeader-oIFUQ, .wink .countHeader-oIFUQ {
    font-weight: 500;
    margin-bottom: 6px;
    font-size: 30px;

    }

    .inactiveCountHeader-2Sfab, .wink .inactiveCountHeader-2Sfab {
    font-weight: 500;
    color: rgba(36,28,21,.65);
}

.dateLabel-8C5Mp, .wink .dateLabel-8C5Mp {
    margin-top: 12px;
    margin-bottom: 0;
    font-size: 13px;
    }
    .statisticsListContainer-2apDH, .wink .statisticsListContainer-2apDH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-flex: 1;
    -ms-flex: 1;
    flex: 1 1 0%;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: end;
    -ms-flex-pack: end;
    justify-content: flex-end;
}

.statisticContainer-HQvNi, .wink .statisticContainer-HQvNi {
    margin-left: 36px;
    }


    .ico-card-head{
      font-size: 30px;
    margin-right: 20px;
    color: #4a154bfa;
    }

.circle_othe_inst_ico{
  font-size: 30px !important;
  color: black;
  margin-right: 20px;
}


span.tag-name-dis {
    font-size: 20px;
    color: black;
    font-weight: 500;

  }

  .all-tag-cnt-dsg{
    max-height: 400px;
    overflow: scroll;
  }

  .marg-bot{
    margin-bottom: 20px;
  }

  span.had-ln-dt {
    color: #241c15;
    font-size: 15px;
    font-weight: 600;

  }

  img.img-loc-thumb {
    width: 60px;
    margin-right: 20px;
    border-radius: 50%;

  }

  .chrt_dsg{
    max-width: 100%;
    padding: 20px;
  }
  .chrt_con_main{
    width: 49%;
    display: inline-block;

  }

  .chrt_dsg_bar{
    padding: 40px;
  }


  .card-init-count {
    width: 33%;
    display: inline-block !important;
    padding: 10px;
    text-align: center;

  }

  .coun_con {
    font-size: 24px;
    color: black;
    font-weight: 500;

  }

  .count_type {
    font-size: 13px;
    color: #241c15;
    padding: 10px 0px;

  }




#main-loader-containre-act{


    text-align: none !important;
    
  }

.main-loader-containre-act{
  text-align: center !important;padding-top: 41vh;height: 84vh;
}

button.btn_of_act {
    background: #540a47;
    font-size: 13px;
    border-radius: 5px;
    color: white;
    padding: 5px 15px;
    border: none;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    margin-right: 20px;
}







body{
  font-family: 'lato';
letter-spacing:0.2px;
}




  .dropdown-menu{
    border-radius:0px !important;
    box-shadow:none !important;

    border:1px solid #dedddc !important;

}

.nav-link:hover{
    cursor:pointer;
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}

.main-content {
    position: relative;
    top: 8vh;
}

a{
    font-weight:600;
}
  .navbar-light .navbar-brand {
    color: white;

  }


.dropdown-menu .dropdown-item>i, .dropdown-menu .dropdown-item>svg {
    margin-right: 1rem;

}

  .navbar-light .navbar-brand:hover, .navbar-light .navbar-brand:focus {
    color: white;

    }
  .navbar {
    background: #4a154b;
}



.navbar-light .navbar-nav .nav-link {
    color: white !important;
    font-size:0.9rem !important;
    font-weight: 600;

padding: 20px 10px !important;
}

.dropdown-menu.show {
    border-radius: 10px !important;

}



.navbar-light .navbar-nav .nav-link:hover, .navbar-light .navbar-nav .nav-link:focus {
    color: white;

}


.navbar-light .navbar-nav .show>.nav-link, .navbar-light .navbar-nav .active>.nav-link, .navbar-light .navbar-nav .nav-link.show, .navbar-light .navbar-nav .nav-link.active {
    color: white;
}
.modal{

background: #00000070;

}

.c-slacklogo{display:flex;align-items:center;padding: 0px 20px;}
.c-slacklogo a{line-height:inherit;display:inline-block;font-size:0;padding:0;border:none}
.c-slacklogo img{vertical-align:top}
.c-slacklogo--white{display:none}
.c-slacklogo--color{display:inline-block}
@media screen and (min-width:67.8125rem){.is-clear:not(.is-fixed) .c-slacklogo .c-slacklogo--white{display:inline-block}
.is-clear:not(.is-fixed) .c-slacklogo .c-slacklogo--color{display:none}
}
.c-slacklogo--pillow{width:auto;fill:#fff}
.c-slacklogo.v-frontiers{width:205px;z-index:1}
.c-nav__mobile .c-slacklogo.v-frontiers svg{margin-left:1rem}

.lgs-txt {
    font-size: 25px;
    padding-left: 10px;
    font-weight: 600;
    color: white;
}

span.spn-ln-lg {
    padding: 2px;
    font-weight: 100;
    font-size: 30px;
    }


 sub {
    font-weight: 500;
}


.navbar-light .navbar-nav .nav-link {
    color: white !important;
    font-size: 2vh;
    font-weight: 600;
    padding: 2.5vh 10px !important;
  }


.dropdown-menu .dropdown-item {
    padding: .5rem 1rem;
    font-size: 13px;
    font-weight: 600;

    }

    button.dropdown-item.comm_up_btn:hover {
    background: #0d66d6;
    color: white;
  }

  .dropdown-caret {
    display: inline-block;
    width: 0;
    height: 0;
    vertical-align: middle;
    content: "";
    border-top-style: solid;
    border-top-width: 4px;
    border-right: 4px solid transparent;
    border-bottom: 0 solid transparent;
    border-left: 4px solid transparent;

  }

  #main-loader-containre-act{


    text-align: center;
    padding-top: 41vh;
  }

.main-loader-containre-act{
  text-align: center;padding-top: 41vh;height: 84vh;
}













button.btn-of-new-obj-crt {
    background: #4a154b;
    color: white;
    border-radius: 10px;
    padding: 10px 20px;
    border: none;
    font-size: 11px;
    font-weight: 800;
    box-shadow: #4a154b82 0px 13px 27px -5px, #4a154b75 0px 8px 16px -8px;
    transition: .5s;
}


.row.head-con-rw {
    margin: 20px 0px;
    border-radius: 10px;
    padding: 20px;
    font-family: lato;
    width: 100%;
}


button.btn-of-new-obj-crt:hover{
cursor:pointer;
box-shadow:none;
}

.row.head-con-rw.color-box-desg {
    background: no-repeat;
    background: #154b3d;
    color: white !important;

}



 @media only screen and (max-width: 480px) {


.navbar {
    height: auto !important;
    background: #4a154b;
}


}


@media (min-width: 320px) and (max-width: 480px) {



.navbar {
    height: auto !important;
    background: #4a154b;
}


}






[data-popper-placement="right"]>.tooltip-arrow{

transform: none !important;
    top: 8px !important;

}
.main-con-of-crm.dsc-inln-flx {
    width: 92%;
    height: 100vh;
    float: right;
    background: #fafafa;
    overflow: scroll;
}

    .dsc-inln-flx {
    display: inline-block;
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

    .icon-con-of-sd {
    height: 90vh;
    width: 100%;
}

.icon-main-con {
    height: auto;
    width: 100%;
    position: relative;
    top: 50%;
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    }

    .con-ico {
    padding: 20px;
    text-align: center;
}

img.con-of-ico-img {
    height: 30px;
    }




.con-of-main-splt {
    width: 20%;
    height: 100vh;
    display: inline-block;

}
.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

   
h2.head-od-dt-shw {
    margin: 0px;
    }


button.btn-of-drk-back {
    height: 6vh;
    width: 100%;
    background: #125ef6;
    border: 0px;
    border-radius: 5px;
    color: white;
}

.con-of-dt-sel-ele {
    height: 80vh;
    width: 100%;
    overflow: scroll;
    }

    
a.com-for-lnk {
    text-decoration: none;
    color: black;
    }

    h2.head-od-dt-shw {
    margin: 0px;
    font-family: lato;
    font-size: 15px;
    font-weight: bolder;
}
.con-of-main-splt {
    width: 20%;
    height: 100vh;
    background: #e5eafc30;
    }


    .eml-add-main-con {
    width: 29%;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    font-size: 16px;
    
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }
    input.srch-ip-fld {
    width: 100%;
    height: 3vh;
    border: none;
    font-family: 'Lato';
    font-weight: 500;
    color: #c7ccd7;
}
.con-of-full-email-dt {
    width: 100%;
    height: 90vh;
    }
h3.title-2V2Vk {
    font-size: 15px;
}
    .img-eml-ico-con {
    font-family: 'Lato';
    padding: 15px;
    border-radius: 50%;
    background: pink;
    margin-right: 10px;
    color: #ca1938;
}
.sub-ln-of-email-txt {
    width: 240px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-family: 'Lato';
    color: #908c8c;
    font-size: 13px;
}
input.srch-ip-fld:focus{
    outline: none;
    border: none;
}

    .fnt-ico-sel {
    width: 20px;
    text-align: center;
}

.con-of-cht-usr {
    width: 50%;
    display: inline-block;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    border-left: 1px solid #f2f2f2;
    }





.con-ico:hover{
    cursor: pointer;
}

.head-of-dash{
    background: #4a154b;
    text-align: right;
    border-bottom-left-radius: 50px;
}


.dropdown-menu .dropdown-item {
    padding: .5rem 1rem;
    font-size: 13px;
    font-weight: 600;
}

button.dropdown-item.comm_up_btn:hover {
    background: #0d66d6;
    color: white;
    }

    .dropdown-header {
    padding: .5rem 1rem;
    color: #f6f9fc;
    font-size: .625rem;
    text-transform: uppercase;
    font-weight: 700;
}
.dropdown-header {
    display: block;
    padding: .5rem 1rem;
    margin-bottom: 0;
    font-size: 0.875rem;
    color: #8898aa;
    white-space: nowrap;
    }
    .dropdown-menu {
    padding: 10px !important;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px !important;
}

.dropdown-item {
    border-radius: 10px;
    }

h6, .h6 {
    font-size: 0.625rem !important;
}


.head-of-inn-con {
    padding: 24px;
}
.all-auta-con {
    padding: 0px 24px;
    }
    span.nm-auta-con {
    font-size: 16px;
    font-weight: 500;
    font-family: 'lato';
    color: #00000080;
}

.crt-new-auta-con {
    width: 200px;
    background: rgb(143 4 175);
    padding: 24px 16px;
    border-radius: 10px;
    height: 200px;
    margin-right: 30px;
    margin-top: 20px;
   
    margin-left: 20px;
}

    .new-crt-head {
    line-height: 28px;
    font-weight: 700;
    color: white;
    font-family: 'Lato';
}
.con-of-crt-new-img {
    text-align: center;
    width: min-content;
    margin-top: 60px;
    padding: 10px;
    margin-left: auto;
    margin-right: auto;
    border-radius: 50%;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
    }

    .crt-new-auta-con:hover{
cursor: pointer;
    }

   .auta-dis-on-dash {
    width: 200px;
    padding: 24px 16px;
    border-radius: 10px;
    background: white;
    margin-right: 30px;
    height: 200px;
    padding-bottom: 0px;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px;
    
    margin-top: 20px;
   margin-left: 20px;    
}

.auta-dis-on-dash:hover{
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
cursor: pointer;

}
.main-con-name {
    flex: auto;
    min-height: 116px;
    display: inline-grid;
    width: 100%;
}
    
    span.bdg-tp-btn {
    margin-left: auto;
    font-size: 12px;
    background: rgb(245, 249, 248);
    padding: 2px 10px;
    border-radius: 10px;
    color: rgb(2, 80, 65);
    font-family: 'Lato';
    font-weight: 600;
    letter-spacing: .4px;
    height: fit-content;
}
.def-name-con-crd {
    display: inline-flex;

}
.ico-of-act-lst {
    width: 40%;
    margin: auto;
    text-align: center;
    padding: 10px;
    width: fit-content;
    border-radius: 10px;
    background: #f2f2f2;
    transition:.4s;
    }

    img.ico-img-src {
    height: 25px;
}
    .def_stat-of-dt {
    padding: 16px 0px;
    display: inline-flex;
    width: 100%;
    height: 60px;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    
}
    .con-of-cnt-data {
    padding: 5.5px 10px;
    background: rgba(0, 0, 0, 0.07);
    border-radius: 5px;
    color: rgb(38, 38, 39);
    width: 60%;
    text-align: center;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    }

    .con-of-dp-data {
    width: 40%;
}

button#dropdownMenuButton {
    background: no-repeat;
    border: none;
    height: 32px;
    padding: 5.5px;
    float: right;
    }

.all-auta-con {
    padding: 0px 24px;
    display: inline-flex;

}
.dropdown-toggle::after{
    display: none;
}

.dropdown-menu.show{
    border: none;
    border-radius: 10px;
}

a.com-for-lnk {
    text-decoration: none;
    color: #00000091;
    }
    .marg-for-temp{
        margin-left: 0px;
        margin-right: 30px;
    }
    .img-temp-of-mark{
        width: 168px;
        height: 166px;
    }










  .ip-by-def-dsg {
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;


  }

  .ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #524d52;
    box-shadow: 0 0 0 3px #bdb2bd4d;

    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;

  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

.btn-blck-in-auta-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(38, 38, 39);
    color: rgb(255, 255, 255);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
    font-family: 'lato';
}

.btn-blck-in-auta-fcs:hover{
    background-color: rgb(71, 71, 71);
    transition: all 0.2s ease 0s;
}

.btn-blck-non-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(227, 227, 227);
    color: rgb(38, 38, 39);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
}

.btn-blck-non-fcs:hover{
    background-color: rgb(231, 231, 231);
    transition: all 0.2s ease 0s;
    color: black;
}

.modal-content{
    border-radius: 8px;
}

.btn-blck-non-fcs:focus{
    color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;
}
.btn-blck-non-fcs:active{

color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;

}


.con-of-temp-lst {
    display: inline-flex;
    width: 100%;
    padding: 5px 10px;
    border-radius: 10px;
    margin-bottom: 10px;
    }

    .con-of-temp-lst:hover {
    background: #f2f2f28a;
    cursor: pointer;
}

.con-of-temp-lst>div {
    width: 50%;
    }

    span.temp-name {
    font-size: 14px;
}

span.crt-data-of-tmp {
    font-size: 10px;
    }
.row{
    margin-left: 0px;
    margin-right: 0px;
}








.btn-primary.focus, .btn-primary:focus{

    color: #fff;
    box-shadow: 0 0 0 0.2rem rgb(105 109 113 / 50%);
    background-color: rgb(38, 38, 39);
    border-color: rgb(38, 38, 39);

}





.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000e8;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
    z-index: 100000000;
}

#cncl-err-msg:hover{


cursor: pointer;


}



.vert-cent-div {
 
  height: min-content;
  text-align: center;
  
  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
    
  margin: auto;
}

.switch-dis{
    display: none;
}






button:disabled,
button[disabled]{
  
  background-color: #cccccc !important;
  color: #666666 !important;
  border: none;
  cursor: not-allowed;
}



.data-head-of-img-fold {
    margin-top: 20px;
    display: inline-flex;
    width: 100%;
    margin-bottom: 20px;
    }

    .main-con-of-img-con {
    width: 100%;
    height: calc(100vh - 8vh - 76px);
    overflow: scroll;
    padding: 30px;
}

.back-btn-to-fold {
    padding: 10px;
    background: #ff008a;
    border-radius: 100px;
    font-size: 12px;
    color: white;
    font-weight: 700;
    margin-left: auto;
    margin-right: auto;
    }

    .con-of-srch-img {
    width: 50%;
}

.con-of-act-img {
    display: inline-flex;
    width: 30%;
    }

    .back-btn-to-fold.color-of-opt-btn {
    padding: 6px;
    background: #c3c2c2;
    border: 0px;
    transition: .4s;
}

.auta-dis-on-dash.img-con-of-fold {
    position: relative;
    padding: 0px;
    border-radius: 0px;
    display: flex;
    justify-content: center;
    margin-right: auto;
    margin-left: 20px;
}
   img.img-tag-for-con {
    width: auto;
    height: auto;
    position: absolute;
    top: 0;
    bottom: 0;
    max-height: 100%;
    max-width: 100%;
    margin: auto;
}

.back-btn-to-fold.color-of-opt-btn:hover {
    cursor: pointer;
    background: #c3c2c28f;
    }
    button.back-btn-to-fold.color-of-opt-btn:focus {
    outline: none;
}

.main-con-of-img-con{
    display: inline-flex;
}

.btn-mdl-act-sel {
    border-radius: 100px !important;
    color: black;
    font-weight: 500;
    font-size: 12px;
    margin-top: 20px;
    text-align: left;
    width: fit-content;
    }

    .btn-mdl-act-sel.active >svg {
    fill: white;
}

.btn-mdl-act-sel >svg {
    fill: black;
    }

    .btn-mdl-act-sel>svg{
        margin-right: 10px;
    }

    .btn-mdl-act-sel:hover svg{
        fill:blue;
    }

    .btn-mdl-act-sel.active:hover svg{
        fill:white;
    }

    .midd-sel-img {
    padding: 40px;
    border: 1px dashed;
    width: fit-content;
    padding: 40px;
    height: 100px;
    
    border-radius: 10px;

}
.sd-con-ico.dsc-inln-flx {
    width: 8%;
}
.midd-sel-img:hover{
    cursor: pointer;
}

img.img-pre-tg-img {
    width: 100%;
    height: auto;
    max-height: 100px;
    border-radius: 10px;

    }

    .img-con-pre {
    width: 98px;
    margin-right: 0px;
    height: 100px;
    position: relative;
    margin-right: 10px;
    margin-top: 10px;
}

#upload_img_form{
    display: inline-flex;
}

.con-of-all-srch {
    width: 600px;
    }

    .con-of-srch-img-thumb {
    border-top-right-radius: 10px;
}

img.img-of-con-srch {
    height: 200px;
    max-width: 250px;
    }

    .btn-con-of-dwn {
    padding: 10px;
    text-align: center;
}

    .full-swn-btn {
    width: fit-content;
    margin-right: 10px;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    margin-top: 10px;
    padding: 0px;
    border-radius: 10px;
}

.active_img_act {
    border: 3px solid blue;
    box-shadow: rgb(0 0 0 / 25%) 0px 14px 28px, rgb(0 0 0 / 22%) 0px 10px 10px;
    }

button.close {
    background: no-repeat;
    border: none;
    }


    th {
    font-weight: 600;
    font-size: 13px;
}

td {
    font-size: 12px;
    }


    .cp-round:after{
        border-top: solid 3px #564f4e;


    }
.img_editor-con{
    display: none;
}

    .tui-image-editor-header{
        display: none;
    }

    #tui-image-editor-container {
    width: 100% !important;
    height: calc(100vh - 52px) !important;
    top: 0px;
    position: fixed;
}

.save-fl-bar-con {
    width: 100%;
    height: 52px;
    background: #171717;
    margin-top: calc(100vh - 52px) !important;
    padding: 10px;
    text-align: right;
    }

    .ico-of-act-lst:hover{
        background:black !important;
    }


.card {
    padding: 0px;
    border-radius: 10px;
}
.cp-round:after{
        border-top: solid 3px #564f4e;


    }

</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">

  <link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1628745601/loader_ww3kdih.css">
  <!-- Icons -->
  <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">

 
  <!-- CSS Files -->

</head>

<body class="" style="">
  
 <div class="main-con-of-dash">



  <?php require("../../confige/header/theme-2.0-side.php");?>
    <div class="main-con-of-crm dsc-inln-flx">
         <?php    require("../../confige/header/header-new.php");?>



        <?php require("../../ajaxfile/phpfile/top_of_mngc_2.php");?>

       


<div id='main-loader-containre' style='text-align:none'>

  <div class="container "  style="">



    <div class="row head-con-rw">

<span class="nm-auta-con" style="
    width: 50%;
    font-size: 16px;
    color: black;
    height: fit-content;
    padding-top: 4px;
">

List Overview
</span>

<div class="btn-con-top" style="text-align:right">
    <button class="btn btn-primary btn-blck-in-auta-fcs com-for-lnk" data-for-serv="0" data-target-link="../../mngc/#mngc" style="float:none">Manage sp_test <i class="fa-long-arrow-right  fal" aria-hidden="true"></i></button>





    </div>

    </div>





</div>

<div id='main-content'>









<div id='con-of-all-chrt-and-ana-dt'>


<div class="container row marg-bot" style="margin:auto;margin-bottom:20px;">

  <div class="container" style="width:100%;border: 1px solid;border-radius: 10px;background:white;">    <div class="card-init-count" style="
    border-right: 1px solid;
">

    <div class="coun_con" id='tot_count_res'>
<div class="lds-ring lds-color  " id="lds-for-all-temp" style=""><div></div><div></div><div></div><div></div></div>

    </div>
    <div class="count_type">Total Response</div></div>


    <div class="card-init-count" style="
">

    <div class="coun_con" id='opn_count_res'><div class="lds-ring lds-color  " id="lds-for-all-temp" style=""><div></div><div></div><div></div><div></div></div></div>
    <div class="count_type">Open Response</div></div>
    <div class="card-init-count" style="border-left: 1px solid;">

    <div class="coun_con" id='clck_count_res'><div class="lds-ring lds-color  " id="lds-for-all-temp" style=""><div></div><div></div><div></div><div></div></div></div>
    <div class="count_type">Click Response</div></div>
    

    
    
</div>
</div>








<div class="container row marg-bot" style="margin:auto;margin-bottom:20px;">

  <div class="card" style='width:100%'>
  <header class="header-6RFqy"><div class="row-2bcC_"><i class="fal fa-calendar-alt ico-card-head"></i><h3 class="title-2V2Vk">Month Overview&nbsp;</h3></div><div class=""><p class="byline-1jw7n">Month wise user click and open your email campigns that send for this list.</p></div></header>


<div class="main-all-chrt_con">




<canvas class='chrt_dsg_bar' id='month_chrt'></canvas>





</div>

</div>

</div>



<div class="container row marg-bot" style="margin:auto;margin-bottom:20px;">

  <div class="card" style='width:100%'>
  <header class="header-6RFqy"><div class="row-2bcC_"><i class="fal fa-calendar-day ico-card-head"></i><h3 class="title-2V2Vk">Day Overview&nbsp;</h3></div><div class=""><p class="byline-1jw7n">Get Your best Day that increase your conversion from below analysis.</p></div></header>


<div class="main-all-chrt_con">




<canvas class='chrt_dsg_bar' id='day_chrt'></canvas>






</div>

</div>

</div>




<div class="container row marg-bot" style="margin:auto;margin-bottom:20px;">

  <div class="card" style='width:100%'>
  <header class="header-6RFqy"><div class="row-2bcC_"><i class="fal fa-hourglass ico-card-head"></i><h3 class="title-2V2Vk">Hour Overview&nbsp;</h3></div><div class=""><p class="byline-1jw7n">that hour you prefer for send email for your perfect user.</p></div></header>


<div class="main-all-chrt_con">



<canvas class='chrt_dsg_bar' id='hour_chrt'></canvas>





</div>

</div>

</div>

























<div class="container row marg-bot" style="margin:auto;margin-bottom:20px;">

  <div class="card" style='width:100%'>
  <header class="header-6RFqy"><div class="row-2bcC_"><i class="fal fa-globe-asia ico-card-head"></i><h3 class="title-2V2Vk">Prediction Anatomy&nbsp;</h3></div></header>


<div class="main-all-chrt_con">
<div class='chrt_con_main'>

<canvas class='chrt_dsg' id='gend_chrt' style='max-width:50%,
    padding: 20px;'  width=''></canvas>
</div>

<div class='chrt_con_main'>


<canvas class='chrt_dsg' id='age_chrt'></canvas>

</div>


</div>

</div>

</div>














<div class="container row marg-bot" style="margin:auto;margin-bottom: 20px;">
 




<div class="card" style="">
  
  
<header class="header-6RFqy"><div class="row-2bcC_"><i class="fal fa-location ico-card-head"></i><h3 class="title-2V2Vk">Top Country&nbsp;</h3></div><div class=""><p class="byline-1jw7n">Based on your contact’s IP address when they interact with your</p></div></header>


<div id="res_cnt_data" class=""></div>







</div>













<div class="card" style="margin-left: auto;">
  
  
<header class="header-6RFqy"><div class="row-2bcC_"><i class="fal fa-map-marker-check ico-card-head" aria-hidden="true"></i><h3 class="title-2V2Vk">Top Location&nbsp;</h3></div><div class=""><p class="byline-1jw7n">Based on your contact’s IP address when they interact with your</p></div></header>


<div id="res_reg_data" class=""></div>







</div>









</div>






</div>






  
</div>

</div>

</div>

</div>


 
<script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>


<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.6/Chart.bundle.min.js"></script>

  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
  
  
  
</body>











</html>







<script type="text/javascript">



get_email_api="<?php echo $lst_name;?>";






label_month=['January', 'February', 'March', 'April', 'May', 'June', 'July','August','September','Octomber','November','December'];

label_day=['Sun',"Mon",'Tue','Wed','Thu','Fri','Sat'];


label_hour=['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24'];






























pred_gend={m:0,f:0};

pred_age={m:{age25:0,age35:0,age45:0,age55:0,age65:0},f:{age25:0,age35:0,age45:0,age55:0,age65:0}};




$(document).ready(function(){






set_other_chart();




})











function set_other_chart(){









jQuery.get('./ajaxfile/get_ana_dash_data.php?path_val='+get_email_api+'&src=list', function(data2) {



if(data2==0){


$("#con-of-all-chrt-and-ana-dt").html('<div class="not-fd-suf-data" style=" text-align: center; "> <img src="https://res.cloudinary.com/heptera/image/upload/v1606727401/addcontact/10_Growth_vrdpjv.svg" style=" height: 400px; "> <div class="suf-data-nf" style=" font-size: 14px; font-weight: 700; color: black; ">Your List Campign Not Collected Sufficient data</div> </div>');



}else{

arr_data=JSON.parse(data2);

init_res_over_count(arr_data.count);


get_chrt(label_month,'month_chrt','Month Overview',arr_data.month.open,arr_data.month.click);


get_chrt(label_day,'day_chrt','Day Overview',arr_data.day.open,arr_data.day.click);




get_chrt(label_hour,'hour_chrt','Hour Overview',arr_data.hr.open,arr_data.hr.click);









jQuery.get('../../mngc/rahul1.php?apicode_main='+get_email_api, function(data2) {








           set_overvew_data_on_scr(data2);





  })







init_locate_data();



}



  })








}



function init_res_over_count(data){


console.log(data);

$("#tot_count_res").html(data.click_count+data.open_count);
$("#opn_count_res").html(data.open_count);
$("#clck_count_res").html(data.click_count);




}




function init_locate_data(){




jQuery.get('../overview/ajaxfile/get_location_data.php?src=list&path_val='+get_email_api+'&type=all', function(data2) {



  console.log(data2);

res_data=JSON.parse(data2);


all_res=res_data.all/2;




show_locate_data(res_data,'reg','cnt',all_res);
show_locate_data(res_data,'cnt','reg',all_res);




  })

}


function find_perce(one,base){


return (one/base)*100;



}



function show_locate_data(data,gp_tp,othr,all_count){


str_append='';

len_of_arr=data[gp_tp].length;

if(len_of_arr>0){


for (var i = 0; i < len_of_arr; i++) {
  
loop_data=data[gp_tp][i];



if(i%2==0){

img='200/200';

}else{

img='199/199';

}

perc=find_perce(loop_data['how'],all_count);




str_append+='<div class="container-2GnNH"><img class="img-loc-thumb" src="https://picsum.photos/'+img+'" style=" "> <p class="byline-1jw7n"><span class="tag-name-dis">'+loop_data[gp_tp]+'</span><br><span class="inactiveCountHeader-2Sfab" style=" margin-bottom: 0px; font-size: 15px; ">'+loop_data[othr]+'</span></p><span class="tag-name-dis" style="margin-left: auto;"> '+perc.toString()+'%</span> </div>';


};

}else{


str_append='<div class="not-fd-data" style=" margin: 0px; "> <img src="https://res.cloudinary.com/heptera/image/upload/v1624254380/addcontact/undraw_Location_search_re_ttoj_k4kyjt.svg" class="not-fd-img" style=" width: 120px; padding: 20px; border-radius: 10px; "> <br> <p class="not-fd-para-txt" style=" font-size: 12px; font-weight: 500; ">Your List User not make sufficient interection with <br> Email that you send</p><button class="btn_of_act cls_of_tbl_name" style="float: none;background: ##1b4e07;" id=""> More About Tracking</button> </div>';


}

$("#res_"+gp_tp+"_data").html(str_append);


}










function get_chrt(label,drw_ele,text,data_open,data_clck){


var barChartData = {
      labels: label,
      datasets: [{
        label: 'Open',
        backgroundColor:"rgb(249, 127, 80)" ,
        data: data_open
      }, {
        label: 'Click',
        backgroundColor: "rgb(79, 19, 94)",
        data: data_clck
      }, ]

    };







var ctx_hour = document.getElementById(drw_ele).getContext('2d');











var chart_hour = new Chart(ctx_hour, {


type: 'bar',
    data:barChartData,
    options: {

    plugins: {
            legend: {
                labels: {
                    // This more specific font property overrides the global property
                    font: {
                        size: 40
                    }
                }
            }
},
        title: {
            display: true,
            text: text,
            position:"bottom",
            fontColor:"black"
        },
        responsive: true,
          scales: {
            xAxes: [{
              stacked: true,
            }],
            yAxes: [{
              stacked: true
            }]
          }
    }





});


}




















































function set_overvew_data_on_scr(data){



arr_cont_data=JSON.parse(data);



for (var i = 0; i < arr_cont_data.length; i++) {


rw_data=arr_cont_data[i];



init_gend_data(rw_data);


init_age_data(rw_data);


}



drw_chrt_of_age();





draw_gend_chart();




}



function init_age_data(row){

int_age=parseInt(row['age_pre']);

int_gend=row['gender_pre'];







if(int_age<25){



pred_age[int_gend]['age25']+=1;


}else if(int_age<35){

  pred_age[int_gend]['age35']+=1;



}else if(int_age<45){

  pred_age[int_gend]['age45']+=1;

}else if(int_age<65){

pred_age[int_gend]['age55']+=1;


}else{

pred_age[int_gend]['age65']+=1;

}




}





function init_gend_data(row){


if(row['gender_pre']=='f'){


pred_gend.f+=1;



}else{


pred_gend.m+=1;


}



}

















function draw_gend_chart(){






new Chart(document.getElementById("gend_chrt"),{
  "type":"doughnut",
  "data":{
    "labels":["Male","Female"],
  "datasets":[{"label":"My First Dataset","data":[pred_gend.m,pred_gend.f],
  "backgroundColor":["rgb(249, 127, 80)","rgb(79, 19, 94)"]}]


},
"options" : {
        "percentageInnerCutout": 40
    }




});


}






function drw_chrt_of_age(){




console.log(pred_age);


var ctx = document.getElementById('age_chrt').getContext('2d');

var mixedChart = new Chart(ctx, {
    type: 'horizontalBar',
    data: {
      labels: ['18-25', '25-35', '35-45', '55-65','65+'],
        datasets: [{
          label:'Male',


            backgroundColor:"rgb(249, 127, 80)",
            data: [pred_age['m']['age25'], pred_age['m']['age35'], pred_age['m']['age45'], pred_age['m']['age55'],pred_age['m']['age65']],
            
        }, {
          label:'female',
            backgroundColor:"rgb(79, 19, 94)",
            data: [pred_age['f']['age25'], pred_age['f']['age35'], pred_age['f']['age45'], pred_age['f']['age55'],pred_age['f']['age65']],
            
           
        }],
        
    },

    options: {
       
      barRoundness: 1,
          
          
          responsive: true,
          scales: {
    yAxes: [{
        gridLines: {
            display: false
            
        },
        
        stacked: true

    }],
    xAxes: [{
        ticks: {
            beginAtZero: true,
            callback: function(value, index, values) {
                return '';
            },
        },
        gridLines: {
            display: false,
            drawBorder: false,
        },
        stacked: true
    }],
},

        }
    
});



}
 $('[data-toggle="tooltip"]').tooltip();

</script>

























