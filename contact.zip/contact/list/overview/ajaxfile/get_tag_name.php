<?php
session_start();
require("../../../confige/managetag.php");

$id=$_SESSION["id"];
$array_of_tag = array();

$tag_tbl_name="tag".$id;
$select_tag = "select * from ".$tag_tbl_name;
$result = $mngtag->query($select_tag);
$result_flg=$result->num_rows;


$i=0;
while($row = $result->fetch_assoc()) {

	$temp_array[$row["tag"]]=0;

if($i==$result_flg-1){
	array_push($array_of_tag,$temp_array);

}
$i++;
}


$geted_tag_array=$array_of_tag;


print_r(json_encode($geted_tag_array));

?>
