


<?php
session_start();
require("../confige/fileconfige.php");

require("../ajaxfile/phpfile/mysql_to_ip.php");


$lst_name=$_SESSION['listname'];






function get_email_col($list_id){
require("../confige/fileconfige.php");


        $get_col_query="SELECT `COLUMN_NAME`  FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='list_contacts' AND `TABLE_NAME`='".$list_id."' ORDER BY ordinal_position";

        $query = $conn3->query($get_col_query);

while($row = $query->fetch_assoc()){


        $result[] = $row;
}

// Array of all column names
$columnArr = array_column($result, 'COLUMN_NAME');

return $columnArr;



}




$get_col=get_email_col($lst_name);


if($_GET['src_req']=='normal'){
$query="select * from `".$lst_name."` where arch=0";
}else{
$query="select * from `".$lst_name."` where tag LIKE '%".$_GET['tag_send']."%' and arch=0";



}

header('Content-Type: text/csv; charset=utf-8');  
      header('Content-Disposition: attachment; filename=data.csv');  
      $output = fopen("php://output", "w");  
      fputcsv($output, $get_col);  
     
      $result = $conn3->query($query);

if ($result->num_rows > 0) {
  
  while($row = $result->fetch_assoc()) {
    fputcsv($output, $row); 
  }


fclose($output); 

} else {
  echo "0 row";
}
      



      ?>
