<html>







<button class="expo_fin_btn"     onclick="location.href='fin_export.php?tag_send=37'">Export</button>
<script src="./../../assets/js/plugins/jquery/dist/jquery.min.js"></script>

</html>
