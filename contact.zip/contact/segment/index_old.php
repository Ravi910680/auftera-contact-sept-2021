



<?php
session_start();

    $mail=$_SESSION["email"];
    $id=$_SESSION["id"];

require("../confige/fileconfige.php");
require("../confige/managetag.php");

require("../confige/camp_confige.php");






function get_email_col($list_id){
require("../confige/fileconfige.php");


	$get_col_query="SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='list_contacts' AND `TABLE_NAME`='".$list_id."' order by ordinal_position ";
	$query = $conn3->query($get_col_query);

while($row = $query->fetch_assoc()){


	$result[] = $row;
}

// Array of all column names
$columnArr = array_column($result, 'COLUMN_NAME');

return $columnArr;



}









function get_col_type($list_id,$col_get){
require("../confige/fileconfige.php");

$columnArr=array();

$i=0;


while(count($col_get)>$i){




      $get_col_query="SELECT `DATA_TYPE` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE  `TABLE_NAME`='".$list_id."' AND COLUMN_NAME ='".$col_get[$i]."'";
        $query = $conn3->query($get_col_query);

while($row = $query->fetch_assoc()){
$data_type=$row['DATA_TYPE'];

  if($data_type=='varchar'){

                $dt_tp='text';
        }else if($data_type=='date'){
                $dt_tp='date';
        }else if ($data_type=='bigint' || $data_type=='int'){
                $dt_tp='int';
        }









array_push($columnArr,$dt_tp);
}

$i+=1;

}


return $columnArr;

}



























$lst_name=$_SESSION['listname'];
$get_camp_data="select * from camp_contact_tbl where list_id='$lst_name' and (flg_send='2' or flg_send='0')";




$result = $camp_name_conn->query($get_camp_data);



$cnt_camp=$result->num_rows;


$array_of_tag = array();

$tag_tbl_name="tag".$id;
$select_tag = "select * from ".$tag_tbl_name;
$result = $mngtag->query($select_tag);


while($row = $result->fetch_assoc()) {
       

        array_push($array_of_tag,$row["tag"]);
    }













$get_col_nw=get_email_col($_SESSION['listname']);





$get_col=array_slice($get_col_nw,0,count($get_col_nw)-$cnt_camp-8);



$get_col_2=array_slice($get_col_nw,0,count($get_col_nw)-$cnt_camp-11);




$col_dt_tp=get_col_type($_SESSION['listname'],$get_col);



































?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">

<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet"> 
 <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />
<style>



.and_ico_for_seg {
    text-align: center;


  }

  .and_con {
    padding: 10px;
    width: 80px;

    
    color: #5a2977;
    margin: auto;
    border-radius: 10px;
    font-weight: 900;

  }











































.bottom-btn{
  text-align: center;
    height: 40px;
 background: #5a297747;
    color: #5a2977;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    
    padding-left: 20px;
    padding-right: 20px;
}


.bottom-btn:hover{
  cursor: pointer;
}




.select_new_sty{
  width: 200px !important;
}
.container{
  padding: 50px;
}
.con_fr_que{
margin: 0px;
    margin-top: 20px;
    margin-bottom: 20px;
    border-radius: 5px;
    box-shadow: rgb(0 0 0 / 12%) 0px 1px 3px, rgb(0 0 0 / 24%) 0px 1px 2px;
}


.main-sel-div-con {
    display: inline-flex;
    padding: 40px;
    width: 90%;
}





.cbx {
  margin: auto;
  -webkit-user-select: none;
  user-select: none;
  cursor: pointer;
}
.cbx span {
  display: inline-block;
  vertical-align: middle;
  transform: translate3d(0, 0, 0);
}
.cbx span:first-child {
  position: relative;
  width: 18px;
  height: 18px;
  border-radius: 3px;
  transform: scale(1);
  vertical-align: middle;
  border: 1px solid #9098A9;
  transition: all 0.2s ease;
}
.cbx span:first-child svg {
  position: absolute;
  top: 3px;
  left: 2px;
  fill: none;
  stroke: #FFFFFF;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 16px;
  stroke-dashoffset: 16px;
  transition: all 0.3s ease;
  transition-delay: 0.1s;
  transform: translate3d(0, 0, 0);
}
.cbx span:first-child:before {
  content: "";
  width: 100%;
  height: 100%;
  background: #506EEC;
  display: block;
  transform: scale(0);
  opacity: 1;
  border-radius: 50%;
}
.cbx span:last-child {
  padding-left: 8px;
}
.cbx:hover span:first-child {
  border-color: #506EEC;
}

.inp-cbx:checked + .cbx span:first-child {
  background: #506EEC;
  border-color: #506EEC;
  animation: wave 0.4s ease;
}
.inp-cbx:checked + .cbx span:first-child svg {
  stroke-dashoffset: 0;
}
.inp-cbx:checked + .cbx span:first-child:before {
  transform: scale(3.5);
  opacity: 0;
  transition: all 0.6s ease;
}

@keyframes wave {
  50% {
    transform: scale(0.9);
  }
}



















@import url(https://fonts.googleapis.com/css?family=Arvo);
@import url(https://fonts.googleapis.com/css?family=Dosis);
.tablediv{
    padding:10%;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;
    cursor:pointer;

}
.card:hover{
    cursor:default;
}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}








.btn_of_act{

background: #540a47;
    font-size: 13px;
    border-radius: 5px;
    color: white;
    padding: 5px 15px;
    border: none;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    margin-right: 20px;



}













#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1603531914/norm_used/loader_ww3kih.css">
  <!-- Icons -->
  

 
  <!-- CSS Files -->

</head>
<div id="c"></div>
<body class="" style="background:#fff">


<style>


.dropdown-menu{
    border-radius:0px;
    box-shadow:none;
    
    border:1px solid #dedddc;
overflow-y:scroll;   
}
.below-tit{
font-weight: 400;
    font-size: 18px;
    padding-top: 20px;
    color: #000000c7;
    font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    letter-spacing: 1px;
}
.color-fet{
padding-left:10px;
padding-right:10px;
font-weight:600;
}



.main-con {
    padding: 20px 0px 70px 0px;

    }

    a.hr-tag-con {
    color: #4a154b;
    font-size: 15px;

  }


select{
  font-weight: 600 !important;
    color: black !important;
}


</style>

<?php require("../confige/header/header.php");?>

<?php require("../ajaxfile/phpfile/top_of_mngc.php");?>





<div id="main-loader-containre">


<div class="container" style="width:100%;padding:120px 0px 0px 0px;">






<div class="main-con">
    
        <div class="">
            <a class="hr-tag-con" href="../../addcontact/"><i class="fal fa-chevron-left" aria-hidden="true" style="
    padding-right: 10px;
"></i>Back To Manage List</a>
        
        </div>
    
    </div>




</div>

<style>

.ip-by-def-dsg {
    width: 30%;
}





.select-wrapper {
        margin: auto;
        max-width: 600px;
        width: calc(100% - 40px);
      }

      .select-pure__select {
        align-items: center;
        background: white;
margin:10px;      
	border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: none;
        box-sizing: border-box;
        color: #363b3e;
        cursor: pointer;
        display: flex;
        font-size: 16px;
        font-weight: 500;
        justify-content: left;
        min-height: 44px;
        padding: 5px 10px;
        position: absolute;
        transition: 0.2s;
        width: 300px;
      }

      .select-pure__options {
        border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: #363b3e;
        display: none;
        left: 0;
        max-height: 220px;
        overflow-y: scroll;
        position: absolute;
        top: 50px;
        width: 100%;
        z-index: 5;
      }

      .select-pure__select--opened .select-pure__options {
        display: block;
      }

      .select-pure__option {
        background: #fff;
        border-bottom: 1px solid #e4e4e4;
        box-sizing: border-box;
        height: 44px;
        line-height: 25px;
        padding: 10px;
      }

      .select-pure__option--selected {
        color: #e4e4e4;
        cursor: initial;
        pointer-events: none;
      }

      .select-pure__option--hidden {
        display: none;
      }

      .select-pure__selected-label {

	align-items: 'center';
       
	border-radius: 4px;
font-size:13px;
        color: #5a2977;
    background: rgba(90, 41, 119, 0.11);
        cursor: initial;
        display: inline-flex;
        justify-content: 'center';
        margin: 5px 10px 5px 0;
        padding: 3px 7px;
      }

      .select-pure__selected-label:last-of-type {
        margin-right: 0;
      }

      .select-pure__selected-label i {
        cursor: pointer;
        display: inline-block;
        margin-left: 7px;
      }

      .select-pure__selected-label img {
        cursor: pointer;
        display: inline-block;
        height: 18px;
        margin-left: 7px;
        width: 14px;
      }

      .select-pure__selected-label i:hover {
        color: black;
      }

      .select-pure__autocomplete {
        background: #f9f9f8;
        border-bottom: 1px solid #e4e4e4;
        border-left: none;
        border-right: none;
        border-top: none;
        box-sizing: border-box;
        font-size: 16px;
        outline: none;
        padding: 10px;
        width: 100%;
      }

      .select-pure__placeholder--hidden {
        display: none;
      }
























.con-of-data {
 max-width:80%;
  max-height: 20em;
  overflow: scroll;
  position: relative;
}

table {
    
  position: relative;
  border-collapse: collapse;
}
tr{
    outline: 1px solid rgb(222, 221, 220);
}
td,
th {
  padding: 0.25em;
}

thead th {
    
    
  position: -webkit-sticky; /* for Safari */
  position: sticky;
  top: 0;
background: #ededf5ed;
    color: #090942;
 

 z-index: 100000;
}

thead th:first-child {
outline: 1px solid rgb(222, 221, 220); 
  left: 0;
  z-index: 1000000000;
}

tbody th {
  position: -webkit-sticky; /* for Safari */
  position: sticky;
  left: 0;
  background: #FFF;
  
}
tbody tr th{
  outline:  1px solid rgb(222, 221, 220); 
    z-index: 1000;
    background: white;
}
.con-data{
min-width: 150px;
max-width: 200px;
overflow: scroll;
padding: 12px 24px;
height:49px;
}
th .email-con{


color:black;


}
.email-con{
overflow-x:scroll;
    width:200px;
 padding-left: 20px;
    margin-right: 20px;   
  
}
.email-con::-webkit-scrollbar {
  display: none;
}
.con-of-data{
margin:0px auto;

margin-bottom:60px;
  color: #090942; 
    outline: 1px solid rgb(222, 221, 220); 

font-size:15px;
}

th.email-con:hover {
    cursor: pointer;
}


.con-data::-webkit-scrollbar {
  display: none;
}



.row.con_of_opt {



transition: all 0.5s ease 0s;

    background: #5a297708;
    margin: 60px auto 0px auto;
    max-width: 80%;
    max-height: 20em;
    position: relative;
    font-weight: 900;
    color: #5a2977;
}


.main_con_opt{
padding:20px;
}
.err_crt_seg{

width:70%;
padding: 6px;
    color: red;
    font-weight: 500;
overflow:scroll;

}








.row{
  margin: 0px;
}





button.btn_hover_clr {
   

        background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    color: #1a73e8;
    font-size: 13px;
    font-weight: 500;
    background: white;
  }

  

button.btn_hover_clr:hover {
    background: #e8f0fe;
    cursor: pointer;
  }


.del_ele_seg{



height: 100%;
    padding: 62px 0px;
    width: 10%;
    text-align: center;
    background: #c13259fa;
    border-radius: 20px 5px 5px 20px;
    color: white;

}




.del_ele_seg:hover{

cursor:pointer;

}













input{
  font-weight: 600 !important;
    color: black !important;
}






.vert-cent-div {
  width: min-content;
  height: min-content;
  text-align: center;
  
  position: fixed;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
   
  margin: auto;
}

button:hover{
cursor:pointer;

}


.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000b5;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
    z-index: 100000000;
}




</style>



<div class="container" style="padding-bottom:0px;">

<div class="row" style="
    margin: 0px;
">
    <div class="ip_name_seg" style="
    width: 50%;
">
    
    <input id="seg_name_data" class="form-control ip-by-def-dsg" type="text" style="
    width: 100% !important;
    margin: 0px !important
">
    </div>
    

<div class="btn_con row" style="
    width: 50%;
    margin: 0px;
">
      
    
    
<div class="btn_pre_con_main" style="
    width: 100%;
">


<button  class="btn_of_act" id="del_seg_btn" data-modal-trigger="del_seg_mdl"  style="
    float: right;display:none;
    background: #a51010;
    "><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16" style="
    margin-right: 10px;
">
  <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"></path>
  <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"></path>
</svg>Delete</button>


<button id="seg_pre_btn" class="btn_of_act" data-toggle="modal" data-target="#seg_pre_mod" style="
    float: right;
    "><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-app-indicator" viewBox="0 0 16 16" style="
    margin-right: 10px;
">
  <path d="M5.5 2A3.5 3.5 0 0 0 2 5.5v5A3.5 3.5 0 0 0 5.5 14h5a3.5 3.5 0 0 0 3.5-3.5V8a.5.5 0 0 1 1 0v2.5a4.5 4.5 0 0 1-4.5 4.5h-5A4.5 4.5 0 0 1 1 10.5v-5A4.5 4.5 0 0 1 5.5 1H8a.5.5 0 0 1 0 1H5.5z"></path>
  <path d="M16 3a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"></path>
</svg>Preview</button></div>
    </div>



    </div>
</div>






<div class="container" id="con_of_opt">

</div>





<div class="container">
<button class="btn_of_act" id="add_ele_to_seg" style="
background: #713a0a;   
    display: inline-block;
"><svg style="margin-right: 10px;" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-node-plus" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M11 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM6.025 7.5a5 5 0 1 1 0 1H4A1.5 1.5 0 0 1 2.5 10h-1A1.5 1.5 0 0 1 0 8.5v-1A1.5 1.5 0 0 1 1.5 6h1A1.5 1.5 0 0 1 4 7.5h2.025zM11 5a.5.5 0 0 1 .5.5v2h2a.5.5 0 0 1 0 1h-2v2a.5.5 0 0 1-1 0v-2h-2a.5.5 0 0 1 0-1h2v-2A.5.5 0 0 1 11 5zM1.5 7a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1z"/>
</svg>Add Condition</button>



<button class="btn_of_act" id="save_data" style="display: inline-block;float: right;">Save Segment<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-save2" viewBox="0 0 16 16" style="
    margin-left: 10px;
">
  <path d="M2 1a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H9.5a1 1 0 0 0-1 1v4.5h2a.5.5 0 0 1 .354.854l-2.5 2.5a.5.5 0 0 1-.708 0l-2.5-2.5A.5.5 0 0 1 5.5 6.5h2V2a2 2 0 0 1 2-2H14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h2.5a.5.5 0 0 1 0 1H2z"></path>
</svg></button>


</div>





<style>









.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid #5a2977;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: #5a2977 transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}


.tag_ext_con {
    height: 220px;
    margin-top: 58px;
padding:10px;
}

















.tag_filt_con{
margin:3px;
}
.tag_con_act{


color: #5a2977;
    background: rgba(90, 41, 119, 0.11);
}






.dropdown1 {
  position: relative;
  display: inline-block;
}

.dropdown1-content {
display:none;
height:350px;
  position: absolute;
  background-color: white;

border-radius: 0px 0px 10px 10px;
  min-width: 352px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 12px 16px;
  z-index: 10000000;


}


.main_con_opt:hover{
cursor:pointer;
}


.row.tag_link_con {
    margin: 0px;
  height:50px;
}
.link_hr {
    width: 50%;
    font-size: 17px;
    padding:10px 0px;
    color: #5a2977;
}

.dropdown1:hover .dropdown1-content{
 
}
.btn-link:hover{
color:#5a2977;
background:rgba(90, 41, 119, 0.11);

}

.btn-link{
padding:5px;
border-radius:5px;
background: transparent;
    font-weight: 600;
    box-shadow: none;
transition:0.1s; 
   border: none;
}

.bottom-more-info.container {
    width: 100%;
    text-align: center;
    background: #4a154b;
    border-radius: 10px;

    }

.not-fd-data {
    text-align: center;
    border-radius: 4px;
    padding: 20px;
}


.txt-not-fd {
    padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
    font-size: 10px;
    max-width: 50%;
}


.modal.fade .modal-dialog {
  transform: translate3d(0, 100vh, 0);
}

.modal.in .modal-dialog {
  transform: translate3d(0, 0, 0);
}




































.modal-2 {
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 0vh;
  background-color: transparent;
  overflow: hidden;
  transition: background-color 0.25s ease;
  z-index: 9999;
}
.modal-2.open {
  position: fixed;
  width: 100%;
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.5);
  transition: background-color 0.25s;
}
.modal-2.open > .content-wrapper {
  transform: scale(1);
}
.modal-2 .content-wrapper {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  width: 40%;
  margin: 0;
  padding: 2.5rem;
  background-color: white;
  border-radius: 0.3125rem;
  box-shadow: 0 0 2.5rem rgba(0, 0, 0, 0.5);
  transform: scale(0);
  transition: transform 0.25s;
  transition-delay: 0.15s;
}
.modal-2 .content-wrapper .close {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 2.5rem;
  height: 2.5rem;
  border: none;
  background-color: transparent;
  font-size: 1.5rem;
  transition: 0.25s linear;
}
.modal-2 .content-wrapper .close:before, .modal-2 .content-wrapper .close:after {
  position: absolute;
  content: '';
  width: 1.25rem;
  height: 0.125rem;
  background-color: black;
}
.modal-2 .content-wrapper .close:before {
  transform: rotate(-45deg);
}
.modal-2 .content-wrapper .close:after {
  transform: rotate(45deg);
}
.modal-2 .content-wrapper .close:hover:before, .modal-2 .content-wrapper .close:hover:after {
  background-color: tomato;
}
.modal-2 .content-wrapper .modal-2-header {
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  margin: 0;
  padding: 0 0 1.25rem;
}
.modal-2 .content-wrapper .modal-2-header h2 {
  font-size: 1.5rem;
  font-weight: bold;
}
.modal-2 .content-wrapper .content {
    position: relative;
    display: flex;
    text-align: center;
    color: #504b4b;
  }
.modal-2 .content-wrapper .content p {
  font-size: 0.875rem;
  line-height: 1.75;
}
.modal-2 .content-wrapper .modal-2-footer {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  width: 100%;
  margin: 0;
  padding: 1.875rem 0 0;
}
.modal-2 .content-wrapper .modal-2-footer .action {
  position: relative;
  margin-left: 0.625rem;
  padding: 0.625rem 1.25rem;
  border: none;
  background-color: slategray;
  border-radius: 0.25rem;
  color: white;
  font-size: 0.87rem;
  font-weight: 300;
  overflow: hidden;
  z-index: 1;
}
.modal-2 .content-wrapper .modal-2-footer .action:before {
  position: absolute;
  content: '';
  top: 0;
  left: 0;
  width: 0%;
  height: 100%;
  background-color: rgba(255, 255, 255, 0.2);
  transition: width 0.25s;
  z-index: 0;
}
.modal-2 .content-wrapper .modal-2-footer .action:first-child {
  background-color: #2ecc71;
}
.modal-2 .content-wrapper .modal-2-footer .action:last-child {
  background-color: #e74c3c;
}
.modal-2 .content-wrapper .modal-2-footer .action:hover:before {
  width: 100%;
}






.modal-2-header h2{

  color: black;
}
































</style>





</div>



<div class="modal in  fade" id="seg_pre_mod" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" >
  

<div class="modal-dialog" role="document" style="min-width:100%;margin: 0px;margin-top: 30vh;height: 70vh;">
<div class="modal-content" style="min-width:100%;height:100%;border-top-left-radius: 20px;border-top-right-radius: 20px;">

      <div class="modal-header" style="">
        <h5 class="modal-title" id="exampleModalLabel">Segment Preview</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="mdl_pre_con">


<div class="lds-ring" id="ld_for_seg" style="display:none"><div></div><div></div><div></div><div></div></div>

       <div class='con-of-data '>
  <table class='table-data-con'>
    <thead>

      <tr>


<th style='z-index:1000000;background: #5a2977;' > <div class='email-con' style='color:white;'>email</div> </th>

<?php

for($i=1;$i<count($get_col);$i++){


?>

        <th><div class='con-data'><?php echo $get_col[$i];?></div></th>


<?php

}
?>
      </tr>

    </thead>
    <tbody>

    </tbody>
  </table>
</div>
      </div>
     
    </div>
  </div>
</div>










<div class="modal-2" data-modal="del_seg_mdl" id='del_seg_mdl'>
<article class="content-wrapper">
<div class="head-line-of-mdl" style="
    margin-right: auto;
    color:black;
">
<h4>Create New Field</h4>
</div>
<div class="btn-con-del-camp" style="
    width: 100%;
">

<input class="ip-by-def-dsg" id="fld_del_conf" placeholder="Enter DELETE In field" name="nameofnewlist" type="text" style="width:100%;" required="">
</div>
<button class="btn-theme-dsg " id="sb_del_seg_btn" style="">Delete Segment</button>
<button class="btn-theme-dsg  del_mdl_cls" mdl-cls-tp="del_seg_mdl" style="background:white;color:#350835;border:1px solid #350835;">Cancel,Keep It Campign</button>
</article>
</div>















<div class="vert-cent-div err-menu-cls-dsg" id="err_msg_dt_trg" style="display: none;">
<span id="con-of-err-msg"></span>
<span class="cls-err-menu" id="cncl-err-msg">
<i class="fal fa-times-circle" style="
    padding: 6px;
"></i>
</span>
</div>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>

<script src="../ajaxfile/phpfile/head_mngc.js"></script>
  
 
 
<script>
  //      $(document).ready(function(){
    //     jQuery.get('ravi.html', function(data) {
//		$("#tbl-con").append(data);
//	 });
//jQuery.get('ravi1.html', function(data) {
  //              $(".sticky-wrap").append(data);
    //     });
	//	
//
//
//









obj_data={};


obj_data.text=["is match","start with","find","not contain"];
obj_data.int=["is equal to","is greater","is less","is not equal to"];
obj_data.date=["before date","after date","before 2 day","before 5 day"];
obj_data.flg_camp=["opened","click","was sent","did not open","did not click","was not sent"];
obj_data.flg_camp2=["any of 5 campign","in last 7 day","in last 1 month","in last 3 month"];
obj_data.flg_conv=["is replied","no replied"];
obj_data.flg_conv2=["any of 5 campign","in last 7 day","in last 1 month","in last 3 month"];
obj_data.flg_cli=["is","is not"];
obj_data.flg_cli2=["gmail","yahoo","outlook","hotmail","AOL"];
obj_data.flg_src=["was","was not"];
obj_data.flg_src2=["By admin","API","File","cloud"];
obj_data.flg_sub=["is","is not"];
obj_data.flg_sub2=["subscribe","bounced","un-subscribe","none-subscribe","VIP"];
obj_data.flg_tag=["is","is not"];
obj_data.flg_tag2=[<?php echo '"'.implode('","', $array_of_tag).'"' ?>];
obj_data.flg_gend=["is","is not"];
obj_data.flg_gend2=['male','female'];




arry_of_fld={fld_name:[<?php echo '"'.implode('","', $get_col_2).'"' ?>],fld_type:[<?php echo '"'.implode('","', $col_dt_tp).'"' ?>]};






all_costm_fld={arry_of_fld_hy:{label:"email history",fld_name:["crt_date","chg_date","eml_cli"],fld_type:["date","date","flg_cli"],fld_name_sh:["added date","last change Info","email client"]},arry_of_fld_req_res:{label:"campign history",fld_name:["camp_act","con_rat","source","substatus","tag"],fld_type:["flg_camp","int","flg_src","flg_sub","flg_tag"],fld_name_sh:["campign activity","contact rating","source of contact","subscriber status","by tag"]},arr_of_pred_fld:{label:"predicted",fld_name:["gender_pre","age_pre"],fld_type:['flg_gend','int'],fld_name_sh:['predicted gender','predicted age']}}









flg_for_cunt=0;

add_field_seg();



function add_field_seg(k){
data_old_flg="";
	if(k>0){
data_old_flg="old-"+k;
	}

 
str_for_app="<div class='row con_fr_que'><div class='main-sel-div-con'><select class='ip-by-def-dsg form-control form-control-sm mx-sm-3 mb-2 select_new_sty sel_data' data-old-seg='"+data_old_flg+"' data-next='1-3'>";


str_for_app+="<optgroup label='Admin Field'>";
for (var i = 0; i < arry_of_fld["fld_name"].length; i++) {
  str_for_app+="<option value='"+arry_of_fld["fld_name"][i]+"^1^"+arry_of_fld["fld_type"][i]+"'>"+arry_of_fld["fld_name"][i]+"</option>";
};

str_for_app+="</optgroup>";





str_for_app+=cstm_fld_show();



str_for_app+="</select></div><div class='del_ele_seg del_seg_dt' style=''><svg xmlns='http://www.w3.org/2000/svg' width='20' height='20' fill='currentColor'class='bi bi-trash' viewBox='0 0 16 16'> <path d='M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z'/> <path fill-rule='evenodd' d='M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z'/> </svg></div></div><div class='and_ico_for_seg'><div class='and_con'><span>AND</span></div></div>";

$("#con_of_opt").append(str_for_app);

flg_for_cunt+=1;


console.log(flg_for_cunt);

}


function cstm_fld_show(){


str_for_app='';

for (let key in all_costm_fld) { 


label_fld=all_costm_fld[key]['label'];


arr_pres_add=all_costm_fld[key];

str_for_app+="<optgroup label='"+label_fld+"'>";
for (var i = 0; i < arr_pres_add["fld_name"].length; i++) {
  str_for_app+="<option value='"+arr_pres_add["fld_name"][i]+"^1^"+arr_pres_add["fld_type"][i]+"'>"+arr_pres_add["fld_name_sh"][i]+"</option>";
};

str_for_app+="</optgroup>";



}


return str_for_app;

}



$(document).on("click","#add_ele_to_seg",function(){

console.log(save_data_json_form());

if(save_data_json_form()==0){

console.log("please select req Field");
}else{

add_field_seg();
}
});



$(document).on("click",".del_seg_dt",function(){



if(flg_for_cunt==1){




}else{

  $(this).parent().next(".and_ico_for_seg").remove();



$(this).parent().remove();


flg_for_cunt-=1;
}



});


function get_flg_str_data(rem_data_2,rem_data_1,cnt_loc,type_data,data_flg,old_flg){


sep_flg_old=old_flg;

if(rem_data_2==rem_data_1){


	old_flg="old-2-"+old_flg;

str_for_app+=get_init_str(cnt_loc,type_data+"2",data_flg,2,old_flg);


}else{


old_flg="old-2-"+old_flg;


str_for_app+=get_init_str(cnt_loc,type_data,data_flg,0,old_flg);


str_for_app+="</select>";


rem_data_1+=1;

data_flg=rem_data_1+"-"+rem_data_2;


old_flg="old-3-"+sep_flg_old;

str_for_app+=get_init_str(cnt_loc,type_data+"2",data_flg,2,old_flg);


}

}



function delete_seg_fun(){




	$.ajax({
                url : "./ajaxfile/del_seg.php",
                type: "POST",
                data : {seg_id:seg_id_curr}
        }).done(function(response){


console.log(response);

        });

}



$(document).on('click',"#sb_del_seg_btn",function(){

	if($("#fld_del_conf").val()=="DELETE"){


delete_seg_fun();



	}else{

err_msg_data("Enter DELETE exactly");
	}

});












$(document).on('click',"#del_seg_btn",function(){


 modalEvent(this);


});










function get_init_str(cnt_loc,type_data,data_flg,flg_stat,old_flg){

console.log(data_flg);



str_for_app="";

if(flg_stat==2){
str_for_app+="<select class='ip-by-def-dsg form-control form-control-sm mx-sm-3 mb-2 select_new_sty' data-old-seg='"+old_flg+"'  data-next="+data_flg+">";
}else{

str_for_app+="<select class='ip-by-def-dsg form-control form-control-sm mx-sm-3 mb-2 select_new_sty sel_data' data-old-seg='"+old_flg+"' data-next="+data_flg+">";

}
for (var i = 0; i < obj_data[type_data].length; i++) {
  str_for_app+="<option value='"+obj_data[type_data][i]+"^"+cnt_loc+"^"+type_data+"'>"+obj_data[type_data][i]+"</option>";
}

return str_for_app;
}



function append_select_data(count_dt,type_data,data_flg,flg_old){
	
	
	

sep_data_for_flg=flg_old;


	str_for_app="";
console.log(flg_old);
count_dt=parseInt(count_dt);

rem_data_1=parseInt(data_flg[0])+1;
rem_data_2=parseInt(data_flg[1]);

data_flg=rem_data_1+"-"+rem_data_2;
cnt_loc=count_dt-1;


flg_old_for_ip="old-3-"+flg_old;

if(type_data=="text"){


if(rem_data_2==rem_data_1){


str_for_app+="<input class='form-control ip-by-def-dsg' type='text' data-old-seg='"+flg_old_for_ip+"'  data-next="+data_flg+">";


}else{

flg_old="old-2-"+flg_old;

str_for_app+=get_init_str(cnt_loc,type_data,data_flg,0,flg_old);


str_for_app+="</select>";

rem_data_1+=1;

data_flg=rem_data_1+"-"+rem_data_2;

flg_old="old-3-"+flg_old;

str_for_app+="<input class='form-control ip-by-def-dsg' type='text' data-old-seg='"+flg_old_for_ip+"' data-next="+data_flg+">";
}


}else if(type_data=="int"){


if(rem_data_2==rem_data_1){




str_for_app+="<input class='form-control ip-by-def-dsg' type='number' data-old-seg='"+flg_old_for_ip+"' data-next="+data_flg+">";


}else{


flg_old="old-2-"+flg_old;

str_for_app+=get_init_str(cnt_loc,type_data,data_flg,0,flg_old);


str_for_app+="</select>";




rem_data_1+=1;

data_flg=rem_data_1+"-"+rem_data_2;




str_for_app+="<input class='form-control ip-by-def-dsg' type='number' data-old-seg='"+flg_old_for_ip+"' data-next="+data_flg+">";

}






}else if(type_data=="date"){


if(rem_data_2==rem_data_1){


str_for_app+="<input class='form-control ip-by-def-dsg' type='date' data-old-seg='"+flg_old_for_ip+"' data-next="+data_flg+">";


}else{


flg_old="old-2-"+flg_old;

str_for_app+=get_init_str(cnt_loc,type_data,data_flg,0,flg_old);


str_for_app+="</select>";




rem_data_1+=1;

data_flg=rem_data_1+"-"+rem_data_2;



str_for_app+="<input class='form-control ip-by-def-dsg' type='date' data-old-seg='"+flg_old_for_ip+"' data-next="+data_flg+">";




}



}else if(type_data.slice(0,3)=="flg"){






get_flg_str_data(rem_data_2,rem_data_1,cnt_loc,type_data,data_flg,sep_data_for_flg);





}














return str_for_app;







}





$(document).on("change",".sel_data",function(){


 
var get_val_of_fld=$(this).val().split("^");

var data_flg=$(this).attr("data-next").split("-");
rem_flg_1=parseInt(data_flg[0])+1;
rem_flg_2=parseInt(data_flg[1]);

rem_dt=rem_flg_1+"-"+rem_flg_2;
 $(this).parent().children('select[data-next='+rem_dt+']').remove();

$(this).parent().children('input[data-next='+rem_dt+']').remove();

rem_flg_1+=1;
rem_dt=rem_flg_1+"-"+rem_flg_2;

console.log(rem_dt);
$(this).parent().children('select[data-next='+rem_dt+']').remove();
$(this).parent().children('input[data-next='+rem_dt+']').remove();



console.log(data_flg);
str_for_app=append_select_data(get_val_of_fld[1],get_val_of_fld[2],data_flg,0);


$(str_for_app).insertAfter(this);


});



last_json_obj=[];







function cls_mdl_pre(){

$("#not-fd_pre_suf").remove();
$("#mdl_pre_con").append('<div class="not-fd-data" id="not-fd_pre_suf"><img src="https://res.cloudinary.com/heptera/image/upload/v1622821285/account/undraw_Accept_request_re_d81h_zf0qze.svg" style="padding:20px;" height="100"><div class="txt-not-fd">Ther is not Sufficient field or data in table or segment please check refresh this window.</div><button class="bottom-btn" data-modal-trigger="src_img_modal" id="ip-img-src-api" style="background: #94918d;border: none;box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.15) 0px 1px 3px 1px;color: black;font-size: 13px;font-weight: 600;float: none;">Close Window</button></div>');

}










function save_data_json_form(){
flg=0;
array_of_loc_data=[];



append_load_in_all_btn("#save_data");
$('.con_fr_que').map(function() {
    
    rem_data_1=1;
    rem_data_2=3;
    rem_dt=rem_data_1+"-"+rem_data_2;

trg_obj_dt=$(this).children(".main-sel-div-con");

var data1=trg_obj_dt.children('select[data-next='+rem_dt+']').val();


rem_data_1+=1;
rem_dt=rem_data_1+"-"+rem_data_2;

var data2=trg_obj_dt.children('select[data-next='+rem_dt+']').val();

rem_data_1+=1;
rem_dt=rem_data_1+"-"+rem_data_2;


var data4=trg_obj_dt.children('select[data-next='+rem_dt+']').val();


if(data4==null){

var data4=trg_obj_dt.children('input[data-next='+rem_dt+']').val();
}
console.log(data1);


if((data1==null) || ( (data2==null)  )){



	 cls_mdl_pre();
	err_msg_data("Please Complete Field");
flg=1;


}else{



array_of_loc_data.push([data1,data2,data4]);

}






});


append_txt_of_lds("#save_data");

if(flg==1){

 return 0; 
}


last_json_obj=array_of_loc_data;

}

json_obj={};





seg_id_curr=0;









function init_seg_all_fld_data_blk (req_data) {
  
console.log(req_data[0].length);

for (var i = 0; i < req_data[0].length; i++) {
flg_field_tp=req_data[0][i].field.split("^")[2];
var str_for_app=append_select_data(1,flg_field_tp,["1", "3"],i+1);

	add_field_seg(i+1);
sel_fld_val="old-"+(i+1);



selector_data='[data-old-seg="'+sel_fld_val+'"]';

$(selector_data).val(req_data[0][i].field);
$(str_for_app).insertAfter(selector_data);


sel_fld_sec="old-2-"+(i+1);
selector_sec='[data-old-seg="'+sel_fld_sec+'"]';

console.log(selector_sec);

$(selector_sec).val(req_data[0][i].cond);





sel_fld_sec="old-3-"+(i+1);
selector_sec='[data-old-seg="'+sel_fld_sec+'"]';

//two type of data availabel for flg 0 -1
//
//


sec_data=req_data[0][i].data.split("^");

console.log(sec_data.length);
if(sec_data.length>1){
sec_fin_data=sec_data[0]+"^0^"+sec_data[2];
}else{

sec_fin_data=req_data[0][i].data;

}

$(selector_sec).val(sec_fin_data);


}


$("#del_seg_btn").css('display','block');

}



function init_seg_fe_data(){

$.ajax({
  type: "POST",
  url: "./ajaxfile/get_seg_data_fld.php",
  data: {seg_id:seg_id_curr}
}).done(function(response1) {
console.log(response1);

passed_arr_of_fld=JSON.parse(response1);

$("#seg_name_data").val(passed_arr_of_fld.seg_data['seg_name']);
$("#seg_name_data").prop("readonly",true);
init_seg_all_fld_data_blk(passed_arr_of_fld.field);

});


}






$(document).ready(function(){



console.log(window.location.href);

url=window.location.href;

seg_id_curr=url.split("#")[4];
console.log(seg_id_curr);
if(seg_id_curr){

console.log("ravi");
	init_seg_fe_data();

}

})















function save_seg_fld_rec(){

append_load_in_all_btn("#save_data");





if(save_data_json_form()==0){




cls_mdl_pre();


 }else{





json_obj.data_link=last_json_obj;

send_json=JSON.stringify(json_obj);



name_segment=$("#seg_name_data").val();
if(name_segment.length>0){

json_obj.data_link=last_json_obj;

send_json=JSON.stringify(json_obj);


$.ajax({
  type: "POST",
  url: "./ajaxfile/save_segment.php",
  data: {send_obj:send_json,seg_name:name_segment}
}).done(function(response1) {

console.log(response1);
	data_jsn=JSON.parse(response1);

flg_stat=data_jsn.status;
message=data_jsn.message;
if(flg_stat==1){
$("#seg_name_data").prop("readonly",true);
$("#del_seg_btn").css('display','block');
seg_id_curr=message;
err_msg_data("Segment Saved");
save_data_seg();
}else{
err_msg_data(message);
}

console.log("rrrrrr");
append_txt_of_lds("#save_data");

});


}else{


err_msg_data("Please Enter Segment Name");
append_txt_of_lds("#save_data");
}
}
}

























$(document).on("click","#save_data",function(){

save_seg_fld_rec();


});













$(document).on("click","#seg_pre_btn",function(){
$(".table-data-con").children("tbody").empty();
$(".con-of-data").css("display","none");
$("#ld_for_seg").css("display","block");
 if(save_data_json_form()==0){

 }else{

save_seg_fld_rec();
}

});



function get_tbl_data(str_query){
console.log(str_query);
 jQuery.get("../mngc/rahul1.php?apicode_main=query&post_query_link="+escape(str_query), function(data2) {

console.log(data2);

            get_tbl_enbl(data2);
 
 
 $(".con-of-data").css("display","block");

 $("#ld_for_seg").css("display","none");
 }).fail(function(error) {
    console.log(error); // or whatever
});

}


function save_data_seg(){
	
json_obj.data_link=last_json_obj;

send_json=JSON.stringify(json_obj);

console.log(send_json);

select_str="";

$.ajax({
  type: "POST",
  url: "./ajaxfile/sage_res.php",
  data: {seg_id:seg_id_curr}
}).done(function(response1) {
console.log(response1);
get_tbl_data(response1);      



});
}

















crt_data_ver=[];



















function json_req_for_tag(data_json){


$.ajax({
                url : "./ajaxfile/update_tag.php",
                type: "POST",
                data : "requestoflist="+data_json+"&get_stat_act=tag"
        }).done(function(response){ 

init_tbl_data();                
console.log(response);

        });





}





















flg_for_filt=0;

dp_dw_stat="";

tag_get=[];





































ary=[];







































deco_data=[];












arr_of_data=[];






















































function sub_stat_enco(sub_flg){

if(sub_flg==1){
                return "subscribe";
        }else if(sub_flg==2){
                return "un-subscribe";
        }else if(sub_flg==3){

                return "none-subscribe";
        }else if(sub_flg==4){
                return "bounced";

	}else if(sub_flg==5){
		return "VIP";
	}



}


function get_tag_html(geted_data){


get_res_tag="";
	
for(k=0;k<geted_data.length;k++){
get_res_tag+="<span class='badge badge-primary' style='margin:3px;'>"+geted_data[k]+"</span>";

}

return get_res_tag;

}






function get_tbl_enbl(geted_data){
str_tbl_enbl="";
        crt_data_ver=JSON.parse(geted_data);
        length_of_array=crt_data_ver.length;


var js_array = [<?php echo '"'.implode('","', $get_col).'"' ?>];

console.log(crt_data_ver.length);

if(length_of_array>0){
        for(i=0;i<length_of_array;i++){
        str_tbl_enbl+="<tr><th class='email-con'><div class='row' style='width:280px;'><div class='email-con'>"+crt_data_ver[i]["email"]+"</div></div></th>"
for (j=1;j<js_array.length-3;j++){

	console.log(crt_data_ver[i][js_array[j]]);
str_tbl_enbl+="<td><div class='con-data'>"+crt_data_ver[i][js_array[j]]+"</div></td>";



}
get_res_tag=get_tag_html(crt_data_ver[i][js_array[j]]);


str_tbl_enbl+="<td><div class='con-data' style='min-width:300px;'>"+get_res_tag+"</div></td>";
j+=1;

var get_sub_stat=sub_stat_enco(crt_data_ver[i][js_array[j]]);
str_tbl_enbl+="<td><div class='con-data sub_stat_con'><span class='badge badge-pill badge-success'>"+get_sub_stat+"</span></div></td>";
i
j+=1;
str_tbl_enbl+="<td><div class='con-data'>"+crt_data_ver[i][js_array[j]]+"</div></td>";






str_tbl_enbl+="</tr>";




dp_dw_stat="";

tag_get=[];
arr_of_data=[];


	}


}else{


	cls_mdl_pre();

}

$(".table-data-con").children("tbody").append(str_tbl_enbl);



}





        </script>

<div id='res4'></div>

 
            
  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
  <script>
  function getdata(path){
      $(".navlinksub").removeClass("active");
      ChangeUrl(path,"?path="+path);
      
      $("#loader").css("display","block");


$(".main-content").load(path+".php", function(responseTxt, statusTxt, xhr){
    if(statusTxt == "success")
      $("#loader").css("display","none");
    if(statusTxt == "error")
      $("#loader").css("display","none");
  });
      
      
      

  }
  function ChangeUrl(title, url) {
    if (typeof (history.pushState) != "undefined") {
        var obj = { Title: title, Url: url };
        history.pushState(obj, obj.Title, obj.Url);
    } else {
        alert("Browser does not support HTML5.");
    }
}
      </script>
  <script>


$(document).on("click",".opt_on_list",function(){
var type_opr=$(this).attr("id");
var define_opt1 = $(this).attr("class");
var define_opt=define_opt1.split(" ");
var final_opr=define_opt[1];  
  
      
      $("#loadsendlink").css("display","inline-block");

    $.ajax({
                url : "./../ajaxfile/crtseslist.php",
                type: "POST",
                data : "requestoflist="+type_opr
        }).done(function(response){ 
$("#res").html(response);
        if(response==1){

window.location = "./../"+final_opr+"/";


      }

        });
  
});







function modalEvent(button) {

  
    const trigger = button.getAttribute('data-modal-trigger');
    const modal = document.querySelector(`[data-modal=${trigger}]`);
   
    
    
    
    

    modal.classList.toggle('open');
  
  
}




$(document).on('click',".del_mdl_cls",function(){


tp_of_mdl=$(this).attr("mdl-cls-tp");

$("#"+tp_of_mdl).removeClass("open");


})













append_txt_that_get_clck="";



function append_load_in_all_btn(selector){




append_txt_that_get_clck=$(selector).html();

$(selector).prop("disabled",true);

}



function append_txt_of_lds(selector){

$(selector).prop("disabled",false);

$(selector).html(append_txt_that_get_clck);


}

















function err_msg_data(message){


$("#con-of-err-msg").html(message);

$("#err_msg_dt_trg").css('display','inline-block');



setTimeout(
    function() {


      $("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');
      
    }, 5000);


}



$(document).on('click','#cncl-err-msg',function(){


$("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

})




</script>
  
  
</body>

<script type="text/javascript" src="../jsfile/stickyheader4.js">

</script>



</html>

