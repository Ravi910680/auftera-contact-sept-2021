<?php
session_start();
$servername = "segment.cooou66jo1js.us-east-1.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="segment_list";

$seg_conn = mysqli_connect($servername, $username, $password,$db);

$seg_conn_data=mysqli_connect($servername,$username,$password,"segment_data");


function select_query($conn,$sel_query){


	$ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    

    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}


$unq_id=$_POST['seg_id'];


$ret_data=array();

$sel_seg_data="select * from seg_list where unq_id='$unq_id'";

$res_arr=select_query($seg_conn,$sel_seg_data);


$ret_data['seg_data']=$res_arr[0];

$sel_seg_fld_data="select * from seg_con where seg_id='$unq_id'";



$res_arr=select_query($seg_conn_data,$sel_seg_fld_data);

$ret_data['field']=array();

array_push($ret_data['field'], $res_arr);


print_r(json_encode($ret_data));

?>
