<?php
session_start();
require("../../confige/segment_confige.php");

require("../../confige/fileconfige.php");
$id=$_SESSION["id"];
$lst_name=$_SESSION["listname"];
$fin_seg_name=$_POST["seg_name"];
$segment_name=$id."^".$fin_seg_name;

$email_data=$_SESSION['email_seg_data'];

$td_date=date("Y-m-d");
$insrt_seg_data="insert into segment_data (id,list_name,date) values ('$segment_name','$lst_name','$td_date');";



if ($seg_conn->query($insrt_seg_data) === TRUE) { 


$arry_data=json_decode($email_data);

$segment_up_data="";
foreach ($arry_data as $key => $value) {
	$email_val=$value->email;
$segment_up_data=$value->segment.$segment_name.",";

$sql = "UPDATE `".$lst_name."` SET segment='$segment_up_data' WHERE email='$email_val'";


if ($conn3->query($sql) === TRUE) {

$flg_suc=1;


}





}












} else {
  $flg_suc=0;
}
echo $flg_suc;



?>
