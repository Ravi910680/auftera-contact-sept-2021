<?php
session_start();
$servername = "segment.cooou66jo1js.us-east-1.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="segment_list";

$seg_conn = mysqli_connect($servername, $username, $password,$db);

$seg_conn_data=mysqli_connect($servername,$username,$password,"segment_data");



function isrt_query_db($conn,$isrt_query){


if($conn->query($isrt_query) === TRUE){

return 1;

}else{
	return $conn->error;
}


}

function select_query($conn,$sel_query){


	$ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    

    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}

function del_query($conn,$query){



	if($conn->query($query)){
return 1;

	}else{

		return 0;
	}

}

function crt_isrt_query($seg_id,$arr_data){


$str_ret="";
for ($i=0; $i < count($arr_data); $i++) { 

	$loc_data=$arr_data[$i];
	$str_ret.="('".$seg_id."','".$loc_data[0]."','".$loc_data[1]."','".$loc_data[2]."','".$loc_data[3]."'),";

}

$str_ret=rtrim($str_ret, ", ");
return $str_ret;


}

function save_seg_field_db($usr_id,$seg_name,$dec_data,$seg_conn,$seg_conn_data){

$sel_query="SELECT unq_id from seg_list where id='$usr_id' and seg_name='$seg_name'";

$unq_id=select_query($seg_conn,$sel_query)[0]['unq_id'];


$del_query="DELETE FROM `seg_con` where seg_id='$unq_id'";


if( del_query($seg_conn_data,$del_query)==1){

$isrt_query="insert into seg_con (seg_id,field,cond,data,cond_val) values ".crt_isrt_query($unq_id,$dec_data->data_link);

if(isrt_query_db($seg_conn_data,$isrt_query)){

$ret_arr['status']=1;
$ret_arr['message']=$unq_id;
}else{


$ret_arr['status']=0;
$ret_arr['message']="Something Wen't Wrong";

}


}
return $ret_arr;
}


$jsn_data=$_POST['send_obj'];

$dec_data=json_decode($jsn_data);
$usr_id=$_SESSION['id'];
$seg_name=$_POST['seg_name'];
$date=gmdate("Y-m-d\TH:i:s\Z");



$isrt_name="insert into seg_list (id,seg_name,crt_date) value ('$usr_id','$seg_name','$date')";

$ret_arr=array("status"=>0,"message"=>"");


if(isrt_query_db($seg_conn,$isrt_name)==1){

$ret_arr['status']=1;
$ret_arr['message']=$unq_id;

}


$sel_query="SELECT unq_id from seg_list where id='$usr_id' and seg_name='$seg_name'";

$unq_id=select_query($seg_conn,$sel_query)[0]['unq_id'];


$del_query="DELETE FROM `seg_con` where seg_id='$unq_id'";



if(del_query($seg_conn_data,$del_query)==1){

$isrt_query="insert into seg_con (seg_id,field,cond,data,cond_val) values ".crt_isrt_query($unq_id,$dec_data->data_link);
if(isrt_query_db($seg_conn_data,$isrt_query)){

$ret_arr['status']=1;
$ret_arr['message']=$unq_id;
}else{


$ret_arr['status']=0;
$ret_arr['message']="Something Wen't Wrong";

}


}
print_r(json_encode($ret_arr));


?>
