<?php
session_start();



$servername = "segment.cooou66jo1js.us-east-1.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="segment_list";

$seg_conn = mysqli_connect($servername, $username, $password,$db);


$id=$_SESSION['id'];;



function select_query($conn,$sel_query){


	$ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    

    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}


$sel_query="select * from seg_list where id='$id'";

$res_data=select_query($seg_conn,$sel_query);

print_r(json_encode($res_data));



?>
