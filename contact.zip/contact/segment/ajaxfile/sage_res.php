<?php
session_start();

error_reporting(E_ALL);
error_reporting(-1);
ini_set('error_reporting', E_ALL);



$servername = "segment.cooou66jo1js.us-east-1.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="segment_list";

$seg_conn = mysqli_connect($servername, $username, $password,$db);

$seg_conn_data=mysqli_connect($servername,$username,$password,"segment_data");




if(isset($_GET['listname'])){
$lst_name=$_GET['listname'];


}else{

$lst_name=$_SESSION['listname'];
}


if(!isset($_GET['id'])){

	$id=$_SESSION["id"];

}else{

$id=$_GET['id'];
}
$camp_data_hy=array();

require("../../confige/managetag.php");


$array_of_tag = array();

$tag_tbl_name="tag".$id;
$select_tag = "select * from ".$tag_tbl_name;
$result = $mngtag->query($select_tag);


while($row = $result->fetch_assoc()) {


$temp_array[$row["tag"]]=$row["id"];


        array_push($array_of_tag,$temp_array);
    }






function get_date_wise_camp($date_camp){

$lst_name=$GLOBALS['lst_name'];
	$loc_array=array();
require("../../confige/camp_confige.php");
$get_camp_data="select * from camp_name_tbl where camp_shed_time>=".$date_camp." and camp_contact_id in(select camp_con_id from camp_contact_tbl where list_id='".$lst_name."')";



$result = $camp_name_conn->query($get_camp_data);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {

array_push($loc_array,$row["camp_contact_id"]);


  }
}



return $loc_array;



}





function get_para_for_conv($get_opt_val,$para_lable){





$camp_data_hy=$GLOBALS['camp_data_hy'];


$str_loc_src="(";


if($get_opt_val=="is replied"){

foreach ($camp_data_hy as  $value) {
  

$str_loc_src.=$value."=1 or";


}




  }else if ($get_opt_val=="no replied") {



foreach ($camp_data_hy as  $value) {
  

$str_loc_src.=$value."=2 or";


}



    
  }




  $str_loc_src=substr($str_loc_src, 0, -2);


return $str_loc_src;



}



function get_para_for_camp($camp_data_hy,$get_opt_val,$para_lable){




$str_loc_src="(";

if ($get_opt_val=="opened") {

foreach ($camp_data_hy as  $value) {
  

$str_loc_src.="(`".$value."`>3 or `".$value."`=2) or";


}


  
}else if ($get_opt_val=="click") {

  foreach ($camp_data_hy as $value) {
  

$str_loc_src.="(`".$value."`>4 or `".$value."`=2) or";


}

  
}else if ($get_opt_val=="was sent") {

  foreach ($camp_data_hy as $value) {
  

$str_loc_src.="(`".$value."`>2 or `".$value."`=2) or";


}

  
}else if ($get_opt_val=="did not open") {

  foreach ($camp_data_hy as  $value) {
  

$str_loc_src.="`".$value."`=3 or";


}
  
}else if ($get_opt_val=="did not click") {


foreach ($camp_data_hy as  $value) {
  

$str_loc_src.="`".$value."`!=5 or ";


}


  
}else if ($get_opt_val=="was not sent") {



  foreach ($camp_data_hy as  $value) {
  

$str_loc_src.="`".$value."`=0 or ";


}
  
}


$str_loc_src=substr($str_loc_src, 0, -3);


return $str_loc_src;

}

















function get_para_for_int($get_opt_val,$para_lable){

if($get_opt_val=="is equal to"){

return "='".$para_lable."'";

}else if ($get_opt_val=="is greater") {
  return ">'".$para_lable."'";
}else if ($get_opt_val=="is less") {
  return "<'".$para_lable."'";
}else if ($get_opt_val=="is not equal to") {
  return "!='".$para_lable."'";
}



}

function get_para_for_text($get_opt_val,$para_lable){


if($get_opt_val=="is match"){

  return "='".$para_lable."'";
}else if ($get_opt_val=="start with") {

  
return "LIKE '".$para_lable."%'";

  }else if ($get_opt_val=="find") {

    return "LIKE '%".$para_lable."%'";
  }else if($get_opt_val=="not contain"){

    return "!='".$para_lable."'";
  }
  



}


function get_date_of_val($get_opt_val){

if($get_opt_val=="any of 5 campign"){

$para_lable = date("Y-m-d", strtotime("-100 day"));

}else if($get_opt_val=="in last 7 day"){

$para_lable = date("Y-m-d", strtotime("-7 day"));

}else if ($get_opt_val=="in last 1 month") {
  $para_lable = date("Y-m-d", strtotime("-30 day"));
}else if ($get_opt_val=="in last 3 month") {
  $para_lable = date("Y-m-d", strtotime("-90 day"));
}

return $para_lable;

}


function get_sub_lable($get_lbl){

if($get_lbl=="subscribe"){
  return "1";
}else if($get_lbl=="un-subscribe"){ 
  return "2";
}else if ($get_lbl=="none-subscribe") {

return "3";
}else if($get_lbl=="bounced"){
  return "4";
}else if ($get_lbl=="VIP") {
  return "5";
}


}

function get_para_for_sub($get_opt_val,$para_lable){

$para_lable=get_sub_lable($para_lable);

if($get_opt_val=="is"){

return "='".$para_lable."'";


}else if ($get_opt_val=="is not") {
  

return "!='".$para_lable."'";

}


}


function get_para_for_cli($get_opt_val,$para_lable){

  if ($get_opt_val=="is") {
    
return "LIKE '%@".$para_lable."%'";

  }else if ($get_opt_val=="is not") {
    # code...


    return "NOT LIKE '%@".$para_lable."%'";

  }
}





function get_para_for_date($get_opt_val,$para_lable){







if($get_opt_val=="before date"){
return "<'".$para_lable."'";
}else if ($get_opt_val=="after date") {
  return ">'".$para_lable."'";
}else if ($get_opt_val=="before 2 day") {

  $para_lable = date("Y-m-d", strtotime("-2 day"));
return "<'".$para_lable."'";

  
}else if ($get_opt_val=="before 5 day") {



  $para_lable = date("Y-m-d", strtotime("-5 day"));
  
  return "<'".$para_lable."'";
}


}

function get_para_for_src($get_opt_val,$para_lable){

if($get_opt_val=="was"){

return " = '".$para_lable."'";

}else if ($get_opt_val=="not was") {
  return "!= '".$para_lable."'";
}

}




function find_operator_val($val_of_str){

$opt_val=explode("^", $val_of_str);
return $opt_val;




}







function get_para_for_tag($get_flg_tag,$get_tag_val,$temp_array_pass){











if($get_flg_tag=="is"){
	


return "LIKE '%".$temp_array_pass[$get_tag_val]."%'";



}else if($get_flg_tag=="is not"){
	

return "NOT LIKE '%".$temp_array_pass[$get_tag_val]."%'";

}



}


function get_para_for_gend($get_flg,$get_val){


if($get_val=='male'){
  $val='m';
}else{
  $val='f';
}




if($get_flg=="is"){
  


return "= '".$val."'";



}else if($get_flg=="is not"){
  

return "<> '".$val."'";

}



}
function select_query($conn,$sel_query){


  $ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    

    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}
















$seg_data=$_GET['seg_id'];
$sel_query="select * from seg_con where seg_id='$seg_data'";

$json_dec_data=select_query($seg_conn_data,$sel_query);




$last_str_src="";
for($i=0;$i<count($json_dec_data);$i++) {

  $value[0]=$json_dec_data[$i]['field'];
  $value[1]=$json_dec_data[$i]['cond'];
  $value[2]=$json_dec_data[$i]['data'];

  $cond_of_lst=$json_dec_data[$i]['cond_val'];
$get_row_val=find_operator_val($value[0]);
  $get_opt_lable=find_operator_val($value[1]);

  if($get_opt_lable[2]=="text"){
     
   

    $get_para_for_val=get_para_for_text($get_opt_lable[0],$value[2]);

    $last_str_src.=" (".$get_row_val[0]." ".$get_para_for_val.") ".$cond_of_lst;
  
  
  }else if($get_opt_lable[2]=="int"){


 $get_int_str=get_para_for_int($get_opt_lable[0],$value[2]);

$last_str_src.=" (".$get_row_val[0]." ".$get_int_str.") ".$cond_of_lst;
}else if($get_opt_lable[2]=="date"){




$get_date_str=get_para_for_date($get_opt_lable[0],$value[2]);







$last_str_src.=" (".$get_row_val[0]." ".$get_date_str.") ".$cond_of_lst;

}else if ($get_opt_lable[2]=="flg_cli") {

$get_cli_val=find_operator_val($value[2]);

  
$get_cli_str=get_para_for_cli($get_opt_lable[0],$get_cli_val[0]);

$last_str_src.=" (email ".$get_cli_str.") ".$cond_of_lst;

  }else if ($get_opt_lable[2]=="flg_src") {
    

$get_src_val=find_operator_val($value[2]);
$get_src_str=get_para_for_src($get_opt_lable[0],$get_src_val[0]);


$last_str_src.=" (source ".$get_src_str.") ".$cond_of_lst;
  }else if ($get_opt_lable[2]=="flg_sub") {
    

$get_sub_val=find_operator_val($value[2]);

$get_sub_str=get_para_for_sub($get_opt_lable[0],$get_sub_val[0]);


$last_str_src.=" (substatus ".$get_sub_str.") ".$cond_of_lst;


  }else if ($get_opt_lable[2]=="flg_camp") {





    $get_camp_val=find_operator_val($value[2]);

$geted_val_date=get_date_of_val($get_camp_val[0]);




    $get_camp_str=get_para_for_camp(get_date_wise_camp($geted_val_date),$get_opt_lable[0],$get_camp_val[0]);

    $last_str_src.=$get_camp_str.") ".$cond_of_lst;

  }else if ($get_opt_lable[2]=="flg_conv") {
    




    $get_conv_val=find_operator_val($value[2]);


    
    $geted_val_date=get_date_of_val($get_conv_val[0]);

get_date_wise_camp($geted_val_date);

    $get_conv_str=get_para_for_conv($get_opt_lable[0],$get_conv_val[0]);

    $last_str_src.=$get_conv_str.") ".$cond_of_lst;

  }else if($get_opt_lable[2]=="flg_tag"){

 $get_tag_val=find_operator_val($value[2]);

$get_tag_str=get_para_for_tag($get_opt_lable[0],$get_tag_val[0],$temp_array);


$last_str_src.=" (tag ".$get_tag_str.") ".$cond_of_lst;






  }else if($get_opt_lable[2]=='flg_gend'){


$get_gend_val=find_operator_val($value[2]);

$get_gend_str=get_para_for_gend($get_opt_lable[0],$get_gend_val[0]);


$last_str_src.=" (gender_pre ".$get_gend_str.") ".$cond_of_lst;

  }






};



$last_str_src="SELECT * from `".$lst_name."` where".$last_str_src;





echo $last_str_src." and arch=0";

?>


