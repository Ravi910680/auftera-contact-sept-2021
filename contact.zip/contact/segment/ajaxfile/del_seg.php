<?php


$servername = "segment.cooou66jo1js.us-east-1.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="segment_list";

$seg_conn = mysqli_connect($servername, $username, $password,$db);

$seg_conn_data=mysqli_connect($servername,$username,$password,"segment_data");



function del_query($conn,$query){



        if($conn->query($query)){
		
		echo "ddd";
		return 1;

        }else{
echo $conn->error;
                return 0;
        }

}



$seg_id=$_POST['seg_id'];

$res_arr=array("status"=>0,"message"=>"Something Wen't wrong");

$del_query_name="delete from seg_list where unq_id='$seg_id'";


if(del_query($seg_conn,$del_query_name)){

	$del_query="delete from seg_con where seg_id='$seg_id'";

echo $del_query;
	if(del_query($seg_conn_data, $del_query)){

$res_arr['status']=1;


	}

}

echo json_encode($res_arr);




?>
