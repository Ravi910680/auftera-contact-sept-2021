<?php
echo "ravi";


echo $_POST['acc_tok'];

echo $_POST['post_data'];

?>
