<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


$token=explode("#",$_POST['token']);
$str_id=explode("/",$token[0])[1];



$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.bigcommerce.com/stores/".$str_id."/v3/customers",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
    "x-auth-token: ".$token[1]
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);


$res_arr=array("status"=>0,"data"=>"");


if ($err) {

	$res_arr['status']=1;
	$res_arr['data']=$response;

} else {
  $res_arr['status']=0;
        $res_arr['data']=$response;


}

print_r(json_encode($res_arr));

?>
