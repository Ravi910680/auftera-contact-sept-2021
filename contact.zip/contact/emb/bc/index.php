<?php
session_start();


require("../vendor/autoload.php");

use Bigcommerce\Api\Client as Bigcommerce;


$text_of_link="How To Use It App";


if(isset($_GET['code'])){

	$code=$_GET['code'];
	$store_id=$_GET['context'];

if(isset($_SESSION['id'])){

$object = new \stdClass();
$object->client_id = 'kb75xl46w54lgu6428alnice0jgl6el';
$object->client_secret = '2608250f1d9cc9ea922e66b3af5c116d4e7a403f96250e0720650de3b1433396';
$object->redirect_uri = 'https://contact.auftera.com/contact/emb/bc/';
$object->code = $_GET['code'];
$object->context =$_GET['store_id'];
$object->scope = "store_v2_customers store_v2_default";

$authTokenResponse = Bigcommerce::getAuthToken($object);

$acc_tok=$authTokenResponse->context."#".$authTokenResponse->access_token;

require("../../confige/multi_src_conn.php");
$id=$_SESSION['id'];



$date=date("Y-m-d H:i:s");

$sel_query="delete from multi_soc_acc where id='$id' and app_id='bc'";
$res=$multi_soc_conn->query($sel_query);


$sql = "INSERT INTO multi_soc_acc (id, acc_tok, add_date,app_id) VALUES ('$id', '$acc_tok', '$date','bc')";


if ($multi_soc_conn->query($sql) === TRUE) {


	header("Location: https://contact.auftera.com/contact/emb/");

}





}else{



	$text_of_link="Login To Auftera";
	$link_of_log="../emb/bc/?code=".$code."&context=".$store_id;
 $link_of_log="https://account.auftera.com/account/login/?path=contact&auta_back=".urlencode($link_of_log);


}

}


?>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


<style type="text/css">

.con-fb-connect {
    padding-top: 10%;
    height: 100vh;
    overflow: scroll;
}
.card-img-top{
  
  margin: auto;
  height: 64px;
  width: 64px;
}


.card{
padding-top: 20px;
    padding-bottom: 20px;


     }
  img.list-img-right {
    height: 36px;
    padding-right: 30px;
  }





.bottom-btn{
  text-align: center;
    height: 40px;
    background: #4a154bd9;
    color: white;

    font-size: 13px;
    border-radius: 4px;
    border:1px solid  #4a154bd9;
   width:100%;
    padding-left: 20px;
    padding-right: 20px;
}


.bottom-btn:hover{
        cursor: pointer;
}


</style>
<script type="text/javascript">





</script>
<?php require("../ajaxfile/common_style.php");?>
<div class='con-fb-connect'>

<div class="card" style="width: 30rem;margin:auto;">
  <img class="card-img-top" src="https://res.cloudinary.com/heptera/image/upload/v1631980989/dropbox_1_hjr4wp.png"  alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Connect DropBox Account</h5>
    <p class="card-text">DropBox connect Use for get file from dropbox easily.</p>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Get All file List on heptera</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Select file option that use</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Add Contact Directly From File</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Add Image In heptera</li>

     </ul>
  <div class="card-body">
  <a href='<?php echo $link_of_log;?>' id="authlink" class="bottom-btn" target="_blank"><?php echo $text_of_link;?></a>  </div></div>

</div>


<script src="../ajaxfile/utils.js"></script>







