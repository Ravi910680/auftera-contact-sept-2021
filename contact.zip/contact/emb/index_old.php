<?php


if(isset($_GET['url_red'])){


$url_red=$_GET['url_red'];

header('Location: '.$url_red);

}

?>




 <style>
.button-select-file{
    
}




.fad {
    color: orange;


}


i.fad.fa-file-csv {
    color: darkblue;

}

#custom-button {
  width:10%;
  color: black;
  background-color: #f2f2f2;
  
  
  cursor: pointer;
}

#custom-button:hover {
  background-color: f;
}

#content-name {
   
    width:40%;
    border:1px solid rgba(36,28,21,0.3);
  margin-left: 10px;
  font-family: sans-serif;
  letter-spacing:0.5px;
  color: #aaa;
  padding:10px;
}
.click_to_go_con:hover{
cursor:pointer;
}

    </style>    

<script>



</script>




















<?php
session_start();

    $mail=$_SESSION["email"];
    $id=$_SESSION["id"];

require("../confige/multi_src_conn.php");




require("../confige/fileconfige.php");


$append_in_not_add_str="<div class='row' style='width:100%;'>";


$selectsite="SELECT * FROM filedetails WHERE id='$id'";
$selectedurl = $conn2->query($selectsite);

$str_of_lable="";
if ($selectedurl->num_rows > 0) {
        while($row = $selectedurl->fetch_assoc()) {
                $filename=explode("^",$row['filename']);
         $name_of_file=base64_decode($filename[1]);



$str_of_lable.="<option class='opt_on_list mngc dropdown-item' value='".$row['filename']."'  style=''>".$name_of_file."</option>";



}


}





$data_user=array();

require("../confige/conn_part.php");

$sql_for_part = "SELECT * FROM part_lst";
$result_part = $conn_part->query($sql_for_part);
$loc_rw=array();
$append_in_add_str="";


$flg_fr_con=0;
  // output data of each row
  while($row = $result_part->fetch_assoc()) {


	 

$loc_rw[$row['part_id']]=$row;	





$part_id_var=$row['part_id'];


$sql = "SELECT * FROM multi_soc_acc WHERE id='$id' and app_id='$part_id_var' LIMIT 1";


$result=$multi_soc_conn->query($sql);





if($result->num_rows > 0 || ($part_id_var=='ig' && $fb_part_flg==1)){


$fetch_data=$result->fetch_assoc();


$data_user[$part_id_var]=$fetch_data['acc_tok'];







$head_str="<div class='rem_api_token' style='text-align: right;'><i data-toggle='modal' id='".$fetch_data['acc_tok']."' data-target='#del_app_from_part' app_tp_del='".$part_id_var."' class='fal fa-times rem_api_token_ico' aria-hidden='true'></i></div>";

        if($row['part_id']=="fb" || $row['part_id']=="tw"){

$head_str="<div class='rem_api_token row' style='text-align: right;'><div class='main_emb_para click_to_go_con' id='".$row['part_id']."' style='width: 50%;text-align: left;'>Add Other Account</div><div style='width: 50%;'><i data-toggle='modal' id='".$fetch_data['acc_tok']."' app_tp_del='".$part_id_var."' data-target='#del_app_from_part' class='fal fa-times rem_api_token_ico' aria-hidden='true'></i></div></div>";
        }





if($part_id_var=='fb'){

$fb_part_flg=1;

}


$flg_fr_con=1;
  $append_in_not_add_str.="<div class='main_con_of_emb'>".$head_str."<div class='row' ><div class='main_ico_emb'><img class='img-of-con-crd' src='https://res.cloudinary.com/heptera/image/upload/".$row['part_logo']."' height='72'></div><div class='main_txt_emb'><h3>".$row['part_name']."</h3><p class='main_emb_para'>".$row['part_desc']."</p></div></div><button class='bottom-btn use_it_app' id='".$row['part_id']."' style='background: #5a0c49;color:white;' data-toggle='modal'  data-target='#use_it_app_mod'>Open ".$row['part_name']."</button></div>";

if($row['part_id']=="dp"){
 echo "<script src='https://cdn.jsdelivr.net/npm/promise-polyfill@7/dist/polyfill.min.js'></script><script src='https://cdnjs.cloudflare.com/ajax/libs/fetch/2.0.3/fetch.js'></script><script src='https://unpkg.com/dropbox/dist/Dropbox-sdk.min.js'></script>";
}





}else{







$append_in_add_str.="<div class='main_con_of_emb'><div class='row'><div class='main_ico_emb'><img class='img-of-con-crd'  src='https://res.cloudinary.com/heptera/image/upload/".$row['part_logo']."' height='64'></div><div class='main_txt_emb'><h3>".$row['part_name']."</h3><p class='main_emb_para'>".$row['part_desc']."</p></div></div><button class='bottom-btn click_to_go_con'  id='".$row['part_id']."'    >Connect</button></div>";
    
  


}







  }
$append_in_not_add_str.="</div>";
$json_part_arr=json_encode($loc_rw);











?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">
  <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />
  


  <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1603531914/norm_used/loader_ww3kih.css">

  <link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css">
<style>

@import url(https://fonts.googleapis.com/css?family=Arvo);
@import url(http://fonts.googleapis.com/css?family=Varela+Round);
.hover-bottom:hover{
    border-bottom:1px solid white;

}
.card-hover:hover{
    background:#f2f2f2;
  cursor: pointer;
}


.rem_api_token {
    text-align: center;
color: #c7c2c2;


}
.rem_api_token_ico:hover{
cursor: pointer;
color: #6f6d6d;
}







.follo span {
    padding-right: 6px;
    color: black;
    font-weight: 700;
    padding-left: 10px;
}



.follo {
    padding: 10px;
    color: #8c7c7c;
    padding-top: 0px;
    font-weight: 500;


}











h3.rem_mod_name {
    padding-top: 10px;
    color: black;

}






#main-loader-containre-act{


    text-align: center;
    padding-top: 41vh;
  }

.main-loader-containre-act{
  text-align: center;padding-top: 41vh;height: 84vh;
}


img.img-of-con-crd {
    padding: 15px;

box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;


   border-radius: 20px;
}
img.img_mod_data_app {
    height: 100%;
    padding: 5px;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    border-radius: 15px;
}


.fa-add{
    padding:20px;
        font-size: 100px;
    margin: 0 auto;
}

i.fas.fa-flag-alt {
    font-size: 20px;
    padding: 10px;
    color: orange;

}


.tablediv{
    padding:10%;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;

}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
#loader {
  position: absolute;
  
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: 0 auto;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
.unique-name:focus{
    border:2px solid;
}

.file-upload{display:block;text-align:center;font-family: Helvetica, Arial, sans-serif;font-size: 12px;}
.file-upload .file-select{display:block;border: 2px solid #dce4ec;color: #34495e;cursor:pointer;height:40px;line-height:40px;text-align:left;background:#FFFFFF;overflow:hidden;position:relative;}
.file-upload .file-select .file-select-button{background:#dce4ec;font-weight:900;font-size:15px;padding:0 10px;display:inline-block;height:40px;line-height:40px;}
.file-upload .file-select .file-select-name{line-height:40px;display:inline-block;padding:0 10px;}
.file-upload .file-select:hover{border-color:#34495e;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload .file-select:hover .file-select-button{background:#34495e;color:#FFFFFF;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload.active .file-select{border-color:#3fa46a;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload.active .file-select .file-select-button{background:#3fa46a;color:#FFFFFF;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload .file-select input[type=file]{z-index:100;cursor:pointer;position:absolute;height:100%;width:100%;top:0;left:0;opacity:0;filter:alpha(opacity=0);}
.file-upload .file-select.file-select-disabled{opacity:0.65;}
.file-upload .file-select.file-select-disabled:hover{cursor:default;display:block;border: 2px solid #dce4ec;color: #34495e;cursor:pointer;height:40px;line-height:40px;margin-top:5px;text-align:left;background:#FFFFFF;overflow:hidden;position:relative;}
.file-upload .file-select.file-select-disabled:hover .file-select-button{background:#dce4ec;color:#666666;padding:0 10px;display:inline-block;height:40px;line-height:40px;}
.file-upload .file-select.file-select-disabled:hover .file-select-name{line-height:40px;display:inline-block;padding:0 10px;}
.emb_con:hover{
border-color:#007c89 !important;
}
</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
 
<link href="../../fa-fold/css/all.css" rel="stylesheet">


<script type="text/javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
  <!-- Icons -->
  

 
 
  <!-- CSS Files -->


</head>
<div id="c"></div>
<body class="" style="background:#fff;">
  <div style="height:93vh">
  <?php require("../confige/header/header.php");?>

<nav class="navbar navbar-dark" style="background:white;height:7vh;top:8vh;border-bottom: 1px solid #ebeaeb;padding:10px;top:8vh;">
<div style="width:100%"><span style="float-left"><a class=" hover-bottom" href="/main/addcontact/" style="color:#4a154bd9;font-weight:900;">Return to dashboard</a></span>
</div></nav>

<style>
.main_con_of_emb {
    padding: 10px;
    width: 30%;
    border: 1px solid #c3c0c3;
    border-radius: 10px;
    margin-right: 1.11%;
    margin-left: 1.11%;
    margin-top: 20px;
}
.main_ico_emb{
  width:fit-content;
  padding:10px;
}
.row{
margin:0px;
}





.lds-color div{

border: 2px solid #4a154bd9 !important;border-color: #4a154bd9 transparent transparent transparent !important;

}


.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid white;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

i.fad.fa-at {
    color: blueviolet;

}


.bottom-btn i{

padding-left:10px;

}



.file_data_hand.row {
    padding: 10px;
    border-bottom: 1px solid #ebeaeb;
    color: #5f285a;
    font-weight: 500;
    }

    .logo_fl_con {
    padding: 3px;
    width: 10%;

    }

    .cont_of_fl_name {
    width: 60%;
    font-weight: 500;
    font-size: 14px;
    color: #8c7c7c;
    text-align: left;
    padding: 3px;

    }

    .opt_of_work {
    width: 30%;

    }

















.head_mod{
width:50%;
padding:10px;

}






.bottom-btn{
  

  text-align: center;
    height: 40px;
    background: white;
    color: #4a154bd9;
    font-size: 15px;
    border-radius: 4px;
    border: 1px solid #4a154bd9;
    width: 100%;
    padding-left: 20px;
    padding-right: 20px;
    font-family: 'Lato', sans-serif;
    font-size: 13px;
}


.bottom-btn:hover{
	cursor: pointer;
}
.main_emb_para{
font-size: 0.8rem;
    font-weight: 500;
    color: #8c7c7c;
    margin-bottom: 0px;
}

.main_txt_emb{
width:250px;

color:black;
 padding:10px; 
}

.mod_ico_data_part {
    width: 50%;
}


.select_lst_data {
    width: 50%;

}

.sel_main_app{


color: black !important;
    border: 1px solid #868686;
    font-weight: 600;

}
.sel_main_app:focus{

border:1px solid #868686;

box-shadow: rgb(18, 90, 163) 0px 0px 0px 1px, rgba(29, 155, 209, 0.3) 0px 0px 0px 5px;

}

.modal_res_connect {
    padding: 20px 0px;

}

.main_txt_emb h3{
color:black;

}




.con-of-img {
    width: fit-content;
    margin: auto;
    border-radius: 40px;
    box-shadow: rgb(0 0 0 / 24%) 0px 3px 8px;

}

span.cust-count {
    color: #106d1c;
    font-weight: 900;
    border-radius: 10px;
    box-shadow: rgb(0 0 0 / 5%) 0px 6px 24px 0px, rgb(0 0 0 / 8%) 0px 0px 0px 1px;
    padding: 10px;
}
span.cust-txt {
    color: black;
    font-weight: 700;
    padding-left: 10px;
    font-size: 19px;
}
.not-of-add {
    font-size: small;
    margin-top: 10px;
    color: grey;
    margin-bottom: 10px;
}

img.img-hndl-cls {
    width: 100px;
    padding: 20px;
}


.modal-content {
    height: 100vh;
  
    border-radius: 0px;
    border-top-left-radius: 20px;
    border-bottom-left-radius: 20px;

}
.modal-dialog.modal-dialog-centered {
    margin: 0px;
    margin-left: auto;
}

.modal-header {
    box-shadow: rgb(0 0 0 / 10%) 0px 4px 6px -1px, rgb(0 0 0 / 6%) 0px 2px 4px -1px;
}


.modal-body{
padding:0px;

position: relative;
}

.not_of_data {
    position: absolute;
    bottom: 0;
    width: 100%;
border-top: 1px solid #f2f2f2;
    overflow: hidden;
}
button.btn_of_act {
    background: #540a47;
    font-size: 13px;
    border-radius: 5px;
    color: white;
    padding: 5px 15px;
    border: none;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    margin-right: 20px;
}








.vert-cent-div {
  width: min-content;
  height: min-content;
  text-align: center;

  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;

  margin: auto;
}

.info-err-img{
  height: 200px;
}


.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000b5;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
    z-index: 100000000;
}

#cncl-err-msg:hover{


cursor: pointer;


}





.sel_main_app:hover{

cursor:pointer;

}

button:hover{
cursor:pointer;
}






.bottom-btn{
border-radius:50px;
}











</style>



<?php


if($flg_fr_con){
?>




<div id="main-loader-containre">


<div class="main-content row" style="margin:40px;top:8vh;">
<p class="main_emb_para" style="width: 100%;
    "
>Installed App</p><br>


<?php echo $append_in_not_add_str;?>


      
    </div> 




<?php

}
?>


















<div class="main-content row" style="margin:40px;top:8vh;">
<p class="main_emb_para" style="width: 100%;
    "
>Reccomended App</p><br>


<?php echo $append_in_add_str;?>


      
    </div>        



</div>
</body>
<div class="res">
</div>


<div id="del_app_from_part" class="modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="exampleModalCenterTitle" style="
    color: #4a154bd9;
">Disconnect App</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><i  class="fal fa-times" ></i></span>
        </button>
      </div>
      <div class="modal-body" style="text-align:center;display: table;">
        
<div style="
    display: table-cell;
    vertical-align: middle;
">
<div class="mod_des_val" style="
    width: 50%;
    margin: auto;
">
          
          <img src="" class="img_rem_mod" height="72">
          
    <h3 class="rem_mod_name"></h3>

<p class="main_emb_para rem_mod_desc"></p>

      
    
    
          </div>




<button class="btn-theme-dsg rem_mod_sub_btn" style="width:auto;min-width:300px;margin:auto;margin-top:10px;">Disconnect App</button>
      </div>
      

    </div>
  </div>
</div>

</div>





<style>
.modal.show{
right:0px;
transition:.5s;
}



</style>






<div id="use_it_app_mod" class="modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display:none; padding-left: 0px;" aria-modal="true">
  <div class="modal-dialog modal-dialog-centered" role="document" style="
    min-width: 700px;
">
    <div class="modal-content" style="
    min-height: 600px;
">
      <div class="modal-header" style="";>
        <h3 class="modal-title" id="exampleModalCenterTitle" style="
    color: #3c3535;
    font-size: 14px;
">Use It App</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><i class="fal fa-times" aria-hidden="true"></i></span>
        </button>
      </div>
     


      <div class="modal-body" style="height: 530px;text-align:center;">

    <div class="mod_act_head row" style="
    text-align: left;
    padding: 20px;
height:88px;
">
    <div class="mod_ico_data_part">
    <img src="https://res.cloudinary.com/heptera/image/upload/v1592640972/iconfinder_38_939833_jgcojl.png" class="img_mod_data_app" height="48" style="
    display: inline-block;
"><h3 style="
    display: inline-block;
    padding: 0px 10px;
" class="app_name_mod">DropBox</h3>
        

    </div>
    
    
    <div class="select_lst_data">
    
         <select class="form-control sel_main_app" id="exampleFormControlSelect1" style="
    height: 40px;
   
   ">
      <?php echo $str_of_lable;?>
    </select>
    
    </div>
    </div>

<div class="head_of_act_mod" style="height:50px;"></div>

<div class="modal_res_connect" style="height:58vh;overflow: scroll;"></div>
      
     <div class="not_of_data" style="padding:10px;height:40px;"><p class="main_emb_para"><i class="fad fa-sticky-note" style="
    color: red;
    padding-right: 10px;
"></i>If You Added Contact From Cloud Please Select List Above.</p></div> 
</div>
    </div>
  </div>
</div>
















<div class="vert-cent-div err-menu-cls-dsg" id="err_msg_dt_trg" style="display: none;position: fixed;">
<span id="con-of-err-msg"></span>
<span class="cls-err-menu" id="cncl-err-msg">
<i class="fal fa-times-circle" style="
    padding: 6px;
"></i>
</span>
</div>





































<style>

.form-check-input{
width: 15px;
    height: 15px;
}
img.insta_pro_pic {
    border-radius: 50%;
  
}

</style>




 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>
  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
  <script>


  </script>
<script>

part_js_data='<?php echo $json_part_arr;?>';

json_dec_part=JSON.parse(part_js_data);




id_usr="<?php echo $id;?>";






















$(document).on("change",".sel_main_app",function(){
type_opr=$(this).val();

  
      
     console.log(type_opr);
    $.ajax({
                url : "../ajaxfile/crtseslist.php",
                type: "POST",
                data : "requestoflist="+type_opr
        }).done(function(response){ 
        

        });
  
});


























access_gc_token="";














$(document).on("click",".use_it_app",function(){


$(".head_of_act_mod").empty();
$(".modal_res_connect").html("<div class='lds-ring lds-color'  style=''><div></div><div></div><div></div><div></div></div>");



get_id_use=$(this).attr("id");
init_head_mod_data(get_id_use);
if(get_id_use=="dp"){
	
init_dropbox_data_mod();

}else if(get_id_use=="gc"){





init_google_c_mod();














}else if(get_id_use=="fb"){




init_fb_in_mod();



}else if(get_id_use=="ig"){



insta_connect_face();


}else if(get_id_use=="tw"){



	tw_init_mod_data();


}else if(get_id_use=="sp"){


init_sp_shop_data();

}else if(get_id_use=="tf"){


	init_tf_data();

}

})



	//tf api start
	//
	//
	//
	//
	//
	//








access_tf_token='<?php echo $data_user['tf']  ?>';





function init_tf_data(){




$.ajax({
                url : "./tf/ajaxfile/get_all_form_list.php?acc_tok="+access_tf_token,
                type: "GET"
        }).done(function(response){ 

console.log(JSON.parse(response));

init_str_of_tf_data(JSON.parse(response));


        });
      




}

function init_str_of_tf_data(jsn_data){


str_of_app="";

for (var i = 0; i < jsn_data.total_items; i++) {

loc_arr=jsn_data['items'][i];

date=new Date(loc_arr['last_updated_at']);
app_dt_str=date.toUTCString();

str_of_app+='<div class="file_data_hand row"><div class="logo_fl_con" style=" "><img src="https://res.cloudinary.com/heptera/image/upload/v1624689789/addcontact/forms_vjhehr.png" style=" height: 48px; padding: 10px; "></div><div class="cont_of_fl_name" style="color: black;font-weight: 800;">'+loc_arr['title']+'<br><p class="main_emb_para">'+app_dt_str+'</p></div><div class="opt_of_work" style=" padding: 12.5px; "><button class="btn_of_act btn_act_tf_add_con "  style="height: auto;border: none;" form_name_def="'+loc_arr['title']+'" form_id="'+loc_arr['id']+'">Sync All Contact<i class="fad fa-long-arrow-right" aria-hidden="true" style=" padding-left: 15px; "></i></button> </div></div>';
};


$(".modal_res_connect").html(str_of_app);




}








$(document).on('click','.btn_act_tf_add_con',function(){


	ld_app_in_btn(this);

frm_id=$(this).attr('form_id');
lst_name_to_add=$("#exampleFormControlSelect1").val();
frm_name=$(this).attr("form_name_def")



$.ajax({
                url : "./tf/ajaxfile/get_all_contact_sync.php",
                type: "POST",
                data:{form_id:frm_id,list_name:lst_name_to_add,form_name:frm_name,acc_token:access_tf_token}
        }).done(function(response){ 

res_data=JSON.parse(response);
if(res_data.status && res_data.email_cnt>0){

window.location=res_data.red_url;

}else{

	err_msg_data("Not Contained Any Email Response");

}
app_txt_btn($('[form_id="'+frm_id+'"]'));
        });
      



})






















	//tf api end































	//shopify ajaxdata
	//
	//
	//
	//






	function init_sp_shop_data(){


access_sp_token='<?php echo $data_user['sp'];?>';


$.ajax({
  type: "POST",
  url: "./sp/ajaxfile/get_cust_count.php",
  data: {query:"accepts_marketing",val:"true",acc_tok:access_sp_token}
}).done(function(response1) {

	console.log(response1);
jsn_data=JSON.parse(response1);

if(jsn_data['status']==1){
str_app='<div class="shopify_con-cust-handl"> <div class="con-of-img"><img class="img-hndl-cls" src="https://res.cloudinary.com/heptera/image/upload/v1622182177/addcontact/customer_vvelzc.png"></div><br><span class="cust-count">'+jsn_data['cust_cnt']+'</span><span class="cust-txt">Active Custemer</span><br><div class="not-of-add">Click below button to add your shopify <br>custemer as contact in upper selected list</div><br> <button class="bottom-btn"i id="add_con_req_sp" style="background:#4a154bd9;color:white;width: auto;border-radius: 50px;box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px">Add Custemer As Contact</button> </div>';


$(".modal_res_connect").html(str_app);
}else{

	not_found_data('sp');

}

});





	}



$(document).on('click',"#add_con_req_sp",function(){
ld_app_in_btn("#add_con_req_sp");
	lst_add_req=$("#exampleFormControlSelect1").val();

$red_url='https://contact.auftera.com/contact/ajaxfile/crtseslist.php?requestoflist='+lst_add_req+'&red_url=https://contact.auftera.com/contact/select_opt/';

window.location.href=$red_url;

})

















function init_head_mod_data(app_id){
    

$(".img_mod_data_app").attr("src","https://res.cloudinary.com/heptera/image/upload/"+json_dec_part[app_id]['part_logo']);

$(".app_name_mod").html(json_dec_part[app_id]['part_name']);


}














function init_google_c_mod(){

access_gc_token='<?php echo $data_user['gc'];?>';


 $.get("https://www.google.com/m8/feeds/contacts/default/thin?alt=json&access_token=" +access_gc_token + "&max-results=500&v=3.0",
                function(response){
			//process the response here
			//
			//
			//



                  console.log(response.feed.entry[0].gd$email[0]);
	       
	init_gc_mod_con(response.feed.entry);
	
	
		}).fail(function() {






not_found_data("gc");

});
}



obj_ml_lst_all=[];
str_of_gc_dt=""





function init_gc_mod_con(get_data_con){
console.log(get_data_con);

$(".head_of_act_mod").html("<div class='data_email_act row' style='height: 50px;'><div class='cont_of_fl_name head_mod'><input class='form-check-input' type='checkbox' value='true' id='sel_all_chk' style=' margin: 0px; '></div><div class='cont_of_fl_name head_mod'><button class='btn_of_act add_all_con_gc' style=' float: right; '>Add Contact <svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-person-plus' viewBox='0 0 16 16' style=' margin-left: 10px; '> <path d='M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H1s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C9.516 10.68 8.289 10 6 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z'></path> <path fill-rule='evenodd' d='M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5z'></path> </svg></button></div></div>");
for ( j = 0; j < get_data_con.length; j++) {


try{



loc_arr={};

loc_arr['email']=get_data_con[j].gd$email[0].address;
obj_ml_lst_all.push(loc_arr);

str_of_gc_dt+="<div class='file_data_hand row'><div class='opt_of_work' style='width: fit-content;'><div class='form-check'><input class='form-check-input stat_up_main_dt' type='checkbox' id='"+get_data_con[j].gd$email[0].address+"'></div></div><div class='logo_fl_con'><i class='fad fa-at'></i></div><div class='cont_of_fl_name'>"+get_data_con[j].gd$email[0].address+"</div></div>";
}catch (err){



}




	};


json_str_all_st=JSON.stringify(obj_ml_lst_all);

console.log(json_str_all_st);

$(".modal_res_connect").html(str_of_gc_dt);


str_of_gc_dt=""

}





$(document).on("click",".add_all_con_gc",function(){


ld_app_in_btn(".add_all_con_gc");



jsn_str_sel_con_gc();

});



function sel_all_fun_chk(id_of_follo,ip_that_follo){
stat_of_sel=$("#"+id_of_follo).val();
if(String(stat_of_sel) == "true"){
	                $("#"+id_of_follo).val(false);
stat_dec=true;

}else{
console.log("rrr");
         $("#"+id_of_follo).val(true);

stat_dec=false;
}
	$('.'+ip_that_follo).map(function() {


		$(this).prop("checked",stat_dec);

		

	})
}
$(document).on('click','#sel_all_chk',function(){

sel_all_fun_chk("sel_all_chk","stat_up_main_dt");

});

function all_is_checked(){
flg_ret=true;
	$('.stat_up_main_dt').map(function() {

		if(!$(this).is(":checked")){

			flg_ret=false;
		}

	})

return flg_ret;
}


$(document).on('click','.stat_up_main_dt',function(){


	console.log(all_is_checked());
	if(all_is_checked()){

$("#sel_all_chk").prop("checked",true);
$("#sel_all_chk").val('false');
	}else{

		$("#sel_all_chk").prop("checked",false);

		$("#sel_all_chk").val('true');
	}


});

function jsn_str_sel_con_gc(){

jsn_str_of_select_con=[];
flg_sel_con_cnt=0;
$('.stat_up_main_dt').map(function() {

flg_sel_con_cnt=1;

loc_arr={}	

  if($(this).is(":checked")){
loc_arr['email']=$(this).attr('id');
jsn_str_of_select_con.push(loc_arr);

  }




})


	if(jsn_str_of_select_con.length>0){
	send_req_gc_ses(JSON.stringify(jsn_str_of_select_con));


}else{
err_msg_data("Please Select Contact");
	app_txt_btn(".add_all_con_gc");

}

}





function not_found_data(app_id){
    
$(".modal_res_connect").html("<button class='bottom-btn click_to_go_con' style='width:fit-content;margin: 20px 0px;background: #4a154bd9;color: white;' id='"+app_id+"'>Connect Once Again</button>");


}




































function send_req_gc_ses(json_dt){



$.ajax({
  type: "POST",
  url: "./gc/ajaxfile/save_con_ses_gc.php",
  data: {json_str:json_dt}
}).done(function(response1) {

      window.location ='./../select_opt/';
    
  



});




}














access_dp_token="";




function init_dropbox_data_mod(){

file_arr_data=[];

$(".head_of_act_mod").html("");

access_dp_token='<?php echo $data_user['dp'];?>';

var dbx = new Dropbox.Dropbox({ accessToken: access_dp_token });
      dbx.filesListFolder({path: ''})
        .then(function(response) {



		
		
		
		
		console.log(response.result);
		
file_data=response.result.entries;
		
		for(i=0;i<file_data.length;i++){
loc_data_arr=[];
			if(file_data[i].path_lower.match(/.(jpg|jpeg|png|gif)$/i)){

				loc_data_arr[0]=file_data[i].name;
				loc_data_arr[1]="image";
 loc_data_arr[2]=file_data[i].id;
 loc_data_arr[3]=file_data[i].path_lower;
file_arr_data.push(loc_data_arr);
			}else if(file_data[i].path_lower.match(/.(csv)$/i)){

loc_data_arr[0]=file_data[i].name;
                                loc_data_arr[1]="csv";
loc_data_arr[2]=file_data[i].id;

loc_data_arr[3]=file_data[i].path_lower;


file_arr_data.push(loc_data_arr);



			}








		}


         console.log(file_arr_data);

file_init_img_db_data(file_arr_data);


	})
        .catch(function(error) {
          console.error(error);
        });

}









str_of_ing_dt="";

function file_init_img_db_data(arr_of_data){
	
for(i=0;i<arr_of_data.length;i++){
	console.log(arr_of_data[1]); 
if(arr_of_data[i][1]=="image"){
str_of_ing_dt+="<div class='file_data_hand row'><div class='logo_fl_con'><i class='fad fa-images'></i></div><div class='cont_of_fl_name'>"+arr_of_data[i][0]+"</div><div class='opt_of_work'><button class='bottom-btn down_ld_dp_fl' style='height: auto;border: none;width:auto;' data-name='"+arr_of_data[i][0]+"' data-path='"+arr_of_data[i][3]+"' >Add to Studio<i class='fad fa-long-arrow-right' aria-hidden='true'></i></button> </div></div>";

}else{


str_of_ing_dt+="<div class='file_data_hand row'><div class='logo_fl_con'><i class='fad fa-file-csv'></i></div><div class='cont_of_fl_name'>"+arr_of_data[i][0]+"</div><div class='opt_of_work'><button class='bottom-btn down_csv_fl_ld' style='height: auto;border: none;' data-name='"+arr_of_data[i][0]+"' data-path='"+arr_of_data[i][3]+"' >Add to Contact<i class='fad fa-long-arrow-right' aria-hidden='true'></i></button> </div></div>";

}


}
console.log(str_of_ing_dt);

$(".modal_res_connect").html(str_of_ing_dt);
str_of_ing_dt="";
}










$(document).on("click",".down_ld_dp_fl",function(){



ld_app_in_btn(this);

path_dt=$(this).attr("data-path");
path_name=$(this).attr("data-name");


$.ajax({
  type: "GET",
  url: "https://img.<?php echo $url_main;?>/save_dp_fl.php",
  data: {fl_path:path_dt,fl_name:path_name,acc_tok:access_dp_token,id:id_usr}
}).done(function(response1) {

app_txt_btn($('[data-path="'+path_dt+'"]'));

res_data=JSON.parse(response1);

       err_msg_data(res_data.message);    
  



});




});





$(document).on("click",".down_csv_fl_ld",function(){
$(this).html("<div class='lds-ring lds-color'  style=''><div></div><div></div><div></div><div></div></div>");	


lst_name=$("#exampleFormControlSelect1").val();

path_dt=$(this).attr("data-path");


$.ajax({
  type: "POST",
  url: "./dp/ajaxfile/dl_csv_fl.php",
  data: {fl_path:path_dt,acc_tok:access_dp_token}
}).done(function(response1) {

       console.log(response1); 


$.ajax({
  type: "POST",
  url: "../addconfile/subfileact.php",
  data: {frm:"dp",lst_name:lst_name}
}).done(function(response1) {

console.log(response1);
if(response1==0){
	
window.location ='./../select_opt/';
}



   
   
});




    
 
});


})










$(document).on("click",".click_to_go_con",function(){


id_dis_tp=$(this).attr("id");

window.location.href="./"+id_dis_tp+"/";

      

        });









//twitter api
//
//
//




access_gc_token='<?php echo $data_user['tw']  ?>';


function tw_init_mod_data(){

$.ajax({
                url : "./tw/get_pro_det.php",
                type: "POST",
                data : "tw_token="+access_gc_token
        }).done(function(response){
jsn_tw_data=JSON.parse(response);

$(".modal_res_connect").html("<img src='"+jsn_tw_data.pro_pic_tw+"' height='64' class='insta_pro_pic'/><br><h3 style='color:black;padding:10px;'>"+jsn_tw_data.tw_name+"</h3><div class='follo'><span class='cust-count'>"+jsn_tw_data.flw+"</span> following <span class='cust-count'>"+jsn_tw_data.flr+"</span> followers</div><button class='bottom-btn com-for-lnk' data-for-serv='1' data-path-ses='social/' data-target-link='https://social.auftera.com/social/' style='width:fit-content;background: #4a154bd9;color: white;' >Create Post</button>");

console.log(jsn_tw_data);
        });




}




//twitter end






























//facebook api 


access_fb_token='<?php echo $data_user['fb'];?>';

access_ig_token='<?php echo $data_user['ig'];?>';



page_fb_data=[];





function init_fb_in_mod(){

$.get(`https://graph.facebook.com/v7.0/me?fields=id&access_token=${access_fb_token}`)
            .then((response) => {

	    console.log(response.id);




init_fb_in_page_mod(response.id);



            })



}


function init_fb_in_page_mod(id_acc){

console.log(id_acc);


$.get(`https://graph.facebook.com/v7.0/${id_acc}/accounts?access_token=${access_fb_token}`)
            .then((response) => {
console.log(response);
	   page_fb_data=response.data;
	  init_modal_fb_page_pub(response.data);



            })



}


function init_modal_fb_page_pub(data_page){
	str_of_app="";
$(".head_of_act_mod").html("");
	if(data_page.length>0){
 for(k=0;k<data_page.length;k++){
	 pg_name=data_page[k].name;
	 cat_of_page=data_page[k].category;
                   
	 str_of_app+="<div class='file_data_hand row'><div class='logo_fl_con'><i class='fas fa-flag-alt'></i></div><div class='cont_of_fl_name' style='color: black;font-weight: 800;'>"+pg_name+"<br><p class='main_emb_para'>"+cat_of_page+"</p></div><div class='opt_of_work'><button class='bottom-btn com-for-lnk' data-for-serv='1' data-path-ses='social/' data-target-link='https://social.<?php echo $url_main;?>/social/'   style='height: auto;border: none;padding: 10px;' >Sheduled Post<i class='fad fa-long-arrow-right' aria-hidden='true'></i></button> </div></div>";

 }
$(".modal_res_connect").html(str_of_app);
 }else{






$(".modal_res_connect").html("<a href='https://facebook.com/'><button class='bottom-btn' style='width:fit-content;margin: 20px 0px;background: #4a154bd9;color: white;' >Connect Once Again</button><a>");




 }




}






$(document).on("click",".add_insta_acc",function(){
append_load("add_insta_acc");	
insta_connect_face();

});





function insta_connect_face(){
	

console.log("instagram");



for(k=0;k<page_fb_data.length;k++){

page_id=page_fb_data[k].id;

$.get("https://graph.facebook.com/v7.0/"+page_id+"?fields=instagram_business_account&access_token="+access_fb_token)
            .then((response) => {


insta_id=response.instagram_business_account.id;

if(insta_id.length>0){

$.get("https://graph.facebook.com/v7.0/"+insta_id+"?fields=username,profile_picture_url&access_token="+access_fb_token)
            .then((response) => {

console.log(response);




insta_pro=response.profile_picture_url;



init_insta_account_mod(response.username,insta_pro);




            })

}

            })



}


}


function init_insta_account_mod(usr_name,pro_pic){

str_app="<img src='"+pro_pic+"' height='64' class='insta_pro_pic'/><br><h3 style='color:black;padding:10px;'>"+usr_name+"</h3><button class='bottom-btn' style='width:fit-content;background: #4a154bd9;color: white;' >Create Post</button>";



$(".modal_res_connect").html(str_app);


}





























//fb api end


rem_app_tp="";

$(document).on("click",".rem_api_token_ico",function(){


id_part=$(this).attr("id");

rem_app_tp=$(this).attr('app_tp_del');

$(".img_rem_mod").attr("src","https://res.cloudinary.com/heptera/image/upload/"+json_dec_part[rem_app_tp]['part_logo']);
$(".rem_mod_name").html(json_dec_part[rem_app_tp]['part_name']);
$(".rem_mod_desc").html(json_dec_part[rem_app_tp]['part_desc']);
$(".rem_mod_sub_btn").attr("id",rem_app_tp);



});

function append_load(get_date){

$("."+get_date).children(".row").append("<div class='lds-ring'  style=''><div></div><div></div><div></div><div></div></div>");

    }


        $(document).on("click",".rem_mod_sub_btn",function(){

ld_app_in_btn(".rem_mod_sub_btn");
id_dis_tp=$(this).attr("id");
$.ajax({
                url : "./ajaxfile/sub_acc_token.php",
                type: "POST",
                data : {access_tok:id_part,access_tp:rem_app_tp}
        }).done(function(response){ 
console.log(response);
if(response){
window.location.href="../emb/";
}else{


}




app_txt_btn(".rem_mod_sub_btn");


        });
      

        });





  $('#chooseFile').change(function () {
  var filename = $("#chooseFile").val();
 
  if (/^\s*$/.test(filename)) {
    $(".file-upload").removeClass('active');
    $("#noFile").text("No file chosen..."); 
  }
  else {
    $(".file-upload").addClass('active');
    $("#noFile").text(filename.replace("C:\\fakepath\\", "")); 
  }
});


  </script>
  <script>
  function getdata(path){
      
      ChangeUrl(path,"?path="+path);
      
      $(".con-hover").css("display","block");

$(".submit-form-contact").attr("id",path);
$(".main-content").load(path+".php", function(responseTxt, statusTxt, xhr){
    if(statusTxt == "success"){
      $(".con-hover").css("display","none");
      $(".click-on-opt").css("display","block");
$(".submit-form-contact").click(function(){

submitcon(path);


});

    }
    if(statusTxt == "error"){
      $(".con-hover").css("display","none");}
  });
      
      
      

  }
  function ChangeUrl(title, url) {
    if (typeof (history.pushState) != "undefined") {
        var obj = { Title: title, Url: url };
        history.pushState(obj, obj.Title, obj.Url);
    } else {
        alert("Browser does not support HTML5.");
    }
}
      </script>
  <script>


$("#subfileform").submit(function(event){
	event.preventDefault(); //prevent default action 
	var post_url = $(this).attr("action"); //get form action url
	var request_method = $(this).attr("method"); //get form GET/POST method
	var form_data = $(this).serialize(); //Encode form elements for submission
	
	$.ajax({
		url:post_url,
   method:"POST",
   data:new FormData(this),
   contentType:false,
   cache:false,
   processData:false,
   beforeSend: function () {
         $("#loadsendlink").css("display","inline-block");
      
        },
   
	}).done(function(response){ //
  $(".res").html(response);
	});
});








btn_con="";

function ld_app_in_btn(id_sel){


btn_con=$(id_sel).html();

$(id_sel).prop('disabled', true);




}


function app_txt_btn(id_sel){

  $(id_sel).html(btn_con);
$(id_sel).prop('disabled', false);

}

function err_msg_data(message){


$("#con-of-err-msg").html(message);

$("#err_msg_dt_trg").css('display','inline-block');



setTimeout(
    function() {


      $("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');
      
    }, 5000);


}


$(document).on('click','#cncl-err-msg',function(){


$("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

})



</script>
  
  




</html>



