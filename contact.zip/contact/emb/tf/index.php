<?php


session_start();


function get_acc_tok_avail($id,$dt_tp){
require("../../confige/multi_src_conn.php");

$sel_query="select * from multi_soc_acc where id='$id' and app_id='$dt_tp'";


$res=$multi_soc_conn->query($sel_query);

if ($res->num_rows > 0) {

  header("Location: https://contact.sycista.com/contact/emb/");

  }

}



$id=$_SESSION['id'];

$dt_tp='tf';

get_acc_tok_avail($id,$dt_tp);
?>









<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


<style type="text/css">

.con-fb-connect {
    padding-top: 10%;
    height: 100vh;
    overflow: scroll;
}
.card-img-top{

  margin: auto;
  height: 64px;
  width: 64px;
}


.card{
padding-top: 20px;
    padding-bottom: 20px;

  }
  img.list-img-right {
    height: 36px;
    padding-right: 30px;
  }





.bottom-btn{
  text-align: center;
    height: 40px;
    background: #4a154bd9;
    color: white;
    
    font-size: 15px;
    border-radius: 4px;
    border:1px solid  #4a154bd9;
   width:100%;
    padding-left: 20px;
    padding-right: 20px;
}


.bottom-btn:hover{
	cursor: pointer;
}


</style>
<script type="text/javascript">





</script>
<?php require("../ajaxfile/common_style.php");?>
<div class='con-fb-connect'>

<div class="card" style="width: 30rem;margin:auto;">
  <img class="card-img-top" src="https://res.cloudinary.com/heptera/image/upload/v1631983396/tp_joc5wi.png"  alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Connect TypeForm Account</h5>
    <p class="card-text">Directly Get all contact of form and Saved In Heptera| <sub>list</sub></p>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Get All Email Contact in Heptera</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Select Specific Contact</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Add All Contact.</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Add In List.</li>
  </ul>
  <div class="card-body">
  <button id="authlink" class="bottom-btn"  >Connect TypeForm Account</button>  </div>
</div>

</div>
 <script src="https://code.jquery.com/jquery-1.11.2.min.js"></script>
<script src="https://apis.google.com/js/client.js"></script>
<script src="../ajaxfile/utils.js"></script>



<script type="text/javascript">

$(document).on('click','#authlink',function(){


id='4nssw8erXnCLMeqdEFtFEy5Vnhwcc2qGXgugPoanQe7A';
sec_id='';
call_back='https://contact.auftera.com/contact/emb/tf/callback.php';
scope='accounts:read+forms:read+responses:read+webhooks:write';

window.location='https://api.typeform.com/oauth/authorize?state=xyz789&client_id='+id+'&redirect_uri='+call_back+'&scope='+scope;



})


</script>




