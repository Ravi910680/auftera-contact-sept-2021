<?php
session_start();
$id=$_SESSION['id'];

function httpPost($url,$params)
{
  $postData = '';
   //create name value pairs seperated by &
   foreach($params as $k => $v) 
   { 
      $postData .= $k . '='.$v.'&'; 
   }
   $postData = rtrim($postData, '&');
 
    $ch = curl_init();  
 
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_HEADER, false); 
   
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);    
 
    $output=curl_exec($ch);
 
    curl_close($ch);
    return $output;
 
}

if(isset($_GET['code'])){



$get_code=$_GET['code'];
$req_for_tok_arr=array(
  'client_secret' => '9NictrAAesrg96Bb5ME7ScCGLwWTTfHEYeW2uSHUbZBY',
  'redirect_uri' => 'https://contact.auftera.com/contact/emb/tf/callback.php',
  'client_id' => '4nssw8erXnCLMeqdEFtFEy5Vnhwcc2qGXgugPoanQe7A',
  'code' => $get_code,
  'grant_type' => 'authorization_code'
);

$tf_token_data=json_decode(httpPost("https://api.typeform.com/oauth/token",$req_for_tok_arr))->access_token;



$arr_post_add=array("access_token"=>$tf_token_data,"app_id"=>"tf","usr_id"=>$id);


$res=httpPost("https://contact.auftera.com/contact/emb/ajaxfile/multi_acc.php",$arr_post_add);


if($res){

	header("Location: https://contact.auftera.com/contact/emb/");

}else{


}

}else{


}

?>
