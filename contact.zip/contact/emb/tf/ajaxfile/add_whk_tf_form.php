<?php



$token=$_POST['token'];
$tag=$_POST['tag'];
$sub_status=$_POST['sub_stat'];
$form_id=$_POST['form_id'];
$lst_id=$_POST['lst_id'];

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.typeform.com/forms/".$form_id."/webhooks/create",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "PUT",
  CURLOPT_POSTFIELDS =>"{\"url\":\"https://api.auftera.com/list/".$lst_id."/tf/add/tag:".$tag."#status:".$sub_status."\", \"enabled\":true}",
  CURLOPT_HTTPHEADER => array(
    "Authorization: Bearer ".$token,
    "Content-Type: application/json",
    "Cookie: attribution_user_id=4188b3ff-f0c2-40d9-9623-6153597e2067"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;



?>
