<?php
session_start();

$acc_token=$_POST['acc_token'];
$form_id=$_POST['form_id'];
$form_name=$_POST['form_name'];
$list_name=$_POST['list_name'];

function get_data_of_res_all($form_id,$acc_token,$page_token){

  $ret_arr=array();

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.typeform.com/forms/".$form_id."/responses?page_size=2&before=".$page_token,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
    "Authorization: Bearer ".$acc_token,
    
  ),
));

$response = curl_exec($curl);

curl_close($curl);

$jsn_arr=json_decode($response);



return $jsn_arr;

}


$data_of_all_res=get_data_of_res_all($form_id,$acc_token,"");

$res_arr=array();

$cnt_email=0;
$cnt_page=$data_of_all_res->page_count;


$res_last_arr=array();

foreach ($data_of_all_res->items as $key => $value) {

  $loc_arr_2=array();
 foreach ($value->answers as $key2 => $value2) {


	 if($key2=="email"){

		 $cnt_email+=1;
    $loc_arr_2['email']=$value2->email;

    break;
   }

  

 }

  array_push($res_last_arr, $loc_arr_2);


}

for ($i=1; $i <$cnt_page ; $i++) { 
  
$page_token=$data_of_all_res->items[1]->token;
$data_of_all_res=get_data_of_res_all($form_id,$acc_token,$page_token);



foreach ($data_of_all_res->items as $key => $value) {

  $loc_arr_2=array();
 foreach ($value->answers as $key2 => $value2) {
	 if($key2=="email"){

		 $cnt_email+=1;
    $loc_arr_2['email']=$value2->email;
    break;
   }

   

 }

 
array_push($res_last_arr, $loc_arr_2);

}



}

$email_arr=json_encode($res_last_arr);


$_SESSION['email_data']=$email_arr;
$_SESSION['src_of_mail']= $form_name." FORM:TF";



$red_url="https://contact.auftera.com/contact/ajaxfile/crtseslist.php?requestoflist=".$list_name."&red_url=https://contact.auftera.com/contact/select_opt/";
$res_data=array("status"=>1,"red_url"=>$red_url,"email_cnt"=>$cnt_email);

print_r(json_encode($res_data));

?>
