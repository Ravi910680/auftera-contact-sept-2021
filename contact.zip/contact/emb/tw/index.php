<?php
session_start();
require 'vendor/autoload.php';
use Abraham\TwitterOAuth\TwitterOAuth;


$connection = new TwitterOAuth('Ez4QEjTHyepCBVZliPWZoWWnn','Tfu97VINIz7V1VyOZ8KtXCnaXVZ4Q7K22cVfi74yT31Xj6FGq9');



$request_token = $connection->oauth('oauth/request_token', array('oauth_callback' => 'https://contact.auftera.com/contact/emb/tw/new/'));


$url = $connection->url('oauth/authorize', array('oauth_token' => $request_token['oauth_token']));



$_SESSION['oauth_token']=$request_token['oauth_token'];
$_SESSION['oauth_token_secret']=$request_token['oauth_token_secret'];










?>





<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


<style type="text/css">

.con-fb-connect {
    padding-top: 10%;
    height: 100vh;
    overflow: scroll;
}
.card-img-top{

  margin: auto;
  height: 64px;
  width: 64px;
}


.card{
padding-top: 20px;
    padding-bottom: 20px;

  }
  img.list-img-right {
    height: 36px;
    padding-right: 30px;
  }





.bottom-btn{
  text-align: center;
    height: 40px;
    background: #4a154bd9;
    color: white;
   
    font-size: 13px;
    border-radius: 4px;
    border:1px solid  #4a154bd9;
   width:100%;
    padding-left: 20px;
    padding-right: 20px;
}


.bottom-btn:hover{
	cursor: pointer;
}


</style>
<script type="text/javascript">





</script>
<?php require("../ajaxfile/common_style.php");?>
<div class='con-fb-connect'>

<div class="card" style="width: 30rem;margin:auto;">
  <img class="card-img-top" src="https://res.cloudinary.com/heptera/image/upload/v1631983564/7211715581582863585-128_dvtwji.png"  alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Connect Twitter Account</h5>
    <p class="card-text">Connect DropBox With Sycista To Simplify your social media marketing.</p>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Promised For Data usage</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Sheduled Post on your Time</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Connect multiple Account</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Social Media Analysis</li>
  </ul>
  <div class="card-body">
  <button onclick="window.location.href='<?php echo $url;?>'" id="authlink" class="bottom-btn">Connect Twitter</button>  </div></div>

</div>
