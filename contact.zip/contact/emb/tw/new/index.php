<?php
session_start();
require '../vendor/autoload.php';
use Abraham\TwitterOAuth\TwitterOAuth;

$request_token['oauth_token'] = $_SESSION['oauth_token'];
$request_token['oauth_token_secret'] = $_SESSION['oauth_token_secret'];


require("../../../confige/userconnect.php");

 $mail=$_SESSION["email"];
    $id=$_SESSION["id"];


$sql_soc_stat = "SELECT * FROM userinfo WHERE email='$mail' and tw=''";

$result=$conn->query($sql_soc_stat);

$count = mysqli_num_rows($result);





if (isset($_REQUEST['oauth_token']) && $request_token['oauth_token'] == $_REQUEST['oauth_token']) {



$connection = new TwitterOAuth('Ez4QEjTHyepCBVZliPWZoWWnn', 'Tfu97VINIz7V1VyOZ8KtXCnaXVZ4Q7K22cVfi74yT31Xj6FGq9', $request_token['oauth_token'], $request_token['oauth_token_secret']);


$access_token = $connection->oauth("oauth/access_token", ["oauth_verifier" => $_REQUEST['oauth_verifier']]);



$acc_tok=$access_token['oauth_token']."#".$access_token['oauth_token_secret'];
echo $acc_tok;

}else{

echo "ravi";


}





?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
stat_of_dt='<?php echo $count;?>';
$( document ).ready(function() {
    
access_token_new='<?php echo $acc_tok;?>';

if(access_token_new.length>0){



$.ajax({
                url : "../../ajaxfile/multi_acc.php",
                type: "POST",
                data : {access_token:access_token_new,app_id:"tw"}
        }).done(function(response){ 
console.log(response);
if(response==1){
window.location.href="../../../emb/";
}


});






}


});


</script>
