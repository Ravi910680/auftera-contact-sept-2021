<?php


$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://content.dropboxapi.com/2/files/download');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);

$headers = array();
$headers[] = 'Authorization: "Bearer" z2HtsEaLdFAAAAAAAAAAf1o28yyQUggbtxVWoKoLPrkG2XtgaEca7-wWkgAfu0UN Dropbox-API-Arg: {"path":"/5^dw5kzwzpbmu=^0.jpeg"}';

curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);


echo $result;

if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);



?>
