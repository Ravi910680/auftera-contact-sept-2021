<?php
session_start();















function httpPost($url,$params,$accestoken)
{
  $postData = '';
   //create name value pairs seperated by &

  $i=0;
   foreach($params as $k => $v)
   {
      $postData .= $k . '='.$v.'&';
      $i+=1;
   }
   $postData = rtrim($postData, '&');

    $ch = curl_init();

    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_HEADER, 'X-Shopify-Access-Token: '.$accestoken);
    curl_setopt($ch, CURLOPT_POST, $i);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

    $output=curl_exec($ch);

    curl_close($ch);
    return $output;

}


function httpGet($url,$accestoken)
{
    $ch = curl_init();  
 
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);

    curl_setopt($ch,CURLOPT_HTTPHEADER,array( 'X-Shopify-Access-Token: '.$accestoken));
    $output=curl_exec($ch);
 
    curl_close($ch);
    return $output;
}























$query_tp=$_POST['query'];
$query_val=$_POST['val'];
$tok=$_POST['acc_tok'];


$exp_tok=explode("#",$tok);
$shop_name=$exp_tok[0];
$token=$exp_tok[1];


$fin_array=array();

$data_of_cust=json_decode(httpGet("https://".$shop_name."/admin/api/2021-04/customers.json",$token));

$cnt_cust=0;


$ret_arr=array("status"=>1,"cust_cnt"=>0);


if(!isset($data_of_cust->errors)){

foreach ($data_of_cust->customers as $value)
{
	
	$ret_arr['cust_cnt']+=1;
	$loc_array=array();

	$loc_array["email"]=$value->email;

	array_push($fin_array,$loc_array);
}

$_SESSION['src_of_mail']=$shop_name;
$_SESSION['email_data']=json_encode($fin_array);


}else{


	$ret_arr['status']=0;
	

}
print_r(json_encode($ret_arr));
?>
