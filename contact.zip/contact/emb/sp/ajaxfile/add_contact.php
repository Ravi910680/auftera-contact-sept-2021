<?php
session_start();


$lst_name=$_POST['list_name'];



?>
