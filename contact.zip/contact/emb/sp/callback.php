<?php



session_start();

require("../../confige/multi_src_conn.php");

$req_cd=$_GET['code'];


 $mail=$_SESSION["email"];
    $id=$_SESSION["id"];

function httpPost($url,$params)
{
  $postData = '';
   //create name value pairs seperated by &

  $i=0;
   foreach($params as $k => $v) 
   { 
      $postData .= $k . '='.$v.'&';
      $i+=1; 
   }
   $postData = rtrim($postData, '&');
 
    $ch = curl_init();  
 
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_HEADER, false); 
    curl_setopt($ch, CURLOPT_POST, $i);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);    
 
    $output=curl_exec($ch);
 
    curl_close($ch);
    return $output;
 
}


$params=array("client_id"=>"f11d828719080feb6cd9cec0b964535a","client_secret"=>"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","code"=>$req_cd);


$shop=$_GET['shop'];

$url="https://".$shop."/admin/oauth/access_token";

$res_data=json_decode(httpPost($url,$params));

$acc_tok=$shop."#".$res_data->access_token;


$date=date("Y-m-d H:i:s");

$app_id="sp";

$sql = "INSERT INTO multi_soc_acc (id, acc_tok, add_date,app_id) VALUES ('$id', '$acc_tok', '$date','$app_id')";


if ($multi_soc_conn->query($sql) === TRUE) {
  header("Location: https://contact.auftera.com/contact/emb/");
} 


?>
