<?php


session_start();


function get_acc_tok_avail($id,$dt_tp,$tok){
require("../../confige/multi_src_conn.php");

$sel_query="delete from multi_soc_acc where id='$id' and app_id='$dt_tp' and acc_tok='$tok'";
$res=$multi_soc_conn->query($sel_query);


}



$id=$_SESSION['id'];

$dt_tp='gc';

if($_GET['tok']!="undefined"){
get_acc_tok_avail($id,$dt_tp,$_GET['tok']);

}
?>










<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


<style type="text/css">

.con-fb-connect {
    padding-top: 10%;
    height: 100vh;
    overflow: scroll;
}
.card-img-top{

  margin: auto;
  height: 64px;
  width: 64px;
}


.card{
padding-top: 20px;
    padding-bottom: 20px;

  }
  img.list-img-right {
    height: 36px;
    padding-right: 30px;
  }





.bottom-btn{
  text-align: center;
    height: 40px;
    background: #4a154bd9;
    color: white;
    
    font-size: 13px;
    border-radius: 4px;
    border:1px solid  #4a154bd9;
   width:100%;
    padding-left: 20px;
    padding-right: 20px;
}


.bottom-btn:hover{
	cursor: pointer;
}


</style>

<?php require("../ajaxfile/common_style.php");?>
<script type="text/javascript">





</script>

<div class='con-fb-connect'>

<div class="card" style="width: 30rem;margin:auto;">
  <img class="card-img-top" src="https://res.cloudinary.com/heptera/image/upload/v1631981848/google-plus_f6ln8a.png"  alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Connect Google Contact Account</h5>
    <p class="card-text">Add Your Google Contact And Saved In Heptera| <sub>list</sub>.</p>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Get All Email Contact in Heptera</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Select Specific Contact</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Add All Contact.</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Add In List.</li>
  </ul>
  <div class="card-body">
  <button id="authlink" class="googleContactsButton bottom-btn">Connect Google Contact</button>  </div>
</div>

</div>
 <script src="https://code.jquery.com/jquery-1.11.2.min.js"></script>
<script src="https://apis.google.com/js/client.js"></script>
<script src="../ajaxfile/utils.js"></script>



<script type="text/javascript">

var clientId = '708831699555-c01j75sl69lg0rhq2v4c6nivo10mmqmg.apps.googleusercontent.com';
          var apiKey = 'CsDmG4gvQ9EyiGc3rwQA6B6F';
          var scopes = 'https://www.googleapis.com/auth/contacts.readonly';

          $(document).on("click",".googleContactsButton", function(){
            gapi.client.setApiKey(apiKey);
            window.setTimeout(authorize);
          });

          function authorize() {
            gapi.auth.authorize({client_id: clientId, scope: scopes, immediate: false}, handleAuthorization);
          }

            
function handleAuthorization(authorizationResult) {

console.log(authorizationResult);

	if (authorizationResult && !authorizationResult.error) {
             console.log("ravi");
              
new_auth_tok=authorizationResult.access_token;




console.log(new_auth_tok);



$.ajax({
                url : "../ajaxfile/multi_acc.php",
                type: "POST",
                data : {access_token:new_auth_tok,app_id:"gc"}
        }).done(function(response){
console.log(response);
if(response==1){

window.location.href="../../emb/";

}


});



            }
          }          




</script>



