<?php

session_start();


 $mail=$_SESSION["email"];
    $id=$_SESSION["id"];
if(isset($_SESSION["email"])){
require("../../confige/multi_src_conn.php");


$token_acc=$_POST['access_tok'];
$acc_type=$_POST['access_tp'];

$sql = "DELETE FROM `multi_soc_acc` where acc_tok='$token_acc' and app_id='$acc_type'";

echo $sql;

$result=$multi_soc_conn->query($sql);

print_r($result);


}






?>

