<?php

session_start();

require("../../confige/multi_src_conn.php");
$id=$_SESSION['id'];
if(isset($_POST['usr_id'])){


$id=$_POST['usr_id'];
}


$date=date("Y-m-d H:i:s");


$acc_tok=$_POST['access_token'];

$app_id=$_POST['app_id'];



$sql = "INSERT INTO multi_soc_acc (id, acc_tok, add_date,app_id) VALUES ('$id', '$acc_tok', '$date','$app_id')";


if ($multi_soc_conn->query($sql) === TRUE) {
  echo 1;
} 



?>
