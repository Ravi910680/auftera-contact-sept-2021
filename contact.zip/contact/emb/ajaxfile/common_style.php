
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">

<style>

body{
font-family: 'lato';
}

.card {
    padding: 0px;
    padding-top: 20px;
border-radius: 30px;
    box-shadow: rgb(0 0 0 / 10%) 0px 10px 15px -3px, rgb(0 0 0 / 5%) 0px 4px 6px -2px;

}
.bottom-btn{
background: #100f10d9;
    color: white;

border-radius: 50px;
    box-shadow: rgb(50 50 93 / 25%) 0px 13px 27px -5px, rgb(0 0 0 / 30%) 0px 8px 16px -8px;

}
.card-img-top {
    margin: auto;
    height: 64px;
    width: 64px;
    border-radius: 20px;
}
.bottom-btn:focus{

outline:none;

}
</style>
