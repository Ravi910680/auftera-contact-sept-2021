<?php

session_start();
require './tw/vendor/autoload.php';
use Abraham\TwitterOAuth\TwitterOAuth;

$tw_api_key="1150652678181011456-ukPpFMtTW3AUBcnLzjZae49hZvODtz#mRrBV5ExpuRZkWTmL89xszcE78MkBuarawmO5jxl4ey6Z";

$tw_ex_tok=explode("#",$tw_api_key);

$acc_tok=$tw_ex_tok[0];
$acc_tok_sec=$tw_ex_tok[1];

$consumerkey = "Ez4QEjTHyepCBVZliPWZoWWnn";
$consumersecret = "Tfu97VINIz7V1VyOZ8KtXCnaXVZ4Q7K22cVfi74yT31Xj6FGq9";


$twitteroauth = new TwitterOAuth($consumerkey, $consumersecret,$acc_tok,$acc_tok_sec);

$parameters = [
    'status' => 'Hello Word with Images! https://developer.twitter.com/en/docs/tweets/post-and-engage/api-reference/post-statuses-update',
    'media_ids' => implode(',', [$media1->media_id_string])
];
$mediaOBJ = $twitteroauth->post('statuses/update', $parameters);
print_r($media1);



?>
