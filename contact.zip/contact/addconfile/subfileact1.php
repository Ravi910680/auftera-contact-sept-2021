<?php  
session_start();
require("../../../confige/fileconfige.php");
if(isset($_POST['filename'])){
    $status=0;
 if(!empty($_FILES['file']['name']))
{
    
 $filename = explode(".", $_FILES['file']['name']);
  if($filename[1] == 'csv')
  {

$filenoencode=$_POST["filename"];
$id=$_SESSION["id"];
      $checkpres = "SELECT * FROM filedetails WHERE id='$id' AND filename='$filenoencode'";
$checkres = $conn2->query($checkpres);
$rowcheck=mysqli_num_rows($checkres);





if($rowcheck==0){







      $filename=$id."^".$_POST["filename"];
      $file_data = fopen($_FILES['file']['tmp_name'], 'r');
      $row = fgetcsv($file_data);
      $collom=count($row);
      $sql = "CREATE TABLE  `".$filename."`  (";
      
      for ($x = 1; $x <= $collom-1; $x++) {
    $sql=$sql."col".$x." VARCHAR(255),";
   
} 
$sql=$sql."col".$x." VARCHAR(255))";


$recordtimes=0;





if ($conn3->query($sql) === TRUE) {




    while($row = fgetcsv($file_data)){

for ($x = 0; $x < $collom-1; $x++){
           if (filter_var($row[$x], FILTER_VALIDATE_EMAIL)) {

$email_idx=$x;
    $insert="INSERT INTO `".$filename."` VALUES(".$row[$email_idx];
       for ($x = 0; $x < $collom-1; $x++){
           $insert=$insert."'".$row[$x]."',";
       }
       $insert=$insert."'".$row[$x]."');";

if ($conn3->query($insert) === TRUE) {
    $recordtimes=$recordtimes+1;
}
} else {
    echo("$email is not a valid email address");
}
       }




        $insert="INSERT INTO `".$filename."` VALUES(";
       for ($x = 0; $x < $collom-1; $x++){
           $insert=$insert."'".$row[$x]."',";
       }
       $insert=$insert."'".$row[$x]."');";









if ($conn3->query($insert) === TRUE) {
    $recordtimes=$recordtimes+1;








    
}
      }
      $insertfilename = "INSERT INTO filedetails (id, filename, extra) VALUES ('$id', '$filenoencode', '$recordtimes')";
$conn2->query($insertfilename);
      echo "<div class='card bg-success text-white'><div class='card-body'>inserted ".$recordtimes." records in file</div></div>";
} else {
    
    $status=1;
    
}
      
}else{
    $status=2;


}

  }else{
    $status=3;
     
  }

}
echo $status;
}else{





    
}


?>