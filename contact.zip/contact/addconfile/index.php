    <style>
.button-select-file{
    
}

#custom-button {
  width:10%;
  color: black;
  background-color: #f2f2f2;
  
  
  cursor: pointer;
}

#custom-button:hover {
  background-color: f;
}

#content-name {
   
    width:40%;
    border:1px solid rgba(36,28,21,0.3);
  margin-left: 10px;
  font-family: sans-serif;
  letter-spacing:0.5px;
  color: #aaa;
  padding:10px;
}









.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid #5a2977;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}












    </style>    

<script>



</script>




















<?php
session_start();

    $mail=$_SESSION["email"];
    $id=$_SESSION["id"];

$id=$_SESSION["id"];


?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">
  <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />
  


<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1603531914/norm_used/loader_ww3kih.css">

  <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">
<style>

@import url(https://fonts.googleapis.com/css?family=Arvo);
@import url(http://fonts.googleapis.com/css?family=Varela+Round);
.hover-bottom:hover{
    border-bottom:1px solid white;

}
.card-hover:hover{
    background:#f2f2f2;
  cursor: pointer;
}
.fa-add{
    padding:20px;
        font-size: 100px;
    margin: 0 auto;
}
.tablediv{
    padding:10%;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;

}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
#loader {
  position: absolute;
  
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: 0 auto;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
.unique-name:focus{
    border:2px solid;
}









.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}


.bottom-btn:hover{
	cursor: pointer;
}












button.btn-theme-dsg {
  font-family 'IBM Plex Sans', sans-serif !important: 
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    font-size: 14px;
    line-height: 1.5;
    font-weight: 500;
    border-radius: 4px;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    border: 0;
    -webkit-appearance: none;
    position: relative;
    -webkit-transition-property: background-color,border-color,color;
    transition-property: background-color,border-color,color;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
    min-width: 0;
    -webkit-flex: 0 0 auto;
    -ms-flex: 0 0 auto;
    flex: 0 0 auto;
    font-family: 'Roboto';
    color: #FFFFFF;
    background-color: #4a154b;
    padding-right: 16px;
    padding-left: 16px;
    margin: 8px 0px;
    height: 48px;


  }

button.btn_hover_clr {
  font-family 'IBM Plex Sans', sans-serif !important: 
    margin-top: 10px;
    background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    font-size: 13px;
    font-weight: 500;
    float: right;
    color: #471f48f0;

  }

  button.btn_hover_clr:hover {
    background: #b284b336;
    cursor: pointer;

  }

  .modal{
    z-index: 10000000000;
  }


  .ip-by-def-dsg {
    max-width: 300px;
    font-family 'IBM Plex Sans', sans-serif !important;
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;


  }

  .ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #4a154b;
    box-shadow: 0 0 0 3px #4a154b4d;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;

  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}












.vert-cent-div {
  width: min-content;
  height: min-content;
  text-align: center;
  
  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
    
  margin: auto;
}




.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000b5;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
    z-index: 100000000;
}

















.file-upload{display:block;text-align:center;font-family: Helvetica, Arial, sans-serif;font-size: 12px;}
.file-upload .file-select{display:block;border: 2px solid #dce4ec;color: #34495e;cursor:pointer;height:40px;line-height:40px;text-align:left;background:#FFFFFF;overflow:hidden;position:relative;}
.file-upload .file-select .file-select-button{background:#dce4ec;font-weight:900;font-size:15px;padding:0 10px;display:inline-block;height:40px;line-height:40px;}
.file-upload .file-select .file-select-name{line-height:40px;display:inline-block;padding:0 10px;}
.file-upload .file-select:hover{border-color:#34495e;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload .file-select:hover .file-select-button{background:#34495e;color:#FFFFFF;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload.active .file-select{border-color:#3fa46a;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload.active .file-select .file-select-button{background:#3fa46a;color:#FFFFFF;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload .file-select input[type=file]{z-index:100;cursor:pointer;position:absolute;height:100%;width:100%;top:0;left:0;opacity:0;filter:alpha(opacity=0);}
.file-upload .file-select.file-select-disabled{opacity:0.65;}
.file-upload .file-select.file-select-disabled:hover{cursor:default;display:block;border: 2px solid #dce4ec;color: #34495e;cursor:pointer;height:40px;line-height:40px;margin-top:5px;text-align:left;background:#FFFFFF;overflow:hidden;position:relative;}
.file-upload .file-select.file-select-disabled:hover .file-select-button{background:#dce4ec;color:#666666;padding:0 10px;display:inline-block;height:40px;line-height:40px;}
.file-upload .file-select.file-select-disabled:hover .file-select-name{line-height:40px;display:inline-block;padding:0 10px;}
</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  
  <!-- Icons -->
  

 
 
  <!-- CSS Files -->


</head>
<div id="c"></div>




<div class="vert-cent-div err-menu-cls-dsg" id="err_msg_dt_trg" style="display: none;">
<span id="con-of-err-msg"></span>
<span class="cls-err-menu" id="cncl-err-msg">
<i class="fal fa-times-circle" style="
    padding: 6px;
"></i>
</span>
</div>


<body class="" style="background:#fff;">
  <div style="height:92vh">
<?php require("../confige/header/header.php");?>

<nav class="navbar navbar-dark " style="color:#4a154bd9;border-bottom: 1px solid #ebeaeb;background:white;height:7vh;padding:10px;top:8vh;">
<div style="width:100%"><span style="float-left"><a class=" hover-bottom" href="/main/addcontact/" style="color:#4a154bd9;font-weight:600;">Return to dashboard</a></span>

</div>

</nav>


<div class="main-content" style="margin:40px;top:15vh;">



        
       
            <form method="POST" action="subfileact.php" id="subfileform"  enctype="multipart/form-data">
            <div class="input-set" style="height:50px;width:100%">
            
  
   <div class="file-upload" style="width:40%;">
  <div class="file-select">
    <div class="file-select-button" id="fileName">Browse File</div>
    <div class="file-select-name" id="noFile">No file chosen...</div> 
    <input type="file" name="file" id="chooseFile" required>
  </div>
</div>


  </div>
   
           <div class="" style="padding:40px;">
           <span style="font-weight:800;"> Choose File :</span><span>   Only use csv file or tab-delimited text files.</span><br>
<div style="width:40%;padding-top:10px;">
           <i>
Duplicate addresses will be removed. We do not send confirmation emails to imported addresses and trust that you’ve gathered proper permission to send to every address in your audience.
           </I>
</div>
           
                </div>
     
     
     

</div>

</div>
<nav class="navbar navbar-dark" style="background:white;border-top:1px solid #c3c0c3;height:8vh;padding:10px;">
<div style="width:100%">
<div class="float-right click-on-opt"  style="height:100%;width:50%;float:right;">
<button type="submit" class="btn-theme-dsg" id="sub_file_form" style="background:#4a154bd9;max-height: 100%;margin: 0px;width: min-content;margin-left: auto;float:right;"><div class="row"><div style="margin:0px 10px;">Countinue to Store<i class="fal fa-long-arrow-alt-right" style="
    padding-left: 10px;
" aria-hidden="true"></i></div></div></button>

</div>

</nav>
</form>
</body>
<div class="res">
</div>
<div id='con_res'></div>


  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>
  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
  <script>


  </script>
    <script>
  $('#chooseFile').change(function () {
  var filename = $("#chooseFile").val();
 
  if (/^\s*$/.test(filename)) {
    $(".file-upload").removeClass('active');
    $("#noFile").text("No file chosen..."); 
  }
  else {
    $(".file-upload").addClass('active');
    $("#noFile").text(filename.replace("C:\\fakepath\\", "")); 
  }
});


  </script>
  <script>
  function getdata(path){
      
      ChangeUrl(path,"?path="+path);
      
      $(".con-hover").css("display","block");

$(".submit-form-contact").attr("id",path);
$(".main-content").load(path+".php", function(responseTxt, statusTxt, xhr){
    if(statusTxt == "success"){
      $(".con-hover").css("display","none");
      $(".click-on-opt").css("display","block");
$(".submit-form-contact").click(function(){

submitcon(path);


});

    }
    if(statusTxt == "error"){
      $(".con-hover").css("display","none");}
  });
      
      
      

  }
  function ChangeUrl(title, url) {
    if (typeof (history.pushState) != "undefined") {
        var obj = { Title: title, Url: url };
        history.pushState(obj, obj.Title, obj.Url);
    } else {
        alert("Browser does not support HTML5.");
    }
}
      </script>
  <script>


$("#subfileform").submit(function(event){
	event.preventDefault(); //prevent default action 
	var post_url = $(this).attr("action"); //get form action url
	var request_method = $(this).attr("method"); //get form GET/POST method
	var form_data = $(this).serialize(); //Encode form elements for submission




append_load_in_all_btn("#sub_file_form");



	$.ajax({
		url:post_url,
   method:"POST",
   data:new FormData(this),
   contentType:false,
   cache:false,
   processData:false,
   beforeSend: function () {
         $("#loadsendlink").css("display","inline-block");
      
        },
   
	}).done(function(response){ //
         


console.log(response);

if(response==0){
	
window.location ='./../select_opt/';
}else if(response==1){



err_msg_data("Invalid User");

	
}else if(response==2){
	

err_msg_data("Please Select CSV File");
}else if(response==3){
	


err_msg_data("please select file");

}else{



err_msg_data("please Valid File");

}


append_txt_of_lds("#sub_file_form");

	});
});






function err_msg_data(message){


$("#con-of-err-msg").html(message);

$("#err_msg_dt_trg").css('display','inline-block');



setTimeout(
    function() {


      $("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');
      
    }, 5000);


}


$(document).on('click','#cncl-err-msg',function(){


$("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

})










function append_load_in_all_btn(selector){




append_txt_that_get_clck=$(selector).html();

$(selector).prop("disabled",true);

$(selector).html('<div class="cp-spinner cp-round"></div>');

}



function append_txt_of_lds(selector){

$(selector).prop("disabled",false);

$(selector).html(append_txt_that_get_clck);


}




function intit_ip_fld_at_err(selector){

$(selector).addClass("err_of_ip_fld");


}


function intit_ip_fld_at_err_rem(selector){


$(selector).removeClass("err_of_ip_fld");

}


function cls_mdl_of_act(selector){



$(selector).removeClass("open");

}





</script>
  
  


<script type="text/javascript" src="../../jsfile/stickyheader4.js">

</script>



</html>

