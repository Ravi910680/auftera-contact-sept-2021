<?php  
session_start();
require("../confige/fileconfige.php");






error_reporting(E_ERROR);








function get_email_col($list_id){
require("../confige/fileconfige.php");


	$get_col_query="SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='list_contacts' AND `TABLE_NAME`='".$list_id."' ORDER BY ordinal_position";	

	$query = $conn3->query($get_col_query);

while($row = $query->fetch_assoc()){
    

	$result[] = $row;
}

// Array of all column names
$columnArr = array_column($result, 'COLUMN_NAME');

return $columnArr;



}









$_SESSION['email_data']=array();


require("../confige/camp_confige.php");
$lst_name=$_SESSION['listname'];
$get_camp_data="select * from camp_data where id LIKE '%".$lst_name."%'";

$result = $camp_name_conn->query($get_camp_data);

$cnt_camp=$result->num_rows;














function init_col_data($row_data,$col_name){

 



for($i=0;$i<count($col_name);$i++){

 $row_array[$col_name[$i]] = $row_data[$i];
            

}
return $row_array;
}


if(isset($_POST['lst_name'])){

	$_SESSION['listname']=$_POST['lst_name'];
}




if(isset($_SESSION['listname'])){
	$status=0;


if($_POST['frm']=="dp"){

$_FILES['file']['name']="dropbox.csv";
}


 if(!empty($_FILES['file']['name']))
{
    
 $filename = explode(".", $_FILES['file']['name']);
  if($filename[1] == 'csv')
  {
$filenoencode=$_SESSION["listname"];
$id=$_SESSION["id"];
     

$a=array();

if($_POST['frm']=="dp"){


$file_data = fopen("../emb/dp/ajaxfile/data.csv", 'r');

}else{
      $file_data = fopen($_FILES['file']['tmp_name'], 'r');
      
      
}
      
      
      $row = fgetcsv($file_data);
      $collom=count($row);
       


      
      


$findmail=0;
$x=0;



$col_name=get_email_col($filenoencode);

$col_name=array_slice($col_name,0,count($col_name)-$cnt_camp-11);      



    while($row = fgetcsv($file_data)){
$f=0;
$innermail=$x;


if (filter_var($row[0], FILTER_VALIDATE_EMAIL)) {
	
	
	

$row_array=init_col_data($row,$col_name);

	
	


array_push($a,$row_array);
}else{
for ($x = 0; $x < $collom; $x++){
           if (filter_var($row[$x], FILTER_VALIDATE_EMAIL)) {
		   $temp=$row[0];
		   $row[0]=$row[$x];
		   $row[$x]=$temp;

	       
	
	$row_array=init_col_data($row,$col_name);
	
		   array_push($a,$row_array);
break;
           }
}


}

      }







$json_arr=json_encode($a);


$_SESSION['email_data']=$json_arr;
$_SESSION['src_of_mail']=$_FILES['file']['name'];


  }else{
    $status=2;
     
  }

 }else{





$status=3;

 }
}else{



$status=4;

    
}

echo $status;


?>


