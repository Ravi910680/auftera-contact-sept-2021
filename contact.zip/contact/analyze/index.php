



<?php
session_start();
require("../confige/fileconfige.php");


    $mail=$_SESSION["email"];
    $id=$_SESSION["id"];



?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">

<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">


  <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />

  <link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1603531914/norm_used/loader_ww3kih.css">

<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>


<style>

@import url(https://fonts.googleapis.com/css?family=Arvo);
@import url(http://fonts.googleapis.com/css?family=Varela+Round);
.tablediv{
    padding:10%;
}
tr{

border:1px solid #dedddc;
}


.con-of-tbl{
background:white;
border-radius:4px;
}

.col-header th{
padding-top:1rem !important;
padding-bottom:1rem !important;
}
.col-header{


color: white;
    font-size: 20px !important;
    background: darkcyan;
    font-weight: 700 !important;


}
.first-col{

display: block;
    
    width: 95%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

body{




webkit-font-smoothing: antialiased;}
.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{

border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#007c89;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;
    cursor:pointer;

}
.card:hover{
    cursor:default;
}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}


























.head-dash{
  font-family: 'Karla', sans-serif;
  font-size: 23px;
  color: #000000e0;
  width:50%;
}
body{
	
}

.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}

.row{
	width:100%;
	margin-left:0px;
	margin-right: 0px;
}
.head-con-rw{
	padding-top: 20px;
	padding-bottom: 20px;
}
.btn-con-top{
	width: 50%;
}

.bottom-btn:hover{
	cursor: pointer;
}







body{




webkit-font-smoothing: antialiased;}
.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{
border-radius:4px;
border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#085861;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}








.con-of-dash-data{
	width:25%;
	margin: 0px auto;


}
.con-ch-dast-data{
text-align: center;
	border-radius: 5px;
	background:white;
	margin: 20px;

}

.icon-data-con{

	padding-top: 20px;
    padding-bottom: 20px;
}



.ico-fa-data{

	display: table-cell;
	vertical-align: middle;

    font-size: 30px;

    height: 60px;
    width:60px;
}




.con-ico-data{


    width: fit-content;
    margin: 0px auto;
    border-radius: 50%;
    height: 60px;
    width:60px;
}

.data-info-text{
  color: black;
  font-size: 37px;
  font-weight: bolder;
  padding-top: 10px;
    padding-bottom: 10px;
}

.data-head-line{
  padding-top: 10px;
    padding-bottom: 20px;
  color: #04040485;
    font-weight: 600;
}


.head-of-over{
  font-family: 'Karla', sans-serif;
  font-size: 20px;
  color: #000000e0;
  padding-top: 20px;
}



.table{
margin-bottom:0px;
}











.data-tbl-db{
 
  background: white;
  border-radius: 5px;
  
}

.data-belo-line{

    width: 500px;
    overflow: scroll;
    font-weight: 600;
    color: #0000006b;
}

.tbl-main-head{
  color: #000000cc;
    font-weight: bolder;
width: 200px;
    overflow-x: scroll;
    font-size: 13px;
}
.tbl-main-head::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE and Edge */
.tbl-main-head {
  -ms-overflow-style: none;
}

.tbl-link-clr{
  color: blue;
transition:.2s;



}


.tbl-link-clr:hover{
color:black;

}











.not-fd-data{
  text-align: center;
background:white;
border-radius:4px;

padding:20px;





}








.txt-not-fd{
  padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
}

















@import url(https://fonts.googleapis.com/css?family=Josefin+Sans);


.nav-link:hover{
    cursor:pointer;
}

ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;

}
.addsiteheadbtn:hover{
    color:black;
    cursor:pointer;
    background:#d9d7cd;

}


td{
vertical-align: middle;

}

html{
background;#f0f8ffcf;
}

#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
.con-of-tbl{
background:white;
border-radius:4px;
}



.navbar{
  position: relative !important;
}












button.btn_hover_clr {
    margin-top: 10px;

        background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    color: #1a73e8;
    font-size: 13px;
    font-weight: 500;
    background: white;
  }

  

button.btn_hover_clr:hover {
    background: #e8f0fe;
    cursor: pointer;
  }



.table td, .table th {
    font-size: 16px;
    white-space: nowrap;

  }












.tooltip2 .tooltiptext {
    visibility: hidden;
    width: 120px;
    font-size: 13px;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;
    position: absolute;
    z-index: 1;
    margin-left: -60px;
    margin-top: 20px;
    font-family: 'IBM Plex Sans', sans-serif;
    font-weight: 500;
  }
.tooltip2:hover .tooltiptext {
  visibility: visible;
}













.lds-color div{

border: 2px solid #4a154bd9;border-color: #4a154bd9 transparent transparent transparent !important;

}


.lds-pos-cht{

  top: 50%;
  left: 50%;
}

.lds-pos-bg{
top: 50%;

}

.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid white;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

.lds-large div{
  width: 40px;
  height: 40px;
  border: 4px solid;

}



.lds-large {
    margin: auto;
    
    width: 40px;
    height: 40px;

  }

.main-content {
  height: 92vh;
  overflow: scroll;
}

   .lds-main-large{
top: 300px;
    left: 50%;

  }







i:hover{

  cursor: pointer;

}






.card{
  height: min-content;
  width: 45%;
  border: 1px solid rgb(0 0 0 / 18%);

  
}

.head-cons-desg{
  padding: 50px 0px;
}

.card-img-top{

    padding: 40px;


}

.card-body{
  text-align: center;
}

.card-text{
  font-weight: 500;
  color: black;
}

.card-title {
    margin-bottom: 1.25rem;
    font-size: 20px;
color: black;
    }

    a.crt-api-btn {
    color: #3368fa;
    background-color: #fff;
    border-color: #3368fa;
    font-family: Colfax-Bold,Helvetica,Arial,sans-serif;
    font-style: normal;
    font-weight: 600;
    display: inline-block;
    padding: 12px 32px;
    font-size: 16px;
    line-height: normal;
    text-align: center;
    border: 2px solid transparent;
    border-radius: 3px;
    outline: 0;
    box-shadow: 0 2px 4px 0 #c8d7ee;
    transition: all .2s ease-in-out;
    border: 2px solid;

  }



.container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 30px 36px;
    border-bottom: 1px solid #dedddc;
  }

.container-2GnNH span{

font-size: 13px;

}









.modal-2 {
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 0vh;
  background-color: transparent;
  overflow: hidden;
  transition: background-color 0.25s ease;
  z-index: 9999;
}
.modal-2.open {
  position: fixed;
  width: 100%;
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.5);
  transition: background-color 0.25s;
}
.modal-2.open > .content-wrapper {
  transform: scale(1);
}
.modal-2 .content-wrapper {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  width: 40%;
  margin: 0;
  padding: 2.5rem;
  background-color: white;
  border-radius: 0.3125rem;
  box-shadow: 0 0 2.5rem rgba(0, 0, 0, 0.5);
  transform: scale(0);
  transition: transform 0.25s;
  transition-delay: 0.15s;
}
.modal-2 .content-wrapper .close {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 2.5rem;
  height: 2.5rem;
  border: none;
  background-color: transparent;
  font-size: 1.5rem;
  transition: 0.25s linear;
}
.modal-2 .content-wrapper .close:before, .modal-2 .content-wrapper .close:after {
  position: absolute;
  content: '';
  width: 1.25rem;
  height: 0.125rem;
  background-color: black;
}
.modal-2 .content-wrapper .close:before {
  transform: rotate(-45deg);
}
.modal-2 .content-wrapper .close:after {
  transform: rotate(45deg);
}
.modal-2 .content-wrapper .close:hover:before, .modal-2 .content-wrapper .close:hover:after {
  background-color: tomato;
}
.modal-2 .content-wrapper .modal-2-header {
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  margin: 0;
  padding: 0 0 1.25rem;
}
.modal-2 .content-wrapper .modal-2-header h2 {
  font-size: 1.5rem;
  font-weight: bold;
}
.modal-2 .content-wrapper .content {
  position: relative;
  display: flex;
}
.modal-2 .content-wrapper .content p {
  font-size: 0.875rem;
  line-height: 1.75;
}
.modal-2 .content-wrapper .modal-2-footer {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  width: 100%;
  margin: 0;
  padding: 1.875rem 0 0;
}
.modal-2 .content-wrapper .modal-2-footer .action {
  position: relative;
  margin-left: 0.625rem;
  padding: 0.625rem 1.25rem;
  border: none;
  background-color: slategray;
  border-radius: 0.25rem;
  color: white;
  font-size: 0.87rem;
  font-weight: 300;
  overflow: hidden;
  z-index: 1;
}
.modal-2 .content-wrapper .modal-2-footer .action:before {
  position: absolute;
  content: '';
  top: 0;
  left: 0;
  width: 0%;
  height: 100%;
  background-color: rgba(255, 255, 255, 0.2);
  transition: width 0.25s;
  z-index: 0;
}
.modal-2 .content-wrapper .modal-2-footer .action:first-child {
  background-color: #2ecc71;
}
.modal-2 .content-wrapper .modal-2-footer .action:last-child {
  background-color: #e74c3c;
}
.modal-2 .content-wrapper .modal-2-footer .action:hover:before {
  width: 100%;
}






.modal-2-header h2{

  color: black;
}




.full-mdl-con-lrg {
    width: 100%;
    height: 60vh;
    background: white;
border-radius: 10px;
  }

  .tw-rw-mdl-con {
    width: 49.7%;
    height: 60vh;
    display: inline-block;
    overflow: scroll;
    padding: 40px;
  }
  p.mdl-lrg-notc-txt {
    font-size: 13px;
    color: #565454;
    font-weight: 500;
    }


.tbl-link-clr:hover{
  cursor: pointer;
}







.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000b5;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    
    z-index: 100000000;
}

#cncl-err-msg:hover{


cursor: pointer;


}



.vert-cent-div {
  
  height: min-content;
  text-align: center;
  
  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
    
  margin: auto;
}



.con-lst-res-data {
    width: 75%;
    height: 92vh;
 overflow: scroll;

  }

  .con-of-nav-con-data {
    width: 25%;
    height: 92vh;
  }

  div#main-content {
    display: flex;
   
  }


.bottom-btn {
    position: relative;
    display: inline-block;
    padding: 5px 16px;
    font-size: 12px;
    font-weight: 500;
    line-height: 20px;
    white-space: nowrap;
    vertical-align: middle;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    border: 1px solid;
    border-radius: 6px;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    height: 5vh;
  }

  .back_wt_con {
    color: #24292e;
    background-color: #fafbfc;
    border-color: #1b1f2326;
    height: fit-content;
    font-family: -apple-system,BlinkMacSystemFont,Segoe UI,Helvetica,Arial,sans-serif,Apple Color Emoji,Segoe UI emoji;
  }
.back_wt_con:hover{
  background-color: #f3f4f6;
  border-color: #1b1f2326;
  transition-duration: .1s;
}




#main-loader-containre-act{


     
    
  }

.main-loader-containre-act{
 
 text-align: center !important;padding-top: 41vh !important;height: 84vh !important;display: block !important;

}


nav.side-nav-of-hlp {
    width: 80%;
    margin: auto;
    margin-top: 50%;
    border: 1px solid #eaecef;
    border-radius: 6px;
  }

  a.side-nav-hrf {
    display: block;
    padding: 12px 16px;
    color: #24292e !important;
    border-top: 1px solid #eaecef;
    font-size: 12px;
    line-height: 1.5;
    background: #fafbfc;
    font-weight: 400;
     font-family: -apple-system,BlinkMacSystemFont,Segoe UI,Helvetica,Arial,sans-serif,Apple Color Emoji,Segoe UI Emoji;
     transition:.2s;
  }

  a.side-nav-hrf:hover{
    cursor: pointer;
    background: white;
  }


.act-of-sd-nav{
  border-left: 2px solid #d25841;
    background: white !important;
}


.main-dash-of-ana {
    padding: 20px;
    margin: 0px 10px;
  }

.main-con-prev-ovw {
    margin: 0px 30px;
  }


  .main-pre-ovw-hed {
    padding: 16px;
    
    background: #f6f8fa;
    border: 1px solid #e1e4e8;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;

  }

  h3.tlt-of-had {
    margin: 0px;
    font-size: 14px;
    font-family: -apple-system,BlinkMacSystemFont,Segoe UI,Helvetica,Arial,sans-serif,Apple Color Emoji,Segoe UI emoji;
    color: #24292e;

  }


  .ovr-vie-db-ana-data {
    display: flex;
    border: 1px solid #e1e4e8;
    border-bottom-right-radius: 6px;
    border-bottom-left-radius: 6px;
  }

  .con-of-pro-br {
    width: 50%;
    margin: 0px;
    padding: 20px;
  }

  .data-of-txt-nw {
    font-size: 13px;
    font-weight: 600;
    color: black;
    padding-top: 5px;
    font-family: font-family: -apple-system,BlinkMacSystemFont,Segoe UI,Helvetica,Arial,sans-serif,Apple Color Emoji,Segoe UI emoji;
  }
  .progress {
    margin: 0px;
  }
  .ana-cht-con{
    margin:30px;
    display: flex;
  }

  .con-of-min-div-chrt {
    
   width: 100%;

  }

  .all-top-data-of-ana {
    margin: 30px;
    display: flex;

  }
  .flx-data-of-chrt{
    width: 100%;
  }

  .main-con-of-txt-tbl-dt{
    width: 49%;
  }


  .con-of-stat-data {
    padding: 20px;
    font-size: 15px;
    font-weight: 800;
    color: darkmagenta;
    width: 100%;
    border-bottom: 1px solid #e1e4e8;

  }
  .all-stat-con-per{
    display: none;
  }

  .not-fd-stat-data {
    width: 100%;
    text-align: center;
    padding: 40px;
     color: #a2a0a0;
  }

  .not-fd-stat-txt {
    font-size: 13px;
    font-weight: 600;

  }
</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">

  <!-- CSS Files -->

</head>

<body class="" style="">
  
<?php require("../confige/header/header.php");?>





<div class="vert-cent-div err-menu-cls-dsg" id="err_msg_dt_trg" style="display: none;">
<span id="con-of-err-msg"></span>
<span class="cls-err-menu" id="cncl-err-msg">
<i class="fal fa-times-circle" style="
    padding: 6px;
"></i>
</span>
</div>


<div id='main-content'>


<div class='con-of-nav-con-data'>



  <nav class="side-nav-of-hlp">
    
        <a class="side-nav-hrf com-for-lnk" data-for-serv="0"  data-target-link="https://contact.<?php echo $url_main;?>/contact/#acl" id='acl'>All Contact List</a>
        <a class="side-nav-hrf" id='ac'>Analyze Campign</a>
        <a class="side-nav-hrf" id='hml'>Help To Manage List</a>
        <a class="side-nav-hrf" id='agw'>Analyze In Good way</a>
    
    
    </nav>

</div>
<div class='con-lst-res-data' id='main-loader-containre'>

  

<div class="main-dash-of-ana" style="
">
    
    









<div class="dropdown" style="
    margin-right: 20px;
">
        <button class="bottom-btn back_wt_con" id='btn-of-camp-name' data-toggle="dropdown" aria-expanded="false">Campign Performance <span class="dropdown-caret"></span></button>
        <div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(0px, 32px, 0px);" id='camp_dt_con_all'>
         

    </div>
  </div>


  <div class="dropdown">
        <button class="bottom-btn back_wt_con" id='lst_name_con' data-toggle="dropdown" aria-expanded="false">In List <span class="dropdown-caret"></span></button>
        <div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(0px, 32px, 0px);" id='lst_of_rlt_camp'>
         



    </div>
  </div>


  <div class="dropdown" style="
    float:right;
">
        <button class="bottom-btn back_wt_con" id="btn-of-camp-name" data-toggle="dropdown" aria-expanded="true"> <span class="padding-left:10px;"> Filter data </span><span class="dropdown-caret"></span></button>
        <div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(0px, 32px, 0px);" >
        <button class="dropdown-item chg_data_ana_dash_chrt" data-target="hr"> <span class="padding-left:10px;"> Hour  </span></button>
       <button class="dropdown-item chg_data_ana_dash_chrt" data-target="day"> <span class="padding-left:10px;"> day </span></button>
       <button class="dropdown-item chg_data_ana_dash_chrt" data-target="month"> <span class="padding-left:10px;"> Month  </span></button>

  </div>


    </div>

</div>



<div class="main-con-prev-ovw">

    <div class="main-pre-ovw-hed">
    
        <h3 class="tlt-of-had">Overview</h3>
    
    </div>

   



<div class="ovr-vie-db-ana-data">

<div class="con-of-pro-br ">
      <div class="progress">
  <div class="progress-bar" role="progressbar" id='opn_lst_prgs_bar' style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
</div>

<div class="data-of-txt-nw">

    <span id='opn-txt-id-con'>0</span> Open in List For

</div>
</div>


<div class="con-of-pro-br ">
      <div class="progress">
  <div class="progress-bar" role="progressbar" id='clck_lst_prgs_bar' style="width: 60%;background: red;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" ></div>
</div>

<div class="data-of-txt-nw">

    <span id='clck-txt-id-con'>0</span> Click in List For

</div>
</div>



    </div>




</div>


<div class='ana-cht-con'>



<div class="con-of-min-div-chrt" style="
    margin-right: auto;
">

<div class="main-pre-ovw-hed">
    
        <h3 class="tlt-of-had">Performance Chart</h3>
    
    </div>


<div class="ovr-vie-db-ana-data" style='background:#f1f8e9;'>


<div class='cnvs-man-of-chrt' id='chrt_con_od_id' style="margin: auto;
    margin-top: 30px;
    margin-bottom: 30px;display:none;">
    <div id="curve_chart" ></div>

</div>










<div id="con-of-all-chrt-and-ana-dt" style='width:100%;'>


<div class="not-fd-stat-data">
    
        
        <svg width="50" height="50" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.4695 11.2929C15.0789 10.9024 14.4458 10.9024 14.0553 11.2929C13.6647 11.6834 13.6647 12.3166 14.0553 12.7071C14.4458 13.0976 15.0789 13.0976 15.4695 12.7071C15.86 12.3166 15.86 11.6834 15.4695 11.2929Z" fill="currentColor"></path><path d="M16.1766 9.17156C16.5671 8.78103 17.2003 8.78103 17.5908 9.17156C17.9813 9.56208 17.9813 10.1952 17.5908 10.5858C17.2003 10.9763 16.5671 10.9763 16.1766 10.5858C15.7861 10.1952 15.7861 9.56208 16.1766 9.17156Z" fill="currentColor"></path><path d="M19.7121 11.2929C19.3216 10.9024 18.6885 10.9024 18.2979 11.2929C17.9074 11.6834 17.9074 12.3166 18.2979 12.7071C18.6885 13.0976 19.3216 13.0976 19.7121 12.7071C20.1027 12.3166 20.1027 11.6834 19.7121 11.2929Z" fill="currentColor"></path><path d="M16.1766 13.4142C16.5671 13.0237 17.2003 13.0237 17.5908 13.4142C17.9813 13.8048 17.9813 14.4379 17.5908 14.8284C17.2003 15.219 16.5671 15.219 16.1766 14.8284C15.7861 14.4379 15.7861 13.8048 16.1766 13.4142Z" fill="currentColor"></path><path d="M6 13H4V11H6V9H8V11H10V13H8V15H6V13Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M7 5C3.13401 5 0 8.13401 0 12C0 15.866 3.13401 19 7 19H17C20.866 19 24 15.866 24 12C24 8.13401 20.866 5 17 5H7ZM17 7H7C4.23858 7 2 9.23858 2 12C2 14.7614 4.23858 17 7 17H17C19.7614 17 22 14.7614 22 12C22 9.23858 19.7614 7 17 7Z" fill="currentColor"></path></svg>
        
        <br>
        
        <div class="not-fd-stat-txt">Not Get Any Response data</div>
    
    
    </div>

</div>







</div>




</div>




</div>



<div class='all-top-data-of-ana all-stat-con-per' id='month-con-stat'>


<div class='main-con-of-txt-tbl-dt' style='margin-right:auto;'>
<div class="main-pre-ovw-hed flx-data-of-chrt" >
    
        <h3 class="tlt-of-had">Best Month For Click</h3>
    
    </div>

    <div class="ovr-vie-db-ana-data" id='monthclick' style=''>


<div class="not-fd-stat-data">
    
        
        <svg width="50" height="50" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.4695 11.2929C15.0789 10.9024 14.4458 10.9024 14.0553 11.2929C13.6647 11.6834 13.6647 12.3166 14.0553 12.7071C14.4458 13.0976 15.0789 13.0976 15.4695 12.7071C15.86 12.3166 15.86 11.6834 15.4695 11.2929Z" fill="currentColor"></path><path d="M16.1766 9.17156C16.5671 8.78103 17.2003 8.78103 17.5908 9.17156C17.9813 9.56208 17.9813 10.1952 17.5908 10.5858C17.2003 10.9763 16.5671 10.9763 16.1766 10.5858C15.7861 10.1952 15.7861 9.56208 16.1766 9.17156Z" fill="currentColor"></path><path d="M19.7121 11.2929C19.3216 10.9024 18.6885 10.9024 18.2979 11.2929C17.9074 11.6834 17.9074 12.3166 18.2979 12.7071C18.6885 13.0976 19.3216 13.0976 19.7121 12.7071C20.1027 12.3166 20.1027 11.6834 19.7121 11.2929Z" fill="currentColor"></path><path d="M16.1766 13.4142C16.5671 13.0237 17.2003 13.0237 17.5908 13.4142C17.9813 13.8048 17.9813 14.4379 17.5908 14.8284C17.2003 15.219 16.5671 15.219 16.1766 14.8284C15.7861 14.4379 15.7861 13.8048 16.1766 13.4142Z" fill="currentColor"></path><path d="M6 13H4V11H6V9H8V11H10V13H8V15H6V13Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M7 5C3.13401 5 0 8.13401 0 12C0 15.866 3.13401 19 7 19H17C20.866 19 24 15.866 24 12C24 8.13401 20.866 5 17 5H7ZM17 7H7C4.23858 7 2 9.23858 2 12C2 14.7614 4.23858 17 7 17H17C19.7614 17 22 14.7614 22 12C22 9.23858 19.7614 7 17 7Z" fill="currentColor"></path></svg>
        
        <br>
        
        <div class="not-fd-stat-txt">Not Get Any Response data</div>
    
    
    </div>


</div>

</div>

    <div class='main-con-of-txt-tbl-dt'>
<div class="main-pre-ovw-hed flx-data-of-chrt" >
    
        <h3 class="tlt-of-had">Best Month For Open</h3>
    
    </div>

    <div class="ovr-vie-db-ana-data" id='monthopen' >


<div class="not-fd-stat-data">
    
        
        <svg width="50" height="50" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.4695 11.2929C15.0789 10.9024 14.4458 10.9024 14.0553 11.2929C13.6647 11.6834 13.6647 12.3166 14.0553 12.7071C14.4458 13.0976 15.0789 13.0976 15.4695 12.7071C15.86 12.3166 15.86 11.6834 15.4695 11.2929Z" fill="currentColor"></path><path d="M16.1766 9.17156C16.5671 8.78103 17.2003 8.78103 17.5908 9.17156C17.9813 9.56208 17.9813 10.1952 17.5908 10.5858C17.2003 10.9763 16.5671 10.9763 16.1766 10.5858C15.7861 10.1952 15.7861 9.56208 16.1766 9.17156Z" fill="currentColor"></path><path d="M19.7121 11.2929C19.3216 10.9024 18.6885 10.9024 18.2979 11.2929C17.9074 11.6834 17.9074 12.3166 18.2979 12.7071C18.6885 13.0976 19.3216 13.0976 19.7121 12.7071C20.1027 12.3166 20.1027 11.6834 19.7121 11.2929Z" fill="currentColor"></path><path d="M16.1766 13.4142C16.5671 13.0237 17.2003 13.0237 17.5908 13.4142C17.9813 13.8048 17.9813 14.4379 17.5908 14.8284C17.2003 15.219 16.5671 15.219 16.1766 14.8284C15.7861 14.4379 15.7861 13.8048 16.1766 13.4142Z" fill="currentColor"></path><path d="M6 13H4V11H6V9H8V11H10V13H8V15H6V13Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M7 5C3.13401 5 0 8.13401 0 12C0 15.866 3.13401 19 7 19H17C20.866 19 24 15.866 24 12C24 8.13401 20.866 5 17 5H7ZM17 7H7C4.23858 7 2 9.23858 2 12C2 14.7614 4.23858 17 7 17H17C19.7614 17 22 14.7614 22 12C22 9.23858 19.7614 7 17 7Z" fill="currentColor"></path></svg>
        
        <br>
        
        <div class="not-fd-stat-txt">Not Get Any Response data</div>
    
    
    </div>


</div>

</div>




</div>


<div class='all-top-data-of-ana all-stat-con-per' id='day-con-stat'>


<div class='main-con-of-txt-tbl-dt' style='margin-right:auto;'>
<div class="main-pre-ovw-hed flx-data-of-chrt" >
    
        <h3 class="tlt-of-had">Best Day For Click</h3>
    
    </div>

    <div class="ovr-vie-db-ana-data" id='dayclick' style=''>


<div class="not-fd-stat-data">
    
        
        <svg width="50" height="50" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.4695 11.2929C15.0789 10.9024 14.4458 10.9024 14.0553 11.2929C13.6647 11.6834 13.6647 12.3166 14.0553 12.7071C14.4458 13.0976 15.0789 13.0976 15.4695 12.7071C15.86 12.3166 15.86 11.6834 15.4695 11.2929Z" fill="currentColor"></path><path d="M16.1766 9.17156C16.5671 8.78103 17.2003 8.78103 17.5908 9.17156C17.9813 9.56208 17.9813 10.1952 17.5908 10.5858C17.2003 10.9763 16.5671 10.9763 16.1766 10.5858C15.7861 10.1952 15.7861 9.56208 16.1766 9.17156Z" fill="currentColor"></path><path d="M19.7121 11.2929C19.3216 10.9024 18.6885 10.9024 18.2979 11.2929C17.9074 11.6834 17.9074 12.3166 18.2979 12.7071C18.6885 13.0976 19.3216 13.0976 19.7121 12.7071C20.1027 12.3166 20.1027 11.6834 19.7121 11.2929Z" fill="currentColor"></path><path d="M16.1766 13.4142C16.5671 13.0237 17.2003 13.0237 17.5908 13.4142C17.9813 13.8048 17.9813 14.4379 17.5908 14.8284C17.2003 15.219 16.5671 15.219 16.1766 14.8284C15.7861 14.4379 15.7861 13.8048 16.1766 13.4142Z" fill="currentColor"></path><path d="M6 13H4V11H6V9H8V11H10V13H8V15H6V13Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M7 5C3.13401 5 0 8.13401 0 12C0 15.866 3.13401 19 7 19H17C20.866 19 24 15.866 24 12C24 8.13401 20.866 5 17 5H7ZM17 7H7C4.23858 7 2 9.23858 2 12C2 14.7614 4.23858 17 7 17H17C19.7614 17 22 14.7614 22 12C22 9.23858 19.7614 7 17 7Z" fill="currentColor"></path></svg>
        
        <br>
        
        <div class="not-fd-stat-txt">Not Get Any Response data</div>
    
    
    </div>



</div>

</div>

    <div class='main-con-of-txt-tbl-dt'>
<div class="main-pre-ovw-hed flx-data-of-chrt" >
    
        <h3 class="tlt-of-had">Best Day For Open</h3>
    
    </div>

    <div class="ovr-vie-db-ana-data" id='dayopen' >



<div class="not-fd-stat-data">
    
        
        <svg width="50" height="50" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.4695 11.2929C15.0789 10.9024 14.4458 10.9024 14.0553 11.2929C13.6647 11.6834 13.6647 12.3166 14.0553 12.7071C14.4458 13.0976 15.0789 13.0976 15.4695 12.7071C15.86 12.3166 15.86 11.6834 15.4695 11.2929Z" fill="currentColor"></path><path d="M16.1766 9.17156C16.5671 8.78103 17.2003 8.78103 17.5908 9.17156C17.9813 9.56208 17.9813 10.1952 17.5908 10.5858C17.2003 10.9763 16.5671 10.9763 16.1766 10.5858C15.7861 10.1952 15.7861 9.56208 16.1766 9.17156Z" fill="currentColor"></path><path d="M19.7121 11.2929C19.3216 10.9024 18.6885 10.9024 18.2979 11.2929C17.9074 11.6834 17.9074 12.3166 18.2979 12.7071C18.6885 13.0976 19.3216 13.0976 19.7121 12.7071C20.1027 12.3166 20.1027 11.6834 19.7121 11.2929Z" fill="currentColor"></path><path d="M16.1766 13.4142C16.5671 13.0237 17.2003 13.0237 17.5908 13.4142C17.9813 13.8048 17.9813 14.4379 17.5908 14.8284C17.2003 15.219 16.5671 15.219 16.1766 14.8284C15.7861 14.4379 15.7861 13.8048 16.1766 13.4142Z" fill="currentColor"></path><path d="M6 13H4V11H6V9H8V11H10V13H8V15H6V13Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M7 5C3.13401 5 0 8.13401 0 12C0 15.866 3.13401 19 7 19H17C20.866 19 24 15.866 24 12C24 8.13401 20.866 5 17 5H7ZM17 7H7C4.23858 7 2 9.23858 2 12C2 14.7614 4.23858 17 7 17H17C19.7614 17 22 14.7614 22 12C22 9.23858 19.7614 7 17 7Z" fill="currentColor"></path></svg>
        
        <br>
        
        <div class="not-fd-stat-txt">Not Get Any Response data</div>
    
    
    </div>


</div>

</div>




</div>



<div class='all-top-data-of-ana all-stat-con-per' id='hr-con-stat'>


<div class='main-con-of-txt-tbl-dt' style='margin-right:auto;'>
<div class="main-pre-ovw-hed flx-data-of-chrt" >
    
        <h3 class="tlt-of-had">Best Hour For Click</h3>
    
    </div>

    <div class="ovr-vie-db-ana-data" id='hrclick' style=''>


<div class="not-fd-stat-data">
    
        
        <svg width="50" height="50" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.4695 11.2929C15.0789 10.9024 14.4458 10.9024 14.0553 11.2929C13.6647 11.6834 13.6647 12.3166 14.0553 12.7071C14.4458 13.0976 15.0789 13.0976 15.4695 12.7071C15.86 12.3166 15.86 11.6834 15.4695 11.2929Z" fill="currentColor"></path><path d="M16.1766 9.17156C16.5671 8.78103 17.2003 8.78103 17.5908 9.17156C17.9813 9.56208 17.9813 10.1952 17.5908 10.5858C17.2003 10.9763 16.5671 10.9763 16.1766 10.5858C15.7861 10.1952 15.7861 9.56208 16.1766 9.17156Z" fill="currentColor"></path><path d="M19.7121 11.2929C19.3216 10.9024 18.6885 10.9024 18.2979 11.2929C17.9074 11.6834 17.9074 12.3166 18.2979 12.7071C18.6885 13.0976 19.3216 13.0976 19.7121 12.7071C20.1027 12.3166 20.1027 11.6834 19.7121 11.2929Z" fill="currentColor"></path><path d="M16.1766 13.4142C16.5671 13.0237 17.2003 13.0237 17.5908 13.4142C17.9813 13.8048 17.9813 14.4379 17.5908 14.8284C17.2003 15.219 16.5671 15.219 16.1766 14.8284C15.7861 14.4379 15.7861 13.8048 16.1766 13.4142Z" fill="currentColor"></path><path d="M6 13H4V11H6V9H8V11H10V13H8V15H6V13Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M7 5C3.13401 5 0 8.13401 0 12C0 15.866 3.13401 19 7 19H17C20.866 19 24 15.866 24 12C24 8.13401 20.866 5 17 5H7ZM17 7H7C4.23858 7 2 9.23858 2 12C2 14.7614 4.23858 17 7 17H17C19.7614 17 22 14.7614 22 12C22 9.23858 19.7614 7 17 7Z" fill="currentColor"></path></svg>
        
        <br>
        
        <div class="not-fd-stat-txt">Not Get Any Response data</div>
    
    
    </div>


</div>

</div>

    <div class='main-con-of-txt-tbl-dt'>
<div class="main-pre-ovw-hed flx-data-of-chrt" >
    
        <h3 class="tlt-of-had">Best Hour For Open</h3>
    
    </div>

    <div class="ovr-vie-db-ana-data" id='hropen' >


<div class="not-fd-stat-data">
    
        
        <svg width="50" height="50" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.4695 11.2929C15.0789 10.9024 14.4458 10.9024 14.0553 11.2929C13.6647 11.6834 13.6647 12.3166 14.0553 12.7071C14.4458 13.0976 15.0789 13.0976 15.4695 12.7071C15.86 12.3166 15.86 11.6834 15.4695 11.2929Z" fill="currentColor"></path><path d="M16.1766 9.17156C16.5671 8.78103 17.2003 8.78103 17.5908 9.17156C17.9813 9.56208 17.9813 10.1952 17.5908 10.5858C17.2003 10.9763 16.5671 10.9763 16.1766 10.5858C15.7861 10.1952 15.7861 9.56208 16.1766 9.17156Z" fill="currentColor"></path><path d="M19.7121 11.2929C19.3216 10.9024 18.6885 10.9024 18.2979 11.2929C17.9074 11.6834 17.9074 12.3166 18.2979 12.7071C18.6885 13.0976 19.3216 13.0976 19.7121 12.7071C20.1027 12.3166 20.1027 11.6834 19.7121 11.2929Z" fill="currentColor"></path><path d="M16.1766 13.4142C16.5671 13.0237 17.2003 13.0237 17.5908 13.4142C17.9813 13.8048 17.9813 14.4379 17.5908 14.8284C17.2003 15.219 16.5671 15.219 16.1766 14.8284C15.7861 14.4379 15.7861 13.8048 16.1766 13.4142Z" fill="currentColor"></path><path d="M6 13H4V11H6V9H8V11H10V13H8V15H6V13Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M7 5C3.13401 5 0 8.13401 0 12C0 15.866 3.13401 19 7 19H17C20.866 19 24 15.866 24 12C24 8.13401 20.866 5 17 5H7ZM17 7H7C4.23858 7 2 9.23858 2 12C2 14.7614 4.23858 17 7 17H17C19.7614 17 22 14.7614 22 12C22 9.23858 19.7614 7 17 7Z" fill="currentColor"></path></svg>
        
        <br>
        
        <div class="not-fd-stat-txt">Not Get Any Response data</div>
    
    
    </div>


</div>

</div>




</div>


</div>






</div>








<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>
  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
  <script>
json_email_camp_data="";

trg_camp_id="";

json_lst_camp_data="";



data_of_ana_db_new=[];

jsn_of_ana_data_txt="";


label_of_chrt={day:['Sun','Mon','Tue','Wen','Thu','fry','Sat'],hr:['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24'],month:['January','February','March','April','May','June','July','August','September','Octomber','November','December']};



function init_act_str(){


id_now_path= window.location.href.split('#');
    console.log(id_now_path.length);
    for(i=0;i<id_now_path.length-1;i++){
            
            $("#"+$.escapeSelector(id_now_path[i+1])).addClass("act-of-sd-nav");
            

    }


}


function get_camp_name () {
	


$.ajax({
                url : "./ajaxfile/get_all_mail_camp.php",
                type: "GET",
                data : "requestoflist=no"
        }).done(function(response){ 

json_email_camp_data=JSON.parse(response).email_camp;


init_camp_data_str();

        });
  



}

function init_camp_data_str(){

str_crt="";

for (var i = 0; i < json_email_camp_data.length; i++) {
  


str_crt+='<button class="dropdown-item chg_camp_in_ana_dash" data-target="'+json_email_camp_data[i].camp_contact_id+'"> <span class="padding-left:10px;"> '+json_email_camp_data[i].camp_name.split("^")[1]+' </span></button>';

};


$("#camp_dt_con_all").html(str_crt);

}


$(document).ready(function(){

get_camp_name ();


})



function init_str_of_lst_camp_rlt(){

str_app="";

for (var i = 0; i < json_lst_camp_data.length; i++) {
  

name_of_lst=atob(json_lst_camp_data[i].list_id.split("^")[1]);

str_app+='<button class="dropdown-item chg_lst_name_ana" data-target="'+json_lst_camp_data[i].list_id+'"> <span class="padding-left:10px;">'+name_of_lst+'</span></button>';

};


$("#lst_of_rlt_camp").html(str_app);


}


function get_lst_name_rlt_in_camp(){





$.ajax({
                url : "./ajaxfile/get_all_lst_with_camp.php",
                type: "GET",
                data : "camp_id="+trg_camp_id
        }).done(function(response){ 

console.log(JSON.parse(response));

json_lst_camp_data=JSON.parse(response);

init_str_of_lst_camp_rlt();
        });
  






}







$(document).on('click',".chg_camp_in_ana_dash",function(){


init_btn_txt_in_chg("#btn-of-camp-name",$(this).html());

trg_camp_id=$(this).attr("data-target");



get_lst_name_rlt_in_camp();


})



function get_ana_dash_data(){

name_tbl=trg_camp_id+"#"+trg_lst_id;

console.log(name_tbl);

$.ajax({
                url : "./ajaxfile/get_ana_data_of_camp_lst.php",
                type: "GET",
                data : "tbl_name_of_ana="+btoa(name_tbl)
        }).done(function(response){ 
console.log(response);
console.log(JSON.parse(response));

jsn_of_ana_data_txt=response;

data_of_ana_db_new=JSON.parse(response);



get_arr_of_passed_data('month');



sml_data_hider=data_of_ana_db_new;


init_prgs_bar_in_dash(sml_data_hider);


get_best_mnth('month','click','https://res.cloudinary.com/heptera/image/upload/v1607150764/icon-svg/calendar-dates_ca6xa0.svg');

get_best_mnth('month','open','https://res.cloudinary.com/heptera/image/upload/v1607159114/icon-svg/alarm_yh71rb.svg');



        });
  





}


function init_prgs_bar_in_dash(data_res){

console.log(data_res);
opn_all=data_res.count.open_count;
clck_all=data_res.count.click_count;

opn_rat=(opn_all/(opn_all+clck_all))*100;
clck_rat=(clck_all/(opn_all+clck_all))*100;


console.log(clck_rat);


$("#clck_lst_prgs_bar").css('width',clck_rat+"%");
$("#opn_lst_prgs_bar").css('width',opn_rat+"%");

$("#clck-txt-id-con").html(clck_all);
$("#opn-txt-id-con").html(opn_all);
}


$(document).on('click','.chg_lst_name_ana',function(){

init_btn_txt_in_chg("#lst_name_con",$(this).html());

trg_lst_id=$(this).attr('data-target');
get_ana_dash_data();


})


function init_btn_txt_in_chg(thisv,txt){
  $(thisv).html(txt+'<span class="dropdown-caret"></span>');
}



function get_arr_of_passed_data(arr_fld){



data_of_ana_db_new=JSON.parse(jsn_of_ana_data_txt);


clck_data=data_of_ana_db_new[arr_fld]['click'];

opn_data=data_of_ana_db_new[arr_fld]['open'];


ret_data=[];

ret_data=[['Period','Open','Click']];


for (var i = 0; i < clck_data.length; i++) {
  
ret_data.push([label_of_chrt[arr_fld][i],opn_data[i],clck_data[i]]);



};



crt_chart_in_ana_data(ret_data);



}


$(document).on('click','.chg_data_ana_dash_chrt',function(){


trg_data=$(this).attr('data-target');

get_arr_of_passed_data(trg_data);



get_best_mnth(trg_data,'click','https://res.cloudinary.com/heptera/image/upload/v1607150764/icon-svg/calendar-dates_ca6xa0.svg');

get_best_mnth(trg_data,'open','https://res.cloudinary.com/heptera/image/upload/v1607159114/icon-svg/alarm_yh71rb.svg');



  })



function crt_chart_in_ana_data(data_2){




google.charts.load('current', {'packages':['line']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable(data_2);

        console.log(data);

        var options = {
          
          legend: { position: 'bottom' },
          backgroundColor: '#f1f8e9',
        width: 800,
        height: 400
        };

        var chart = new google.charts.Line(document.getElementById('curve_chart'));

        chart.draw(data, google.charts.Line.convertOptions(options));
      }


      $("#chrt_con_od_id").css('display','block');
      $("#con-of-all-chrt-and-ana-dt").css('display','none');

}



function get_best_mnth(tp_tm,tp_act,ico){



$('.all-stat-con-per').map(function() {
   

  $(this).css('display','none');




});




get_str_of_app="";


data_res=JSON.parse(jsn_of_ana_data_txt);

console.log(data_res);

var act_data=data_res[tp_tm][tp_act];


for (var i = 0; i < act_data.length; i++) {
  

max_val=Math.max(...act_data);
  if(max_val==0){

console.log(0);
break;

  }else{

idx_of_max=act_data.indexOf(max_val);


act_data[idx_of_max]=0;


console.log(idx_of_max);




get_str_of_app=str_of_stat_data_res(ico,label_of_chrt[tp_tm][idx_of_max]);



$("#"+tp_tm+tp_act).html(get_str_of_app);


  }


};



$("#"+tp_tm+"-con-stat").css('display','flex');


}



function str_of_stat_data_res(icon,txt_data){



ret_str='<div class="con-of-stat-data"> <img src="'+icon+'" style=" height: 30px; margin-right: 20px; "> '+txt_data+' </div>';


return ret_str;


}





$(document).ready(function(){

init_act_str();

})

</script>
  
  
</body>

<script type="text/javascript" src="../jsfile/stickyheader4.js">

</script>



</html>

