<?php

$getdata=$_GET["code"];


?>


<tr>
	<th class="email-con"><div class="eml-con">ravigorasiya65@gmail.com</div></th><td><div class="con-of-tbl-txt"><?php echo $getdata;?></div></td><td><div class="con-of-tbl-txt"></div></td><td><div class="con-of-tbl-txt"></div></td><td><div class="con-of-tbl-txt"></div></td><td><div class="con-of-tbl-txt"></div></td><td><div class="con-of-tbl-txt"></div></td><td><div class="con-of-tbl-txt"></div></td>
<td><div class="con-of-tbl-txt"></div></td>
                        </tr>
