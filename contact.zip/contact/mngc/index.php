



<?php
session_start();

    $email=$_SESSION["email"];
    $id=$_SESSION["id"];

require("../confige/fileconfige.php");
require("../confige/managetag.php");
require("../confige/camp_confige.php");









$lst_name=$_SESSION['listname'];
$get_camp_data="select * from camp_contact_tbl where list_id='$lst_name' and (flg_send='2' or flg_send='0')";



$result = $camp_name_conn->query($get_camp_data);



$cnt_camp=$result->num_rows;

$array_of_tag = array();

$tag_tbl_name="tag".$id;
$select_tag = "select * from ".$tag_tbl_name;
$result = $mngtag->query($select_tag);


while($row = $result->fetch_assoc()) {
        $temp_array["label"]=$row["tag"];
        $temp_array["value"]=$row["id"];

        array_push($array_of_tag,$temp_array);
    }


$geted_tag_array=json_encode($array_of_tag);






function get_email_col($list_id){
require("../confige/fileconfige.php");


  $get_col_query="SELECT `COLUMN_NAME`  FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='list_contacts' AND `TABLE_NAME`='".$list_id."' ORDER BY ordinal_position";
  $query = $conn3->query($get_col_query);

while($row = $query->fetch_assoc()){


  $result[] = $row;
}

// Array of all column names
$columnArr = array_column($result, 'COLUMN_NAME');

return $columnArr;



}





$get_col=get_email_col($_SESSION['listname']);


$get_col=array_slice($get_col,0,count($get_col)-$cnt_camp-8);
?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">





<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">


 <link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1628745601/loader_ww3kdih.css">
<style>
.not-fd-data{
  text-align: center;
padding: 40px;
    background: white;
    border-radius: 4px;
width: 100% !important;
}




.txt-not-fd{
  padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
}




.cbx {
  margin: auto;
  -webkit-user-select: none;
  user-select: none;
  cursor: pointer;
}
.cbx span {
  display: inline-block;
  vertical-align: middle;
  transform: translate3d(0, 0, 0);
}
.cbx span:first-child {
  position: relative;
  width: 18px;
  height: 18px;
  border-radius: 3px;
  transform: scale(1);
  vertical-align: middle;
  border: 1px solid #9098A9;
  transition: all 0.2s ease;
}
.cbx span:first-child svg {
  position: absolute;
  top: 3px;
  left: 2px;
  fill: none;
  stroke: #FFFFFF;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 16px;
  stroke-dashoffset: 16px;
  transition: all 0.3s ease;
  transition-delay: 0.1s;
  transform: translate3d(0, 0, 0);
}
.cbx span:first-child:before {
  content: "";
  width: 100%;
  height: 100%;
  background: #506EEC;
  display: block;
  transform: scale(0);
  opacity: 1;
  border-radius: 50%;
}
.cbx span:last-child {
  padding-left: 8px;
}
.cbx:hover span:first-child {
  border-color: #506EEC;
}

.inp-cbx:checked + .cbx span:first-child {
  background: #506EEC;
  border-color: #506EEC;
  animation: wave 0.4s ease;
}
.inp-cbx:checked + .cbx span:first-child svg {
  stroke-dashoffset: 0;
}
.inp-cbx:checked + .cbx span:first-child:before {
  transform: scale(3.5);
  opacity: 0;
  transition: all 0.6s ease;
}

@keyframes wave {
  50% {
    transform: scale(0.9);
  }
}








.modal-header {
    display: flex;
    flex-shrink: 0;
    align-items: center;
    justify-content: space-between;
    padding: 1rem 1rem;
    border-bottom: 1px solid #dee2e6;
    border-top-left-radius: calc(.3rem - 1px);
    border-top-right-radius: calc(.3rem - 1px);
  }










@import url(https://fonts.googleapis.com/css?family=Arvo);
@import url(https://fonts.googleapis.com/css?family=Dosis);
.tablediv{
    padding:10%;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;
    cursor:pointer;

}
.card:hover{
    cursor:default;
}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
.upper-dir{



}
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}


















.select-wrapper {
        margin: auto;
        max-width: 600px;
        width: calc(100% - 40px);
      }

      .select-pure__select {
        align-items: center;
        background: white;
margin:10px;      
  border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: none;
        box-sizing: border-box;
        color: #363b3e;
        cursor: pointer;
        display: flex;
        font-size: 16px;
        font-weight: 500;
        justify-content: left;
        min-height: 44px;
        padding: 5px 10px;
        position: absolute;
        transition: 0.2s;
        width: 300px;
      }

      .select-pure__options {
        border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: #363b3e;
        display: none;
        left: 0;
        max-height: 220px;
        overflow-y: scroll;
        position: absolute;
        top: 50px;
        width: 100%;
        z-index: 5;
      }

      .select-pure__select--opened .select-pure__options {
        display: block;
      }

      .select-pure__option {
        background: #fff;
        border-bottom: 1px solid #e4e4e4;
        box-sizing: border-box;
        height: 44px;
        line-height: 25px;
        padding: 10px;
      }

      .select-pure__option--selected {
        color: #e4e4e4;
        cursor: initial;
        pointer-events: none;
      }

      .select-pure__option--hidden {
        display: none;
      }

      .select-pure__selected-label {

  align-items: 'center';
       
  border-radius: 4px;
font-size:13px;
        color: #5a2977;
    background: rgba(90, 41, 119, 0.11);
        cursor: initial;
        display: inline-flex;
        justify-content: 'center';
        margin: 5px 10px 5px 0;
        padding: 3px 7px;
      }

      .select-pure__selected-label:last-of-type {
        margin-right: 0;
      }

      .select-pure__selected-label i {
        cursor: pointer;
        display: inline-block;
        margin-left: 7px;
      }

      .select-pure__selected-label img {
        cursor: pointer;
        display: inline-block;
        height: 18px;
        margin-left: 7px;
        width: 14px;
      }

      .select-pure__selected-label i:hover {
        color: black;
      }

      .select-pure__autocomplete {
        background: #f9f9f8;
        border-bottom: 1px solid #e4e4e4;
        border-left: none;
        border-right: none;
        border-top: none;
        box-sizing: border-box;
        font-size: 16px;
        outline: none;
        padding: 10px;
        width: 100%;
      }

      .select-pure__placeholder--hidden {
        display: none;
      }
























.con-of-data {
 max-width:80%;
  max-height: 20em;
  overflow: scroll;
  position: relative;
}


.con-of-data {
    margin: 0px auto;
    margin-bottom: 60px;
    color: #090942;
    font-size: 15px;
    box-shadow: rgb(0 0 0 / 15%) 1.95px 1.95px 2.6px;
    border-bottom-right-radius: 10px;
    border-bottom-left-radius: 10px;
  }
table {
    
  position: relative;
  border-collapse: collapse;
}
tr{
    outline: 1px solid rgb(222, 221, 220);
}
td,
th {
  padding: 0.25em;
}

thead th {
    
    
  position: -webkit-sticky; /* for Safari */
  position: sticky;
  top: 0;
background: #ededf5ed;
    color: #090942;
 

 z-index: 1000;
}

thead th:first-child {
outline: 1px solid rgb(222, 221, 220); 
  left: 0;
  z-index: 1000000000;
}

tbody th {
  position: -webkit-sticky; /* for Safari */
  position: sticky;
  left: 0;
  background: #FFF;
  
}
tbody tr th{
  outline:  1px solid rgb(222, 221, 220); 
    z-index: 1000;
    background: white;
}
.con-data{
min-width: 150px;
max-width: 200px;
overflow: scroll;
padding: 12px 24px;
height:49px;
}
th .email-con{


color:black;


}
.email-con{
overflow-x:scroll;
    width:200px !important;
 padding-left: 20px;
    margin-right: 20px;   
  
}
.email-con::-webkit-scrollbar {
  display: none;
}
.con-of-data{
margin:0px auto;

margin-bottom:60px;
  color: #090942; 
   

font-size:15px;
}

.dropdown-menu.show{
  z-index: 1000000000;
}

th.email-con:hover {
    cursor: pointer;
}


.con-data::-webkit-scrollbar {
  display: none;
}



.row.con_of_opt {
    transition: all 0.5s ease 0s;
    background: #5a297708;
    margin: 60px auto 0px auto;
    max-width: 80%;
    max-height: 30em;
    position: relative;
    color: #5a2977;
    box-shadow: rgb(0 0 0 / 15%) 1.95px 1.95px 2.6px;
    border-top-right-radius: 10px;
    border-top-left-radius: 10px;
    font-size: 12px;
    font-weight: 600;
  }
.bottom-btn {
    text-align: center;
    height: 40px;
    background: #5a297747;
    color: #5a2977;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    padding-left: 20px;
    padding-right: 20px;
}

.main_con_opt{
padding:20px;
}






.dropdown-menu{
    border-radius:0px;
    box-shadow:none;
    
    border:1px solid #dedddc;
overflow-y:scroll;   
}
.below-tit{
font-weight: 400;
    font-size: 18px;
    padding-top: 20px;
    color: #000000c7;
    font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    letter-spacing: 1px;
}
.color-fet{
padding-left:10px;
padding-right:10px;
font-weight:600;
}













.sd-con-ico.dsc-inln-flx {
    width: 8%;
    height: 100%;
}

.tooltip-arrow {
    
    }


[data-popper-placement="right"]>.tooltip-arrow{

transform: none !important;
    top: 8px !important;

}
.main-con-of-crm.dsc-inln-flx {
    width: 92%;
    height: 100vh;
    float: right;
    background: #fafafa;
    overflow: scroll;
}

    .dsc-inln-flx {
    display: inline-block;
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

    .icon-con-of-sd {
    height: 90vh;
    width: 100%;
}

.icon-main-con {
    height: auto;
    width: 100%;
    position: relative;
    top: 50%;
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    }

    .con-ico {
    padding: 20px;
    text-align: center;
}

img.con-of-ico-img {
    height: 30px;
    }




.con-of-main-splt {
    width: 20%;
    height: 100vh;
    display: inline-block;

}
.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

   
h2.head-od-dt-shw {
    margin: 0px;
    }


button.btn-of-drk-back {
    height: 6vh;
    width: 100%;
    background: #125ef6;
    border: 0px;
    border-radius: 5px;
    color: white;
}

.con-of-dt-sel-ele {
    height: 80vh;
    width: 100%;
    overflow: scroll;
    }

    .container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 15px;
}
a.com-for-lnk {
    text-decoration: none;
    color: black;
    }

    h2.head-od-dt-shw {
    margin: 0px;
    font-family: lato;
    font-size: 15px;
    font-weight: bolder;
}
.con-of-main-splt {
    width: 20%;
    height: 100vh;
    background: #e5eafc30;
    }


    .eml-add-main-con {
    width: 29%;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    font-size: 16px;
    
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }
    input.srch-ip-fld {
    width: 100%;
    height: 3vh;
    border: none;
    font-family: 'Lato';
    font-weight: 500;
    color: #c7ccd7;
}
.con-of-full-email-dt {
    width: 100%;
    height: 90vh;
    }

    .img-eml-ico-con {
    font-family: 'Lato';
    padding: 15px;
    border-radius: 50%;
    background: pink;
    margin-right: 10px;
    color: #ca1938;
}
.sub-ln-of-email-txt {
    width: 240px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-family: 'Lato';
    color: #908c8c;
    font-size: 13px;
}
input.srch-ip-fld:focus{
    outline: none;
    border: none;
}

    .fnt-ico-sel {
    width: 20px;
    text-align: center;
}

.con-of-cht-usr {
    width: 50%;
    display: inline-block;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    border-left: 1px solid #f2f2f2;
    }





.con-ico:hover{
    cursor: pointer;
}

.head-of-dash{
    background: #4a154b;
    text-align: right;
    border-bottom-left-radius: 50px;
}


.dropdown-menu .dropdown-item {
    padding: .5rem 1rem;
    font-size: 13px;
    font-weight: 600;
}

button.dropdown-item.comm_up_btn:hover {
    background: #0d66d6;
    color: white;
    }

    .dropdown-header {
    padding: .5rem 1rem;
    color: #f6f9fc;
    font-size: .625rem;
    text-transform: uppercase;
    font-weight: 700;
}
.dropdown-header {
    display: block;
    padding: .5rem 1rem;
    margin-bottom: 0;
    font-size: 0.875rem;
    color: #8898aa;
    white-space: nowrap;
    }
    .dropdown-menu {
    padding: 10px !important;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px !important;
}

.dropdown-item {
    border-radius: 10px;
    }

h6, .h6 {
    font-size: 0.625rem !important;
}


.head-of-inn-con {
    padding: 24px;
}
.all-auta-con {
    padding: 0px 24px;
    }
    span.nm-auta-con {
    font-size: 16px;
    font-weight: 500;
    font-family: 'lato';
    color: #00000080;
}

.crt-new-auta-con {
    width: 200px;
    background: rgb(143 4 175);
    padding: 24px 16px;
    border-radius: 10px;
    height: 200px;
    margin-right: 30px;
    margin-top: 20px;
   
    margin-left: 20px;
}

    .new-crt-head {
    line-height: 28px;
    font-weight: 700;
    color: white;
    font-family: 'Lato';
}
.con-of-crt-new-img {
    text-align: center;
    width: min-content;
    margin-top: 60px;
    padding: 10px;
    margin-left: auto;
    margin-right: auto;
    border-radius: 50%;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
    }

    .crt-new-auta-con:hover{
cursor: pointer;
    }

   .auta-dis-on-dash {
    width: 200px;
    padding: 24px 16px;
    border-radius: 10px;
    background: white;
    margin-right: 30px;
    height: 200px;
    padding-bottom: 0px;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px;
    
    margin-top: 20px;
   margin-left: 20px;    
}

.auta-dis-on-dash:hover{
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
cursor: pointer;

}
.main-con-name {
    flex: auto;
    min-height: 116px;
    display: inline-grid;
    width: 100%;
}
    
    span.bdg-tp-btn {
    margin-left: auto;
    font-size: 12px;
    background: rgb(245, 249, 248);
    padding: 2px 10px;
    border-radius: 10px;
    color: rgb(2, 80, 65);
    font-family: 'Lato';
    font-weight: 600;
    letter-spacing: .4px;
    height: fit-content;
}
.def-name-con-crd {
    display: inline-flex;

}
.ico-of-act-lst {
    width: 40%;
    margin: auto;
    text-align: center;
    padding: 10px;
    width: fit-content;
    border-radius: 10px;
    background: #f2f2f2;
    transition:.4s;
    }

    img.ico-img-src {
    height: 25px;
}
    .def_stat-of-dt {
    padding: 16px 0px;
    display: inline-flex;
    width: 100%;
    height: 60px;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    
}
    .con-of-cnt-data {
    padding: 5.5px 10px;
    background: rgba(0, 0, 0, 0.07);
    border-radius: 5px;
    color: rgb(38, 38, 39);
    width: 60%;
    text-align: center;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    }

    .con-of-dp-data {
    width: 40%;
}

div#confirm_arch_all {
    z-index: 10000000;
}


button#dropdownMenuButton {
    background: no-repeat;
    border: none;
    height: 32px;
    padding: 5.5px;
    float: right;
    }

.all-auta-con {
    padding: 0px 24px;
    display: inline-flex;

}
.dropdown-toggle::after{
    display: none;
}

.dropdown-menu.show{
    border: none;
    border-radius: 10px;
}

a.com-for-lnk {
    text-decoration: none;
    color: #00000091;
    }
    .marg-for-temp{
        margin-left: 0px;
        margin-right: 30px;
    }
    .img-temp-of-mark{
        width: 168px;
        height: 166px;
    }










  .ip-by-def-dsg {
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;


  }

  .ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #524d52;
    box-shadow: 0 0 0 3px #bdb2bd4d;

    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;

  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

.btn-blck-in-auta-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(38, 38, 39);
    color: rgb(255, 255, 255);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
    font-family: 'lato';
}

.btn-blck-in-auta-fcs:hover{
    background-color: rgb(71, 71, 71);
    transition: all 0.2s ease 0s;
}

.btn-blck-non-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(227, 227, 227);
    color: rgb(38, 38, 39);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
}

.btn-blck-non-fcs:hover{
    background-color: rgb(231, 231, 231);
    transition: all 0.2s ease 0s;
    color: black;
}

.modal-content{
    border-radius: 8px;
}

.btn-blck-non-fcs:focus{
    color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;
}
.btn-blck-non-fcs:active{

color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;

}


.con-of-temp-lst {
    display: inline-flex;
    width: 100%;
    padding: 5px 10px;
    border-radius: 10px;
    margin-bottom: 10px;
    }

    .con-of-temp-lst:hover {
    background: #f2f2f28a;
    cursor: pointer;
}

.con-of-temp-lst>div {
    width: 50%;
    }

    span.temp-name {
    font-size: 14px;
}

span.crt-data-of-tmp {
    font-size: 10px;
    }
.row{
    margin-left: 0px;
    margin-right: 0px;
}








.btn-primary.focus, .btn-primary:focus{

    color: #fff;
    box-shadow: 0 0 0 0.2rem rgb(105 109 113 / 50%);
    background-color: rgb(38, 38, 39);
    border-color: rgb(38, 38, 39);

}





.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000e8;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
    z-index: 100000000;
}






input#sel_all_con_stat {
    height: 16px;
    width: 16px;
    border-radius: 2px;
    margin-top: 20px;
}



#cncl-err-msg:hover{


cursor: pointer;


}



.vert-cent-div {
 
  height: min-content;
  text-align: center;
  
  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
    
  margin: auto;
}

.switch-dis{
    display: none;
}






button:disabled,
button[disabled]{
  
  background-color: #cccccc !important;
  color: #666666 !important;
  border: none;
  cursor: not-allowed;
}



.data-head-of-img-fold {
    margin-top: 20px;
    display: inline-flex;
    width: 100%;
    margin-bottom: 20px;
    }

    .main-con-of-img-con {
    width: 100%;
    height: calc(100vh - 8vh - 76px);
    overflow: scroll;
    padding: 30px;
}

.back-btn-to-fold {
    padding: 10px;
    background: #ff008a;
    border-radius: 100px;
    font-size: 12px;
    color: white;
    font-weight: 700;
    margin-left: auto;
    margin-right: auto;
    }

    .con-of-srch-img {
    width: 50%;
}

.con-of-act-img {
    display: inline-flex;
    width: 30%;
    }

    .back-btn-to-fold.color-of-opt-btn {
    padding: 6px;
    background: #c3c2c2;
    border: 0px;
    transition: .4s;
}

.auta-dis-on-dash.img-con-of-fold {
    position: relative;
    padding: 0px;
    border-radius: 0px;
    display: flex;
    justify-content: center;
    margin-right: auto;
    margin-left: 20px;
}
   img.img-tag-for-con {
    width: auto;
    height: auto;
    position: absolute;
    top: 0;
    bottom: 0;
    max-height: 100%;
    max-width: 100%;
    margin: auto;
}

.back-btn-to-fold.color-of-opt-btn:hover {
    cursor: pointer;
    background: #c3c2c28f;
    }
    button.back-btn-to-fold.color-of-opt-btn:focus {
    outline: none;
}

.main-con-of-img-con{
    display: inline-flex;
}

.btn-mdl-act-sel {
    border-radius: 100px !important;
    color: black;
    font-weight: 500;
    font-size: 12px;
    margin-top: 20px;
    text-align: left;
    width: fit-content;
    }

    .btn-mdl-act-sel.active >svg {
    fill: white;
}

.btn-mdl-act-sel >svg {
    fill: black;
    }

    .btn-mdl-act-sel>svg{
        margin-right: 10px;
    }

    .btn-mdl-act-sel:hover svg{
        fill:blue;
    }

    .btn-mdl-act-sel.active:hover svg{
        fill:white;
    }

    .midd-sel-img {
    padding: 40px;
    border: 1px dashed;
    width: fit-content;
    padding: 40px;
    height: 100px;
    
    border-radius: 10px;

}

.midd-sel-img:hover{
    cursor: pointer;
}

img.img-pre-tg-img {
    width: 100%;
    height: auto;
    max-height: 100px;
    border-radius: 10px;

    }

    .img-con-pre {
    width: 98px;
    margin-right: 0px;
    height: 100px;
    position: relative;
    margin-right: 10px;
    margin-top: 10px;
}

#upload_img_form{
    display: inline-flex;
}

.con-of-all-srch {
    width: 600px;
    }

    .con-of-srch-img-thumb {
    border-top-right-radius: 10px;
}

img.img-of-con-srch {
    height: 200px;
    max-width: 250px;
    }

    .btn-con-of-dwn {
    padding: 10px;
    text-align: center;
}

    .full-swn-btn {
    width: fit-content;
    margin-right: 10px;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    margin-top: 10px;
    padding: 0px;
    border-radius: 10px;
}

.active_img_act {
    border: 3px solid blue;
    box-shadow: rgb(0 0 0 / 25%) 0px 14px 28px, rgb(0 0 0 / 22%) 0px 10px 10px;
    }

button.close {
    background: no-repeat;
    border: none;
    }


    th {
    font-weight: 600;
    font-size: 13px;
}

td {
    font-size: 14px;
    }
button.btn.btn-link {
    color: black;
    text-decoration: none;
}

    .cp-round:after{
        border-top: solid 3px #564f4e;


    }
.img_editor-con{
    display: none;
}

    .tui-image-editor-header{
        display: none;
    }

    #tui-image-editor-container {
    width: 100% !important;
    height: calc(100vh - 52px) !important;
    top: 0px;
    position: fixed;
}

.save-fl-bar-con {
    width: 100%;
    height: 52px;
    background: #171717;
    margin-top: calc(100vh - 52px) !important;
    padding: 10px;
    text-align: right;
    }

    .ico-of-act-lst:hover{
        background:black !important;
    }
span.badge.badge-primary {
    background: #00800057;
    color: #074007;
}

span.badge.badge-pill.badge-success {
    background: #0000ff26;
    color: #04044cf7;
}

.btn-blck-in-auta-fcs:hover{
  box-shadow: none !important;
  transform:none;
}
.head-of-nxt-act {
    width: 80%;
    margin: auto;
    padding: 30px 0px;
  }

.row>*{
  width: fit-content;
}

</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 
  <!-- CSS Files -->

</head>
<div id="c"></div>
<body class="" style="background:#fff">


<div class="main-con-of-dash">

<div class="sd-con-ico dsc-inln-flx" style="
">
    
    <div class="sd-hd-con"><img src="https://res.cloudinary.com/heptera/image/upload/v1611850905/landing/open-collective_1_m4opwf.svg" width="" style="
    padding: 2vh
    ">
</div>

<div class="icon-con-of-sd">

    <style>


#main-loader-containre-act{


    text-align: center;
    padding-top: 41vh;
  }

.main-loader-containre-act{
  text-align: center;padding-top: 41vh;height: 84vh;
}



</style>
<div class="icon-main-con">
<div class="con-ico com-for-lnk" data-for-serv="0" data-target-link="https://campign.auftera.com/campigns/all-campign" data-toggle="tooltip" data-placement="right" title="Sheduled Campigns"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1626278281/automation/schedule_send_black_24dp_wybxtb.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="contact/" data-target-link="https://contact.auftera.com/contact/#acl" data-toggle="tooltip" data-placement="right" title="Manage Contact List"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1628748461/email-crm/playlist_add_circle_black_24dp_eryixo.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="template/" data-target-link="https://template.auftera.com/template/" data-toggle="tooltip" data-placement="right" title="Manage Template"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1626278301/automation/web_black_24dp_kx5cze.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="studio/" data-target-link="https://studio.auftera.com/studio/" data-toggle="tooltip" data-placement="right" title="Browse Studio"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1626278284/automation/camera_black_24dp_ldwdgu.svg"></div>
<div class="con-ico" data-toggle="tooltip" data-placement="right" title="Launch Automation"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1627707060/automation/model_training_black_24dp_wjuu9i.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="social/" data-target-link="https://social.auftera.com/social/" data-toggle="tooltip" data-placement="right" title="Social Post"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1627537307/automation/share_black_24dp_wpgnni.svg"></div>
</div>
<script>


id='<?php echo $id;?>';
email='<?php echo $mail;?>';

$(document).on('click','.com-for-lnk',function(){



$("#main-loader-containre").addClass("main-loader-containre-act");
$("#main-loader-containre").html('<div class="cp-spinner cp-round"></div>');

url_lnk=$(this).attr('data-target-link');
ses_path=$(this).attr('data-path-ses');


var sourceString = url_lnk.replace('http://','').replace('https://','').replace('www.','').split(/[/?#]/)[0];

if($(this).attr('data-for-serv')=='1'){

red_url="https://"+sourceString+"/"+ses_path+"confige/crt_ses.php?id="+id+"&email="+email+"&url_red="+url_lnk;

console.log(red_url);


}else if($(this).attr('data-for-serv')=='0'){



red_url=$(this).attr('data-target-link');





}

console.log(red_url);

pageRedirect(red_url);
})

	function pageRedirect(red) {
		
		console.log(red);
		window.location.href=red;




		if(red.indexOf("/mngc") != -1 && red.indexOf("/mngc/profile")<0){
  location.reload(); 
}
//location.reload();	

  
	
	}
</script>


</div>
        
    
    </div>

    <div class="main-con-of-crm dsc-inln-flx">


        
         <?php    require("../confige/header/header-new.php");?>

     

<?php require("../ajaxfile/phpfile/top_of_mngc_2.php");?>




<div id='main-loader-containre'>




<div class="head-of-nxt-act">

    <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" data-toggle="tooltip" data-placement="bottom" title="Create Segment" style="
"><img src="https://res.cloudinary.com/heptera/image/upload/v1628918577/addcontact/interests_white_24dp_st8uyq.svg" class="ico-img-src"></button>

    <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" data-toggle="tooltip" data-placement="bottom" title="Open Analysis" style="
    float: right;
"><img src="https://res.cloudinary.com/heptera/image/upload/v1628918887/addcontact/analytics_white_24dp_acvrpj.svg" class="ico-img-src"></button>
</div>



<div class='row con_of_opt' style=''>
    

<div id='not_select_val_con' style='display:inline-flex'>
<div class="dropdown1" id="dropdown3">
  <div class='main_con_opt'> Filter By Tag</div>
  <div class="dropdown1-content" id="dropdown3-content" style='height:auto;'>

<div id="tag_con_main" style='max-height:250px;overflow:scroll;'>
 

</div>

<div class="row tag_link_con" style="">
        
        <div class="link_hr" style="text-align: r;text-align: right;width:100%;padding:20px 0px 0px 0px;"><button type="button" class="btn btn-link" id="filt_img_nw">Filter<i class="fas fa-check" aria-hidden="true"></i></button></div>
    
    </div>

      </div>

  </div>
    

<div class="dropdown1" id="dropdown4">
  <div class='main_con_opt'>View Segment</div>
  <div class="dropdown1-content" id="dropdown4-content" style='min-width:300px;'>





        </div>
      
  </div>
    <div onclick="window.location.href='../segment/'" class="main_con_opt">
         create Sagment
    </div>
</div>
<div id='select_val_con' style='display:none'>

  <input type="checkbox" id='sel_all_con_stat'>
<div class="dropdown1" id="dropdown1">
  <div class='main_con_opt'> Change Tag</div>
  <div class="dropdown1-content" id="dropdown1-content">


<span class="autocomplete-select"></span>
<div class="tag_ext_con" id='main_tag_con'>
    
    



</div>
<div class="row tag_link_con" style="">
        <div class="link_hr" style="
    float: left;
"><button type="button" class="btn btn-link">Manage Tag <i class="fas fa-arrow-right"></i></button></div>
        <div class="link_hr" style="text-align: r;text-align: right;"><button type="button" class="btn btn-link" id='save_tag_dt'>Save Tag <i class="fas fa-check"></i></button></div>
    
    </div>   
      </div>

  </div>

<div class="dropdown1" id="dropdown2">
  <div class='main_con_opt'>Manage Tag</div>
  <div class="dropdown1-content" id="dropdown2-content" style='min-width:200px;height:auto;'>




<div class="chg_stat_opt" style="">
        
        <div class="link_hr_for_stat" style=""><button type="button" class="btn btn-link save_stat_dt" id="sub_sata^2">Unsubscribe <i class="fas fa-arrow-right"></i></button></div>
<div class="link_hr_for_stat" style=""><button type="button" class="btn btn-link save_stat_dt"  id="sub_sata^4">Bounced<i class="fas fa-arrow-right"></i></button></div>
        <div class="link_hr_for_stat" style=""><button type="button" class="btn btn-link save_stat_dt"  id="sub_sata^1">Subscribe <i class="fas fa-arrow-right"></i></button></div>
       <div class="link_hr_for_stat" style=""><button type="button" class="btn btn-link save_stat_dt"  id="sub_sata^3">None-Subscribe<i class="fas fa-arrow-right"></i></button></div>
<div class="link_hr_for_stat" style=""><button type="button" class="btn btn-link save_stat_dt" id="sub_sata^5">VIP<img src="https://res.cloudinary.com/heptera/image/upload/v1589619572/sign_kxvmzy.png" height='20' style='margin-left:10px;'></button></div>
    </div>
      </div>

  </div>

<div class="main_con_opt" id="arch_con">MaKe It Archive</div>

</div>


<div id="seg_head_tbl" style="display:none;width:100%;background:black;color:white">


<div class="main_con_opt back_btn_seg" style="color:white"> <i class="fas fa-chevron-left"></i> Back</div>

<div class="main_con_opt" id="seg_name_def" style="color:white"> </div>


<div class="main_con_opt del_seg_btn" style="color:white;background:#00000061">DELET SEGMENT</div>





</div>



<div class="container not-fd-data" style="display:none;">

<img src="https://image.flaticon.com/icons/png/512/2879/2879478.png" height="64" style="
">
<div class="txt-not-fd">
You hnot Imported Any Contact.for Start Import contact Click Button.
  </div>

<button class="bottom-btn" data-toggle="modal" onclick="window.location.href='../contact/'" style="float:none;"><i class="fas fa-file-import" style="
    padding-right: 10px;
" aria-hidden="true"></i>Import Now</button>
</div>



</div>

<div class='con-of-data '>
  <table class='table-data-con'>
    <thead>

      <tr>


<th style='z-index:1000000;background: #5a2977;' > <div class='email-con' style='color:white;'>email</div> </th>

<?php

for($i=1;$i<count($get_col);$i++){


?>
        
        <th><div class='con-data'><?php echo $get_col[$i];?></div></th>
        
       
<?php

}
?>
      </tr>

    </thead>
    <tbody>
      
    </tbody>
  </table>
</div>


</div>


</div>

</div>
<style>









.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid #fff;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: #fff transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}


.tag_ext_con {
    height: 220px;
    margin-top: 58px;
padding:10px;
}













span.txt-of-dt {
    font-size: 10px;
    font-weight: 900;
}



.tag_filt_con{
margin:3px;
}
.tag_con_act{


color: #5a2977;
    background: rgba(90, 41, 119, 0.11);
}






.dropdown1 {
  position: relative;
  display: inline-block;
}

.dropdown1-content {
display:none;
max-height:350px;
  position: absolute;
  background-color: white;

border-radius: 0px 0px 10px 10px;
  min-width: 352px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 12px 16px;
  z-index: 10000000;

overflow:scroll;
}


.main_con_opt:hover{
cursor:pointer;
}


.row.tag_link_con {
    margin: 0px;
  height:50px;
}
.link_hr {
    width: 50%;
    font-size: 17px;
    padding:10px 0px;
    color: #5a2977;
}

.dropdown1:hover .dropdown1-content{
 
}
.btn-link:hover{
color:#5a2977;
background:rgba(90, 41, 119, 0.11);

}

.btn-link{
padding:5px;
border-radius:5px;
background: transparent;
    font-weight: 600;
    box-shadow: none;
transition:0.1s; 
   border: none;
}
.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.con_txt_for_mdl{

color:black;
padding-bottom:10px;


}



.lrg-dp-lnk-hov:hover{


box-shadow: rgb(50 50 93 / 25%) 0px 6px 12px -2px, rgb(0 0 0 / 30%) 0px 3px 7px -3px;

}

.new-crt-head {
    line-height: 28px;
    font-weight: 700;
    color: white;
    font-family: 'Lato';
    }
label.lbl {
    font-size: 12px;
  }

  input.ip-by-def-dsg {
    margin-bottom: 20px;
  }


</style>









<div class="modal" id="confirm_arch_all" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style='border-bottom: 0px;'>
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Create Archive All Contact</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">


      <input class="ip-by-def-dsg" type="text" placeholder="Enter ARCHIVE To Create Contact Arch" id="arch_inp_con">
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" style="background:none;" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="con_arch_btn"><div class="row">Confirm</div></button>
      </div>
    </div>
  </div>
</div>


































<script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>
 <script src="../select_opt/jsfile/bundel.min.js"></script>
<script>
  //      $(document).ready(function(){
    //     jQuery.get('ravi.html', function(data) {
//    $("#tbl-con").append(data);
//   });
//jQuery.get('ravi1.html', function(data) {
  //              $(".sticky-wrap").append(data);
    //     });
  //  
//
//
//


crt_data_ver=[];
get_email_api="<?php echo $lst_name;?>";

seg_ope_flg=0;




length_of_array=0;




arr_of_data=[];



function append_load(get_date){

$("#"+get_date).children(".row").append("<div class='lds-ring'  style=''><div></div><div></div><div></div><div></div></div>");

    }














$(document).on("click","#con_arch_btn",function(){

arr_of_data=[];

if($("#arch_inp_con").val()=="ARCHIVE"){

append_load("con_arch_btn");


for (var i = 0; i < length_of_array; i++) {
  arr_of_data.push(i);
};

console.log(length_of_array);
data_of_chg=get_arch_array(1);
$.ajax({
                url : "./ajaxfile/update_tag.php",
                type: "POST",
                data : "requestoflist="+data_of_chg+"&get_stat_act="+"arch"
        }).done(function(response){ 

init_tbl_data();    


        });


}

});
























function init_tbl_data(){
$("#not_select_val_con").children(".back_btn_seg").remove();
$("#unarch_con").html("Make It Archive");

  $("#unarch_con").attr("id","arch_con");
$(".dropdown1-content").css("display","none");

  $(".table-data-con").children("tbody").empty();
arr_of_data=[];
  init_head_of_tbl();
  jQuery.get('rahul1.php?apicode_main='+get_email_api, function(data2) {

console.log(data2);

            get_tbl_enbl(data2);
  });

}






$(document).on('click',".save_stat_dt",function(){

change_stat_data={};  
        
stat_data=$(this).attr("id").split("^")[1];


console.log(crt_data_ver);

for(j=0;j<arr_of_data.length;j++){

console.log(arr_of_data);
email_of_chg=crt_data_ver[arr_of_data[j]]["email"];
  
 change_stat_data[email_of_chg]= stat_data;
}


data_of_chg=JSON.stringify(change_stat_data);

console.log(data_of_chg);

$.ajax({
                url : "./ajaxfile/update_tag.php",
                type: "POST",
                data : "requestoflist="+data_of_chg+"&get_stat_act="+"substatus"
        }).done(function(response){ 

init_tbl_data();    


        });








});

















id_data='<?php echo $lst_name;?>';

$(document).on("click",".get_seg_data",function(){



var get_id=$(this).attr("id");


$(".table-data-con").children("tbody").empty();
arr_of_data=[];
  init_head_of_tbl();



jQuery.get('./rahul1.php?apicode_main=seg_data&post_query_link='+get_id, function(data2) {
             get_tbl_enbl(data2);
$("#seg_name_def").html(get_id.split("^")[1]); 
 $("#seg_head_tbl").css("display","inline-flex");
$(".del_seg_btn").attr("id",get_id);       
       $("#not_select_val_con").css("display","none");
        $("#select_val_con").css("display","none");
       seg_ope_flg=1;
 })


})




  $(document).on("click",".back_btn_seg",function(){
    
    
    
    
    $("#seg_head_tbl").css("display","none");


$("#unarch_con").html("Make It Archive");

  $("#unarch_con").attr("id","arch_con");
seg_ope_flg=0;
init_tbl_data()


});



function get_seg_dt_str(get_seg_old,rem_seg){

return get_seg_old.replace(rem_seg+",","");


}


$(document).on("click",".del_seg_btn",function(){

console.log(length_of_array);
change_stat_data={};
val_of_tag=$(this).attr("id");

for(j=0;j<length_of_array;j++){


email_of_chg=crt_data_ver[j]["email"];
  geted_old_str=get_seg_dt_str(crt_data_ver[j]["segment"],val_of_tag);

final_tag_str=geted_old_str;
 change_stat_data[email_of_chg]= final_tag_str;

}

data_of_chg=JSON.stringify(change_stat_data);

console.log(data_of_chg);
json_req_for_tag(data_of_chg,val_of_tag);



setTimeout(function(){ location.reload(); }, 1000);



});



























function json_req_for_tag(data_json,seg_name){

  if(seg_name=="tag98"){
    status_of_act="tag";
    seg_name_dt="none";
  }else{

    status_of_act="segment";
    seg_name_dt=seg_name;
  }

$.ajax({
                url : "./ajaxfile/update_tag.php",
                type: "POST",
                data : "requestoflist="+data_json+"&get_stat_act="+status_of_act+"&seg_name="+seg_name_dt
        }).done(function(response){ 

init_tbl_data();                
console.log(response);

        });





}







arr_of_all_tag=[];


$(document).on("click",".tag_filt_con",function(){

$(this).addClass("tag_con_act");

var get_val_data=$(this).attr("id").split("^")[1];

val_of_con=$(this).attr("tag_filt_flg");

if(val_of_con=="true"){


$(this).addClass("tag_con_act");
$(this).removeClass("link_hr_for_stat");


arr_of_all_tag.push(get_val_data);

$(this).attr("tag_filt_flg","false");
$("#tag_filt-"+get_val_data).attr("src","https://image.flaticon.com/icons/svg/860/860821.svg");


}else if(val_of_con=="false"){


$(this).addClass("link_hr_for_stat");
$(this).removeClass("tag_con_act");




arr_of_all_tag.splice( arr_of_all_tag.indexOf(get_val_data), 1 );

$(this).attr("tag_filt_flg","true");

$("#tag_filt-"+get_val_data).attr("src","https://image.flaticon.com/icons/svg/748/748113.svg");

}

console.log(arr_of_all_tag);

});



function unsub_function_data(){
sel_query_unsub_add="select * from `"+get_email_api+"` where substatus='2' and arch='0'";

jQuery.get("rahul1.php?apicode_main=query&post_query_link="+sel_query_unsub_add, function(data2) {

console.log(data2);

            get_tbl_enbl(data2);
  });




}





function get_arch_array(get_stat_data){
change_stat_data={};
for (var i = 0; i < arr_of_data.length; i++) {
  email_of_chg=crt_data_ver[arr_of_data[i]]["email"];
change_stat_data[email_of_chg]= get_stat_data;

};

data_of_chg=JSON.stringify(change_stat_data);

return data_of_chg;

}

$(document).on("click","#arch_con",function(){


data_of_chg=get_arch_array(1);

$.ajax({
                url : "./ajaxfile/update_tag.php",
                type: "POST",
                data : "requestoflist="+data_of_chg+"&get_stat_act="+"arch"
        }).done(function(response){ 

init_tbl_data();    


        });




});






function arch_show_fun(){
$("#not_select_val_con").prepend("<div class='main_con_opt back_btn_seg' style='color:rgb(90, 41, 119)'> <i class='fas fa-chevron-left'></i> Back</div>");
  
  $("#arch_con").html("Unarchive");

  $("#arch_con").attr("id","unarch_con");


sel_query_unsub_add="select * from `"+get_email_api+"` where  arch='1'";

jQuery.get("rahul1.php?apicode_main=query&post_query_link="+sel_query_unsub_add, function(data2) {

console.log(data2);

            get_tbl_enbl(data2);
  });



}







$(document).on("click","#unarch_con",function(){


data_of_chg=get_arch_array(0);
console.log(data_of_chg);
$.ajax({
                url : "./ajaxfile/update_tag.php",
                type: "POST",
                data : "requestoflist="+data_of_chg+"&get_stat_act="+"arch"
        }).done(function(response){ 

sel_query_unsub_add="select * from `"+get_email_api+"` where  arch='1'";

jQuery.get("rahul1.php?apicode_main=query&post_query_link="+sel_query_unsub_add, function(data2) {




  location.reload();

});

 


        });




});

















flg_for_filt=0;

dp_dw_stat="";

tag_get=[];

function append_filt_tag_dt () {
  
  
  str_main="";
  for(i=0;i<json.length;i++){
  lable=json[i]["label"];

str_main+="<div class='link_hr_for_stat tag_filt_con' tag_filt_flg='true' style='' id='tag_get_filt^"+json[i]["value"]+"'><button type='button' class='btn btn-link'  style='width: 100%;text-align: left;'>"+lable+"<img src='https://image.flaticon.com/icons/svg/748/748113.svg' height='20' class='del_tag_dt' id='tag_filt-"+json[i]["value"]+"' style='float: right;'></button></div>";

}

$("#tag_con_main").append(str_main);

}














$(document).on("click","#filt_img_nw",function(){


data_of_chg=JSON.stringify(arr_of_all_tag);

$.ajax({
                url : "./ajaxfile/filter_tag.php",
                type: "POST",
                data : "filt_tag="+data_of_chg
        }).done(function(response){ 


if(arr_of_all_tag.length>0){
$(".table-data-con").children("tbody").empty();
arr_of_data=[];
  init_head_of_tbl();



get_tbl_enbl(response);
}else{


$(".table-data-con").children("tbody").empty();
arr_of_data=[];
  init_head_of_tbl();



init_tbl_data();

}

        });





});




















$(document).on("click",".dropdown1",function(){




dp_dw_stat=$(this).attr("id")+"-content";
console.log(dp_dw_stat);
if($("#"+dp_dw_stat).css("display")=="none"){
get_str_of_ext_tag();


}

if(dp_dw_stat=="dropdown3-content"){

if($("#"+dp_dw_stat).css("display")=="none" && flg_for_filt==0){

  append_filt_tag_dt();
  flg_for_filt=1;
}

}

$("#"+dp_dw_stat).css("display","block");

});





$(document).mouseup(function(e)
{
    var container = $("#"+dp_dw_stat);

    // if the target of the click isn't the container nor a descendant of the container
    if (!container.is(e.target) && container.has(e.target).length === 0)
    {
        container.hide();
    }
});




ary=[];


function find_lable_from_val(val_of_tag,src_of_dt,tag_geted){

str_of_tag="";
for (i=0;i<val_of_tag.length;i++) {
  

var get_tag_val=ary[0][val_of_tag[i]];


if(src_of_dt=="add_tag"){

if(tag_get.indexOf(get_tag_val)==-1){

str_of_tag+=get_tag_val+",";

}
}else if(src_of_dt=="rem_tag"){


if(tag_geted !== get_tag_val){

str_of_tag+=get_tag_val+",";

console.log(tag_geted);

}




}





}
console.log(str_of_tag);



return str_of_tag;

}

function get_update_str_of_tag(){
str_of_tag="";

for (var i = 0; i < tag_get.length; i++) {
  str_of_tag+=tag_get[i]+",";
};
console.log(str_of_tag);

return str_of_tag;

}






$(document).on("click",".del_tag_dt",function(){


var removed_ele=$(this).attr("id").split("^")[1];
console.log(removed_ele);

val_of_tag=ary[0][removed_ele];

change_stat_data={};

for(j=0;j<arr_of_data.length;j++){


email_of_chg=crt_data_ver[arr_of_data[j]]["email"];
  geted_old_str=find_lable_from_val(crt_data_ver[arr_of_data[j]]["tag"],"rem_tag",val_of_tag);
console.log(geted_old_str.length);
if(geted_old_str.length==0){
        
geted_old_str=val_of_tag;
}
console.log(geted_old_str);

final_tag_str=geted_old_str;
 change_stat_data[email_of_chg]= final_tag_str;
}

data_of_chg=JSON.stringify(change_stat_data);

console.log(data_of_chg);

json_req_for_tag(data_of_chg,"tag98");
   
tag_get=[];

});














function remove_tag_str_dt(id_of_lst){

var tag_of_lst=crt_data_ver[id_of_lst]["tag"];
var new_tag_dt=[];
for (var i = 0; i < tag_of_lst.length; i++) {
  if(tag_get.indexOf(tag_of_lst[i])==-1){

new_tag_dt.push(tag_of_lst[i]);
  }
}


for (var i = 0; i < arr_of_data.length; i++) {
  var loc_dt_tag=crt_data_ver[arr_of_data[i]]["tag"];
for (var i = 0; i < new_tag_dt.length; i++) {
  
if(loc_dt_tag.indexOf(new_tag_dt[i])==-1){


new_tag_dt.splice( new_tag_dt.indexOf(new_tag_dt[i]), 1 );

break;


}

}







}
tag_get+=new_tag_dt;




}





$(document).on('click',"#save_tag_dt",function(){

change_stat_data={};  
        
for(j=0;j<arr_of_data.length;j++){


console.log("ravi");

email_of_chg=crt_data_ver[arr_of_data[j]]["email"];
if(crt_data_ver[arr_of_data[j]]["tag"].length>0){
  

  geted_old_str=find_lable_from_val(crt_data_ver[arr_of_data[j]]["tag"],"add_tag","0");
  
  
}else{
  geted_old_str="";
}
geted_new_str=get_update_str_of_tag();


final_tag_str=geted_old_str+geted_new_str;
 change_stat_data[email_of_chg]= final_tag_str;
}


data_of_chg=JSON.stringify(change_stat_data);
console.log(data_of_chg);


json_req_for_tag(data_of_chg,"tag98");






});




var data = '<?php echo $geted_tag_array; ?>';







json = JSON.parse(data);     



dict_of_tag={};
for(i=0;i<json.length;i++){
  lable=json[i]["label"];
val=json[i]["value"]; 
dict_of_tag[lable]=val;

if(i==json.length-1){
ary.push(dict_of_tag);
}
}









console.log(json);
var autocomplete = new SelectPure(".autocomplete-select", {
        options: json,
        value: [],
        multiple: true,
        autocomplete: true,
        icon: "fa fa-times",
        onChange: value => { tag_get=value; },
        classNames: {
          select: "select-pure__select",
          dropdownShown: "select-pure__select--opened",
          multiselect: "select-pure__select--multiple",
          label: "select-pure__label",
          placeholder: "select-pure__placeholder",
          dropdown: "select-pure__options",
          option: "select-pure__option",
          autocompleteInput: "select-pure__autocomplete",
          selectedLabel: "select-pure__selected-label",
          selectedOption: "select-pure__option--selected",
          placeholderHidden: "select-pure__placeholder--hidden",
          optionHidden: "select-pure__option--hidden",
        }
      });


function append_tag(item, index){
  let op = json.filter(e=> e.value == item);
  
$("#tag_ver_con").append("<span class='select-pure__selected-label'>"+op[0]['label']+"</span>");


}




























deco_data=[];












function init_head_of_tbl(){





if(seg_ope_flg==0){

if(arr_of_data.length>0 ){


$("#not_select_val_con").css("display","none");
if( crt_data_ver.length==arr_of_data.length){
  
  

$("#sel_all_con_stat").prop('checked',true);

}

  $("#select_val_con").css("display","inline-flex");
$(".con_of_opt").css("background","#5a2977");
$(".con_of_opt").css("color","#ffffff");


}else{
  

  
 $("#select_val_con").css("display","none");



$("#sel_all_con_stat").prop('checked',false);

 
        $("#not_select_val_con").css("display","inline-flex");
$(".con_of_opt").css("background","#5a297708");
$(".con_of_opt").css("color","#5a2977");


}

}



}








function get_tag_match(id_of_lst){

var loc_array_tag=[];
var tag_of_lst=crt_data_ver[id_of_lst]["tag"];
console.log(tag_of_lst);
if(tag_of_lst.length>0){
if(arr_of_data.length>0){
for(var i=0;i<tag_of_lst.length;i++){
if(tag_get.indexOf(tag_of_lst[i])>=0){

  loc_array_tag.push(tag_of_lst[i]);


}

}

}else{


loc_array_tag=tag_of_lst;

}
}
tag_get=loc_array_tag;
console.log(tag_get);



}











function get_str_of_ext_tag(){
  
  $("#main_tag_con").empty();
  console.log(tag_get);
var str_main="";
for (var i = 0;i < tag_get.length; i++) {
  str_main+="<div class='link_hr_for_stat' style=''><button type='button' class='btn btn-link'  style='width: 100%;text-align: left;'>"+tag_get[i]+"<img src='https://image.flaticon.com/icons/svg/1214/1214428.svg' height='20' class='del_tag_dt' id='tag_dt^"+tag_get[i]+"' style='float: right;'></button></div>";
}
console.log(str_main);
$("#main_tag_con").append(str_main);

}



function sel_all_fun_chk(id_of_follo,ip_that_follo){

arr_of_loc=[];

stat_of_sel=$("#"+id_of_follo).prop("checked");

console.log(stat_of_sel);

if(String(stat_of_sel) == "true"){


console.log("rrr");

                  $("#"+id_of_follo).prop("checked", true);
stat_dec=true;

$('.'+ip_that_follo).map(function() {


    $(this).prop("checked",stat_dec);



  email_add=$(this).siblings('.cbx').children('.select_mail_lst').attr('id').split("^")[1];
arr_of_loc.push(email_add);

  

  })

}else{


stat_dec=false;
         $("#"+id_of_follo).prop("checked",false);



         $('.'+ip_that_follo).map(function() {



    $(this).prop("checked",stat_dec);

$(this).val("true");


    

  })


}


arr_of_data=arr_of_loc;

console.log(arr_of_data);

init_head_of_tbl();
  
}




$(document).on('click','#sel_all_con_stat',function(){


console.log($(this).val());

sel_all_fun_chk('sel_all_con_stat','inp-cbx');



})

function allow_to_sel_data(sel){

  val_of_mail=$(sel).attr("id").split("^");
  
  
  get_tag_match(val_of_mail[1]);


  var val_of_id="#email_stat"+val_of_mail[1];
val_of_con=$(val_of_id).val();
if(val_of_con=="true"){
  
arr_of_data.push(val_of_mail[1]);

$(val_of_id).val("false");



}else if(val_of_con=="false"){
  
arr_of_data.splice( arr_of_data.indexOf(val_of_mail[1]), 1 );

$(val_of_id).val("true");



}

}


$(document).on("click",".select_mail_lst",function(){


  
console.log(arr_of_data);

allow_to_sel_data(this);

init_head_of_tbl();





});







function relead_seg_data_app(data){

 str_app="";
  for(const val of data){

seg_id=val['unq_id'];
seg_name=val['seg_name'];
date_seg=new Date(val['crt_date']);
lst_fin_date=String(date_seg).split(" ",5).join(" ");

    str_app+='<a class="dropdown-item dp-opt-lst lrg-dp-lnk-hov com-for-lnk" id="vc" href="#" data-for-serv="0" data-path-ses="contact/" data-target-link="https://contact.auftera.com/contact/segment/#mngc#seg#'+get_email_api+'#'+seg_id+'">'+seg_name+'<br> <span class="txt-of-dt">'+lst_fin_date+'</span> </a>';
  }


 $("#dropdown4-content").html(str_app);

}





function init_seg_data_all(){




$.ajax({
                url : "../segment/ajaxfile/all_seg_name.php",
                type: "GET"
        }).done(function(response){ 

  console.log(response);  

relead_seg_data_app(JSON.parse(response));
        });




}


























$(document).ready(function(){




setTimeout(function(){ $('[data-toggle="tooltip"]').tooltip(); }, 5000);



init_seg_data_all();



id_now_path= window.location.href.split('#');
    console.log(id_now_path.length);
    for(i=0;i<id_now_path.length-1;i++){
           

    }

    if(id_now_path[i-1]=="unsub_add"){

                unsub_function_data();




      }else if(id_now_path[i-1]=="arch_show"){


arch_show_fun();

     }else if(id_now_path[i-1]=="arch_all"){
     
     
     $('#confirm_arch_all').modal();
     init_tbl_data();
     }else if(id_now_path[i-1]=="add_sub_mdl"){


$("#add_con_in_mdl").modal();
init_tbl_data();
     }else{


init_tbl_data();

                 }
});






function sub_stat_enco(sub_flg){

if(sub_flg==1){
                return "subscribe";
        }else if(sub_flg==2){
                return "un-subscribe";
        }else if(sub_flg==3){

                return "none-subscribe";
        }else if(sub_flg==4){
                return "bounced";

  }else if(sub_flg==5){
    return "VIP";
  }



}


function get_tag_html(geted_data){


get_res_tag="";
  
for(k=0;k<geted_data.length;k++){
get_res_tag+="<span class='badge badge-primary' style='margin:3px;'>"+geted_data[k]+"</span>";

}

return get_res_tag;

}


function init_ip_fld_for_add_con(jsn_arr){

  console.log(jsn_arr);

str_app="";

for(i=0;i<jsn_arr.length-3;i++){

val=jsn_arr[i];

str_app+='<label class="lbl">'+val+'</label> <input type="text" class="ip-by-def-dsg" name="'+val+'" placeholder="'+val+'">';

}


$("#bd-of-ip-add-con").html(str_app);

}



function get_tbl_enbl(geted_data){


$(".table-data-con").children("tbody").empty();



str_tbl_enbl="";
        crt_data_ver=JSON.parse(geted_data);
        length_of_array=crt_data_ver.length;


	js_array = [<?php echo '"'.implode('","', $get_col).'"' ?>];


init_ip_fld_for_add_con(js_array);
if(length_of_array>0){


        for(i=0;i<length_of_array;i++){
        str_tbl_enbl+="<tr><th class='email-con' ><div class='row' style='width:280px;'><div><input class='inp-cbx' id='email_stat"+i.toString()+"'   value='true' type='checkbox' style='display: none' /><label class='cbx' for='email_stat"+i.toString()+"'><span class='select_mail_lst' id='"+crt_data_ver[i]["email"]+"^"+i.toString()+"'><svg width='12px' height='10px' viewbox='0 0 12 10'><polyline points='1.5 6 4.5 9 10.5 1'></polyline></svg></span><span> </span></label></div><div class='email-con com-for-lnk'   data-for-serv='0'  data-target-link='http://contact.auftera.com/contact/mngc/profile/confige/crt_ses_of_pro.php?pro_email_req="+crt_data_ver[i]["email"]+"&pro_id="+crt_data_ver[i]["con_id"]+"'>"+crt_data_ver[i]["email"]+"</div></div></th>"
    for (j=1;j<js_array.length-3;j++){

 
  str_tbl_enbl+="<td><div class='con-data'>"+crt_data_ver[i][js_array[j]]+"</div></td>";



}



console.log(crt_data_ver[i][js_array[j]]);


get_res_tag=get_tag_html(crt_data_ver[i][js_array[j]]);


str_tbl_enbl+="<td><div class='con-data' style='min-width:300px;'>"+get_res_tag+"</div></td>";
j+=1;

var get_sub_stat=sub_stat_enco(crt_data_ver[i][js_array[j]]);
str_tbl_enbl+="<td><div class='con-data sub_stat_con'><span class='badge badge-pill badge-success'>"+get_sub_stat+"</span></div></td>";
i
j+=1;
str_tbl_enbl+="<td><div class='con-data'>"+crt_data_ver[i][js_array[j]]+"</div></td>";






str_tbl_enbl+="</tr>";




dp_dw_stat="";

tag_get=[];
arr_of_data=[];


        }
$("#res4").html("klkl");
$(".not-fd-data").css("display","none");
$(".table-data-con").children("tbody").append(str_tbl_enbl);
$(".table-data-con").css("display","block");
}else{

$(".table-data-con").css("display","none");

$(".not-fd-data").css("display","block");
}

}




$("#frm_data").submit(function(e) {

    e.preventDefault(); // avoid to execute the actual submit of the form.

    var form = $(this);
    var url = form.attr('action');

    $.ajax({
           type: "POST",
           url: url,
           data: form.serialize(), // serializes the form's elements.
           success: function(data)
           {
               

window.location ='./../select_opt/';

           }
         });


});




        </script>


  
</body>




</html>



