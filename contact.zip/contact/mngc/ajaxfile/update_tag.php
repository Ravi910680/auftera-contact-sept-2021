<?php

session_start();


require("../../confige/fileconfige.php");
require("../../confige/managetag.php");
require("../../confige/segment_confige.php");
require("../../confige/curlpost/post.php");

if(isset($_SESSION['listname'])){
$lst_name=$_SESSION['listname'];
}else{

$lst_name=$_POST['listname'];


}



function select_query($conn,$sel_query){


	$ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}
$geted_array=$_POST["requestoflist"];


$dec_of_data=json_decode($geted_array);


$stat_of_act=$_POST["get_stat_act"];



foreach($dec_of_data as $x => $val) {
$tag_val_data=$val;       

$sql = "UPDATE `".$lst_name."` SET ".$stat_of_act."='$tag_val_data' WHERE email='$x' and tag <> '$tag_val_data'";

if ($conn3->query($sql) === TRUE) {


	$sel_query="select * from `".$lst_name."` where email='$x'";


	$con_id=select_query($conn3,$sel_query)[0]['con_id'];

	if($stat_of_act=="arch"){
$trg_arr['trg_tp']="arch_con_trg";
	}else if($stat_of_act=="substatus"){


		$trg_arr['trg_tp']="chg_stat_trg";

	}else{
		$trg_arr['trg_tp']="chg_tag_trg";
	}
$trg_arr['field']="add";
$trg_arr['data']=$lst_name;

$send_arr=json_encode($trg_arr);

$url="https://automation.auftera.com/automation/create/ajaxfile/auta_flow.php";

$params=array("jsn_arr"=>$send_arr,"con_id"=>$con_id);
httpPost($url,$params);
echo "oooo";

}





}


?>
