<?php

session_start();


require("../confige/fileconfige.php");

require("../confige/managetag.php");

require("./ajaxfile/get_tag_data.php");


$listname_api=$_SESSION['listname'];






function get_email_col($list_id){
require("../confige/fileconfige.php");


	$get_col_query="SELECT `COLUMN_NAME`  FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='list_contacts' AND `TABLE_NAME`='".$list_id."' ORDER BY ordinal_position";
	$query = $conn3->query($get_col_query);

while($row = $query->fetch_assoc()){


	$result[] = $row;
}

// Array of all column names
$columnArr = array_column($result, 'COLUMN_NAME');

return $columnArr;



}








$get_col=get_email_col($listname_api);























if($_GET["apicode_main"]=="query"){
	$sql=$_GET["post_query_link"];


}else if($_GET["apicode_main"]=="seg_data"){
	$seg_name=$_GET["post_query_link"];
$sql = "SELECT * FROM `".$listname_api."` where segment LIKE '%".$seg_name."%' and arch='0'";
	
	
	
	
}else{
$sql = "SELECT * FROM `".$listname_api."` where arch='0'";


}

$result = $conn3->query($sql);
$a=array();

if ($result->num_rows > 0) {
$i=0;
    // output data of each row
    while($row = $result->fetch_assoc()) 	    
    {
for($i=0;$i<count($get_col);$i++){


$row_array[$get_col[$i]] = $row[$get_col[$i]];


}


$tag_val=array();
$tag_arr=explode(",",$row_array["tag"]);


$tag_arr=array_slice($tag_arr,0,count($tag_arr)-1);



foreach($tag_arr as $val){


array_push($tag_val,$geted_tag_array[0][$val]);

}



$row_array["tag"]=$tag_val;




	    
	    
array_push($a,$row_array);
    }



  }
$json_arr=json_encode($a);
echo $json_arr;

$_SESSION['email_seg_data']=$json_arr;








?>


