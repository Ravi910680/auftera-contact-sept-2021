<?php
session_start();

require("../../../confige/camp_confige.php");

$lst_name=$_SESSION['listname'];



function get_camp_ana_data($tbl_name,$id,$tz){

	require("../../../confige/email_camp_ana.php");

$data_of_camp=array();

$sql_query="select * from `$tbl_name` where id='$id' ORDER BY act_date DESC";


$result = $camp_ana_conn->query($sql_query);

if($result->num_rows>0){

while($row = $result->fetch_assoc()) {

$row['act_date']=conv_utc_to_loc($row['act_date'],$tz);
array_push($data_of_camp, $row);

  }
}
return $data_of_camp;


}



function get_camp_sub_ln($conn,$camp_con_id){


$sel_sub="select * from camp_content_tbl where camp_id='$camp_con_id'";

$result = $conn->query($sel_sub);


$row = $result->fetch_assoc();
return $row;

}

function conv_utc_to_loc($date,$tz){
      

        $given = new DateTime($date, new DateTimeZone("UTC"));
$given->setTimezone(new DateTimeZone($tz));
$output = $given->format("Y-m-d H:i:s");

return $output;
    
}

function get_all_camp_from_db($conn,$id,$lst_id){

$ret_arr=array();
$get_tz_usr=file_get_contents("https://account.auftera.com/account/main/settings/ajaxfile/get_tz_of_usr.php?id=".$id);



$tz=json_decode($get_tz_usr)[0]->time_zone;

$pro_id=$_SESSION['pro_id'];


$sel_query="select * from camp_name_tbl where id='$id' and flg_send<=1   ORDER BY camp_shed_time DESC";



$result=$conn->query($sel_query);

$ret_data=array();


if ($result->num_rows > 0) {
  // output data of each row

$i=0;

$j=0;
$flg_not_fd=0;
  while($row = $result->fetch_assoc()){
	  
	  
	  
	  $db_name=$row['camp_contact_id']."#".$lst_id;

$sub_ln_camp=$row['camp_name'];

$i+=1;
  	$arr_camp_ana=get_camp_ana_data($db_name,$pro_id,$tz);

  	

  	if(count($arr_camp_ana)>0){

		$ret_data['data'][$j]=$row;

    $ret_data['data'][$j]['subject']=$sub_ln_camp;
			
			
			array_unshift($arr_camp_ana, array('act'=>'1','act_date'=>conv_utc_to_loc($row["camp_shed_time"],$tz)));
    $ret_data['data'][$j]['activity']=$arr_camp_ana;


$j+=1;

}else{



	$flg_not_fd+=1;
	
	if($result->num_rows==$flg_not_fd){
		$ret_data=array();
		$ret_data['camp_num']=$i;
return $ret_data;
	}

}

  }

  
}else{


}	

$ret_data['camp_num']=$i;

return $ret_data;


}



$id=$_SESSION['id'];
print_r(json_encode(get_all_camp_from_db($camp_name_conn,$id,$lst_name)));



?>
