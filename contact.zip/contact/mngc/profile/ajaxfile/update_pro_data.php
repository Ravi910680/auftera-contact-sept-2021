<?php

session_start();

require("../../../confige/fileconfige.php");
require("../../../confige/curlpost/post.php");




$id=$_SESSION['id'];


$lst_name=$_SESSION['listname'];

$email_pro=$_SESSION['pro_email'];




function str_of_update($data_up_fld){

$str_up="";

foreach($data_up_fld as $x => $val) {


	

$str_up.=$x."='".$val."',";



}

return $str_up;


}



function select_query($conn,$sel_query){


	$ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}

function send_req_for_auta($conn3,$list_name,$email){

$sel_query="select * from `$list_name` where email='$email'";


$con_id=select_query($conn3,$sel_query)[0]['con_id'];


$trg_arr['trg_tp']="up_con_trg";
$trg_arr['field']="add";
$trg_arr['data']=$list_name;

$send_arr=json_encode($trg_arr);

$url="https://automation.auftera.com/automation/create/ajaxfile/auta_flow.php";

$params=array("jsn_arr"=>$send_arr,"con_id"=>$con_id);

httpPost($url,$params);
 
}

$up_req_data=json_decode($_POST['data']);

$up_str_fld=str_of_update($up_req_data);
$up_str_fld=substr($up_str_fld, 0, -1);

$up_query="update `$lst_name` set ".$up_str_fld." where email='$email_pro'";



if ($conn3->query($up_query) === TRUE) {

send_req_for_auta($conn3,$lst_name,$up_req_data->email);


$_SESSION['pro_email']=$up_req_data->email;
echo 1;
} else {
  echo 0;
}



?>
