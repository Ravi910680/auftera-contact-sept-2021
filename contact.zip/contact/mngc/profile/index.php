



<?php
session_start();

    $mail=$_SESSION["email"];
    $id=$_SESSION["id"];

    $lst_name=$_SESSION['listname'];

require("../../confige/userconnect.php");
require("../../confige/fileconfige.php");
require("../../confige/managetag.php");
require("../../confige/camp_confige.php");







?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">


<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">


<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">

 <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />


 <link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1628745601/loader_ww3kdih.css">
<style>
.not-fd-data{
  text-align: center;
padding: 40px;
    background: white;
    border-radius: 4px;

}




.txt-not-fd{
  padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
}




.cbx {
  margin: auto;
  -webkit-user-select: none;
  user-select: none;
  cursor: pointer;
}
.cbx span {
  display: inline-block;
  vertical-align: middle;
  transform: translate3d(0, 0, 0);
}
.cbx span:first-child {
  position: relative;
  width: 18px;
  height: 18px;
  border-radius: 3px;
  transform: scale(1);
  vertical-align: middle;
  border: 1px solid #9098A9;
  transition: all 0.2s ease;
}
.cbx span:first-child svg {
  position: absolute;
  top: 3px;
  left: 2px;
  fill: none;
  stroke: #FFFFFF;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 16px;
  stroke-dashoffset: 16px;
  transition: all 0.3s ease;
  transition-delay: 0.1s;
  transform: translate3d(0, 0, 0);
}
.cbx span:first-child:before {
  content: "";
  width: 100%;
  height: 100%;
  background: #506EEC;
  display: block;
  transform: scale(0);
  opacity: 1;
  border-radius: 50%;
}
.cbx span:last-child {
  padding-left: 8px;
}
.cbx:hover span:first-child {
  border-color: #506EEC;
}

.inp-cbx:checked + .cbx span:first-child {
  background: #506EEC;
  border-color: #506EEC;
  animation: wave 0.4s ease;
}
.inp-cbx:checked + .cbx span:first-child svg {
  stroke-dashoffset: 0;
}
.inp-cbx:checked + .cbx span:first-child:before {
  transform: scale(3.5);
  opacity: 0;
  transition: all 0.6s ease;
}

@keyframes wave {
  50% {
    transform: scale(0.9);
  }
}



















@import url(https://fonts.googleapis.com/css?family=Arvo);
@import url(https://fonts.googleapis.com/css?family=Dosis);
.tablediv{
    padding:10%;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;
    cursor:pointer;

}
.card:hover{
    cursor:default;
}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
.upper-dir{



}
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}


















.select-wrapper {
        margin: auto;
        max-width: 600px;
        width: calc(100% - 40px);
      }

      .select-pure__select {
        align-items: center;
        background: white;
margin:10px;      
  border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: none;
        box-sizing: border-box;
        color: #363b3e;
        cursor: pointer;
        display: flex;
        font-size: 16px;
        font-weight: 500;
        justify-content: left;
        min-height: 44px;
        padding: 5px 10px;
        position: absolute;
        transition: 0.2s;
        width: 300px;
      }

      .select-pure__options {
        border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: #363b3e;
        display: none;
        left: 0;
        max-height: 220px;
        overflow-y: scroll;
        position: absolute;
        top: 50px;
        width: 100%;
        z-index: 5;
      }

      .select-pure__select--opened .select-pure__options {
        display: block;
      }

      .select-pure__option {
        background: #fff;
        border-bottom: 1px solid #e4e4e4;
        box-sizing: border-box;
        height: 44px;
        line-height: 25px;
        padding: 10px;
      }

      .select-pure__option--selected {
        color: #e4e4e4;
        cursor: initial;
        pointer-events: none;
      }

      .select-pure__option--hidden {
        display: none;
      }

      .select-pure__selected-label {

  align-items: 'center';
       
  border-radius: 4px;
font-size:13px;
        color: #5a2977;
    background: rgba(90, 41, 119, 0.11);
        cursor: initial;
        display: inline-flex;
        justify-content: 'center';
        margin: 5px 10px 5px 0;
        padding: 3px 7px;
      }

      .select-pure__selected-label:last-of-type {
        margin-right: 0;
      }

      .select-pure__selected-label i {
        cursor: pointer;
        display: inline-block;
        margin-left: 7px;
      }

      .select-pure__selected-label img {
        cursor: pointer;
        display: inline-block;
        height: 18px;
        margin-left: 7px;
        width: 14px;
      }

      .select-pure__selected-label i:hover {
        color: black;
      }

      .select-pure__autocomplete {
        background: #f9f9f8;
        border-bottom: 1px solid #e4e4e4;
        border-left: none;
        border-right: none;
        border-top: none;
        box-sizing: border-box;
        font-size: 16px;
        outline: none;
        padding: 10px;
        width: 100%;
      }

      .select-pure__placeholder--hidden {
        display: none;
      }
























.con-of-data {
 max-width:80%;
  max-height: 20em;
  overflow: scroll;
  position: relative;
}

table {
    
  position: relative;
  border-collapse: collapse;
}
tr{
    outline: 1px solid rgb(222, 221, 220);
}
td,
th {
  padding: 0.25em;
}

thead th {
    
    
  position: -webkit-sticky; /* for Safari */
  position: sticky;
  top: 0;
background: #ededf5ed;
    color: #090942;
 

 z-index: 1000;
}

thead th:first-child {
outline: 1px solid rgb(222, 221, 220); 
  left: 0;
  z-index: 1000000000;
}

tbody th {
  position: -webkit-sticky; /* for Safari */
  position: sticky;
  left: 0;
  background: #FFF;
  
}
tbody tr th{
  outline:  1px solid rgb(222, 221, 220); 
    z-index: 1000;
    background: white;
}
.con-data{
min-width: 150px;
max-width: 200px;
overflow: scroll;
padding: 12px 24px;
height:49px;
}
th .email-con{


color:black;


}
.email-con{
overflow-x:scroll;
    width:200px;
 padding-left: 20px;
    margin-right: 20px;   
  
}
.email-con::-webkit-scrollbar {
  display: none;
}
.con-of-data{
margin:0px auto;

margin-bottom:60px;
  color: #090942; 
    outline: 1px solid rgb(222, 221, 220); 

font-size:15px;
}

th.email-con:hover {
    cursor: pointer;
}


.con-data::-webkit-scrollbar {
  display: none;
}



.row.con_of_opt {



transition: all 0.5s ease 0s;

    background: #5a297708;
    margin: 60px auto 0px auto;
    max-width: 80%;
    max-height: 20em;
    position: relative;
    font-weight: 900;
    color: #5a2977;
}
.bottom-btn {
    text-align: center;
    height: 40px;
    background: #5a297747;
    color: #5a2977;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    padding-left: 20px;
    padding-right: 20px;
}

.main_con_opt{
padding:20px;
}






.dropdown-menu{
    border-radius:0px;
    box-shadow:none;
    
    border:1px solid #dedddc;
overflow-y:scroll;   
}
.below-tit{
font-weight: 400;
    font-size: 18px;
    padding-top: 20px;
    color: #000000c7;
    font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    letter-spacing: 1px;
}
.color-fet{
padding-left:10px;
padding-right:10px;
font-weight:600;
}

.main-con-of-pro-dt {
    height: 80vh;
    margin: 0px 10vh;
    width: 100%;
  }

  .con-of-pro-txt-dt {
    
    width: 60%;
    display: inline-block;
    position: relative;
    float: left;

  }

  .con-of-ana-data {
    height: 80vh;
    width: 39%;
    display: inline-block;
    position: relative;
    float: left;

  }






























.steps {
  
  box-shadow: 0px 10px 15px -5px rgba(0, 0, 0, 0.3);
  background-color: #FFF;
  padding: 24px 0;
  position: relative;
  margin: auto;
  border-radius: 10px;
}

.steps::before {
  content: '';
  position: absolute;
  top: 0;
  height: 24px;
  width: 1px;
  
  left: calc(50px / 2);
  z-index: 1;
}

.steps::after {
  content: '';
  position: absolute;
  height: 13px;
  width: 13px;
  background-color: var(--primary-color);
  box-shadow: 0px 0px 5px 0px var(--primary-color);
  border-radius: 15px;
  left: calc(50px / 2);
  bottom: 24px;
  transform: translateX(-45%);
  z-index: 2;
}

.step {
    padding: 10px 20px 10px 50px;
    position: relative;
    transition: all 0.4s ease-in-out;
    background-color: #FFF;

  }
.step-open::before {
    content: '';
    position: absolute;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    left: calc(50px / 2);
    transform: translateX(-45%);
    z-index: 2;
    background: #9bd4bd;
    margin-top: 20px;
    border: 5px solid white;
  }
  

.step::after {
    content: '';
    position: absolute;
    height: 100%;
    width: 1px;
    background-color: #00008b3b;
    left: calc(50px / 2);
    top: 0;
    z-index: 1;

  }

.step.minimized {
  background-color: #FFF;
  transition: background-color 0.3s ease-in-out;
  cursor: pointer;
}

.header {
    user-select: none;
    font-size: 14px;
    color: rgba(0, 0, 0, 0.6);
    font-weight: 500;

  }
.subheader {
    user-select: none;
    font-size: 12px;
    color: rgba(0, 0, 0, 0.4);
    font-weight: 400;
  }

.step-content {
  transition: all 0.3s ease-in-out;
  overflow: hidden;
  position: relative;
}

.step.minimized > .step-content {
  height: 0px;
}

.step-content.one {
  height: 460px;
  width: 100%;
  background-color: rgba(0, 0, 0, 0.05);
  border-radius: 4px;
  margin-top: 10px;
}

.step-content.two {
  height: 600px;
  width: 100%;
  background-color: rgba(0, 0, 0, 0.05);
  border-radius: 4px;
  margin-top: 10px;
}

.step-content.three {
  height: 400px;
  width: 100%;
  background-color: rgba(0, 0, 0, 0.05);
  border-radius: 4px;
  margin-top: 10px;
}

.next-btn {
  position: absolute;
  top: 50%;
  left: 50%;
  border: 0;
  padding: 10px 20px;
  border-radius: 4px;
  background-color: red;
  box-shadow: 0 5px 10px -3px rgba(0, 0, 0, 0.3);
  color: #FFF;
  transition: background-color 0.3s ease-in-out;
  cursor: pointer;
  transform: translate(-50%, -50%);
}

.close-btn {
  position: absolute;
  top: 50%;
  left: 50%;
  border: 0;
  padding: 10px 20px;
  border-radius: 4px;
  background-color: rgb(255, 0, 255);
  box-shadow: 0 5px 10px -3px rgba(0, 0, 0, 0.3);
  color: #FFF;
  transition: background-color 0.3s ease-in-out;
  cursor: pointer;
  transform: translate(-50%, -50%);
}

/* Irrelevant styling things */
.close-btn:hover {
  background-color: rgba(255, 0, 255, 0.6);
}

.close-btn:focus {
  outline: 0;
}

.next-btn:hover {
  background-color: rgba(255, 0, 0, 0.6);
}

.next-btn:focus {
  outline: 0;
}

.step.minimized:hover {
  background-color: rgba(0, 0, 0, 0.06);
}


.ico-that-act-pro {
    width: 20%;
    display: inline-block;
    color: #e01a4f;
  }

  .step-header {
    display: flex;
    margin-top: 25px;
    width: 100%;
  }


.ico-of-email-dt {
    height: 100px;
    width: 100px;
    border-radius: 50%;
    background: #dcd6d1;
    text-align: center;
    font-size: 50px;
    padding: 12px;
    color: #9e9c9b;
    margin-bottom: 20px;
  }

.txt-of-full-email {
    font-size: 20px;
    color: #453e39;
    width: fit-content;
    padding-left: 30px;
}
  span.dt-con-of-hy {
    color: #9e9c9b;
    font-size: 13px;
  }


.status_span{
  display: inline-block;
    border-radius: 3px;
    padding: 5px 12px;
    font: 700 13px Lato,Arial,sans-serif;
    cursor: default;
}

.subscribe{
  background-color: #cbd598;
    color: #fff;
}


.card-init-count {
    width: 33%;
    display: inline-block !important;
    padding: 10px;
    text-align: center;

  }

  .coun_con {
    font-size: 24px;
    color: black;
    font-weight: 500;

  }

  .count_type {
    font-size: 13px;
    color: #241c15;
    padding: 10px 0px;

  }


.dt-fld-for-pro {
    width: 100%;
    padding-top: 50px;

  }

  tr {
    border-top: 1px solid #f1efed;
    outline: none;
  }

  td, th {
    padding: 0.25em;
    padding: 16px;
  }

  td.fld-name {
    color: #9e9c9b;
    font: 16px Lato,Arial,sans-serif;
    }
    td.fld-val {
    font: 16px Lato,Arial,sans-serif;
  }


  button.btn-of-edt-con {
    margin-right: 20px;
    background: no-repeat;
    border: none;

  }


.edt_save_btn{


  background: #4a154b !important;
    border-radius: 10px;
    padding: 5px 10px;
    color: white;
    font-size: 13px;
    font-weight: 700;
}


.header {
    width: 30%;
    user-select: none;
    font-size: 14px;
    color: rgb(0 0 0 / 89%);
    font-weight: 500;

    }

    .act-of-camp {
    width: 20%;
    user-select: none;
    font-size: 14px;
    color: rgba(0, 0, 0, 0.6);
    font-weight: 500;

  }

  .sub_of_camp {
    width: 40%;
    user-select: none;
    font-size: 14px;
    color: #4d7b69;
    font-weight: 500;

  }













body{
  font-family: 'lato';
letter-spacing:0.2px;
}




  .dropdown-menu{
    border-radius:0px !important;
    box-shadow:none !important;

    border:1px solid #dedddc !important;

}

.nav-link:hover{
    cursor:pointer;
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}

.main-content {
    position: relative;
    top: 8vh;
}

a{
    font-weight:600;
}
  .navbar-light .navbar-brand {
    color: white;

  }


.dropdown-menu .dropdown-item>i, .dropdown-menu .dropdown-item>svg {
    margin-right: 1rem;

}

  .navbar-light .navbar-brand:hover, .navbar-light .navbar-brand:focus {
    color: white;

    }
  .navbar {
    background: #4a154b;
}



.navbar-light .navbar-nav .nav-link {
    color: white !important;
    font-size:0.9rem !important;
    font-weight: 600;

padding: 20px 10px !important;
}

.dropdown-menu.show {
    border-radius: 10px !important;

}



.navbar-light .navbar-nav .nav-link:hover, .navbar-light .navbar-nav .nav-link:focus {
    color: white;

}


.navbar-light .navbar-nav .show>.nav-link, .navbar-light .navbar-nav .active>.nav-link, .navbar-light .navbar-nav .nav-link.show, .navbar-light .navbar-nav .nav-link.active {
    color: white;
}
.modal{

background: #00000070;

}

.c-slacklogo{display:flex;align-items:center;padding: 0px 20px;}
.c-slacklogo a{line-height:inherit;display:inline-block;font-size:0;padding:0;border:none}
.c-slacklogo img{vertical-align:top}
.c-slacklogo--white{display:none}
.c-slacklogo--color{display:inline-block}
@media screen and (min-width:67.8125rem){.is-clear:not(.is-fixed) .c-slacklogo .c-slacklogo--white{display:inline-block}
.is-clear:not(.is-fixed) .c-slacklogo .c-slacklogo--color{display:none}
}
.c-slacklogo--pillow{width:auto;fill:#fff}
.c-slacklogo.v-frontiers{width:205px;z-index:1}
.c-nav__mobile .c-slacklogo.v-frontiers svg{margin-left:1rem}

.lgs-txt {
    font-size: 25px;
    padding-left: 10px;
    font-weight: 600;
    color: white;
}

span.spn-ln-lg {
    padding: 2px;
    font-weight: 100;
    font-size: 30px;
    }


 sub {
    font-weight: 500;
}


.navbar-light .navbar-nav .nav-link {
    color: white !important;
    font-size: 2vh;
    font-weight: 600;
    padding: 2.5vh 10px !important;
  }


.dropdown-menu .dropdown-item {
    padding: .5rem 1rem;
    font-size: 13px;
    font-weight: 600;

    }

    button.dropdown-item.comm_up_btn:hover {
    background: #0d66d6;
    color: white;
  }

  .dropdown-caret {
    display: inline-block;
    width: 0;
    height: 0;
    vertical-align: middle;
    content: "";
    border-top-style: solid;
    border-top-width: 4px;
    border-right: 4px solid transparent;
    border-bottom: 0 solid transparent;
    border-left: 4px solid transparent;

  }

  #main-loader-containre-act{


    text-align: center;
    padding-top: 41vh;
  }

.main-loader-containre-act{
  text-align: center;padding-top: 41vh;height: 84vh;
}













button.btn-of-new-obj-crt {
    background: #4a154b;
    color: white;
    border-radius: 10px;
    padding: 10px 20px;
    border: none;
    font-size: 11px;
    font-weight: 800;
    box-shadow: #4a154b82 0px 13px 27px -5px, #4a154b75 0px 8px 16px -8px;
    transition: .5s;
}


.row.head-con-rw {
    margin: 20px 0px;
    border-radius: 10px;
    padding: 20px;
    font-family: lato;
    width: 100%;
}


button.btn-of-new-obj-crt:hover{
cursor:pointer;
box-shadow:none;
}

.row.head-con-rw.color-box-desg {
    background: no-repeat;
    background: #154b3d;
    color: white !important;

}



 @media only screen and (max-width: 480px) {


.navbar {
    height: auto !important;
    background: #4a154b;
}


}


@media (min-width: 320px) and (max-width: 480px) {



.navbar {
    height: auto !important;
    background: #4a154b;
}


}






[data-popper-placement="right"]>.tooltip-arrow{

transform: none !important;
    top: 8px !important;

}
.main-con-of-crm.dsc-inln-flx {
    width: 92%;
    height: 100%;
    float: right;
    background: #fafafa;
    overflow: scroll;
}

    .dsc-inln-flx {
    display: inline-block;
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

    .icon-con-of-sd {
    height: 90vh;
    width: 100%;
}

.icon-main-con {
    height: auto;
    width: 100%;
    position: relative;
    top: 50%;
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    }

    .con-ico {
    padding: 20px;
    text-align: center;
}

img.con-of-ico-img {
    height: 30px;
    }




.con-of-main-splt {
    width: 20%;
    height: 100vh;
    display: inline-block;

}
.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

   
h2.head-od-dt-shw {
    margin: 0px;
    }


button.btn-of-drk-back {
    height: 6vh;
    width: 100%;
    background: #125ef6;
    border: 0px;
    border-radius: 5px;
    color: white;
}

.con-of-dt-sel-ele {
    height: 80vh;
    width: 100%;
    overflow: scroll;
    }

    
a.com-for-lnk {
    text-decoration: none;
    color: black;
    }

    h2.head-od-dt-shw {
    margin: 0px;
    font-family: lato;
    font-size: 15px;
    font-weight: bolder;
}
.con-of-main-splt {
    width: 20%;
    height: 100vh;
    background: #e5eafc30;
    }


    .eml-add-main-con {
    width: 29%;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    font-size: 16px;
    
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }
    input.srch-ip-fld {
    width: 100%;
    height: 3vh;
    border: none;
    font-family: 'Lato';
    font-weight: 500;
    color: #c7ccd7;
}
.con-of-full-email-dt {
    width: 100%;
    height: 90vh;
    }

    .img-eml-ico-con {
    font-family: 'Lato';
    padding: 15px;
    border-radius: 50%;
    background: pink;
    margin-right: 10px;
    color: #ca1938;
}
.sub-ln-of-email-txt {
    width: 240px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-family: 'Lato';
    color: #908c8c;
    font-size: 13px;
}
input.srch-ip-fld:focus{
    outline: none;
    border: none;
}

    .fnt-ico-sel {
    width: 20px;
    text-align: center;
}

.con-of-cht-usr {
    width: 50%;
    display: inline-block;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    border-left: 1px solid #f2f2f2;
    }





.con-ico:hover{
    cursor: pointer;
}

.head-of-dash{
    background: #4a154b;
    text-align: right;
    border-bottom-left-radius: 50px;
}


.dropdown-menu .dropdown-item {
    padding: .5rem 1rem;
    font-size: 13px;
    font-weight: 600;
}

button.dropdown-item.comm_up_btn:hover {
    background: #0d66d6;
    color: white;
    }

    .dropdown-header {
    padding: .5rem 1rem;
    color: #f6f9fc;
    font-size: .625rem;
    text-transform: uppercase;
    font-weight: 700;
}
.dropdown-header {
    display: block;
    padding: .5rem 1rem;
    margin-bottom: 0;
    font-size: 0.875rem;
    color: #8898aa;
    white-space: nowrap;
    }
    .dropdown-menu {
    padding: 10px !important;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px !important;
}

.dropdown-item {
    border-radius: 10px;
    }

h6, .h6 {
    font-size: 0.625rem !important;
}


.head-of-inn-con {
    padding: 24px;
}
.all-auta-con {
    padding: 0px 24px;
    }
    span.nm-auta-con {
    font-size: 16px;
    font-weight: 500;
    font-family: 'lato';
    color: #00000080;
}

.crt-new-auta-con {
    width: 200px;
    background: rgb(143 4 175);
    padding: 24px 16px;
    border-radius: 10px;
    height: 200px;
    margin-right: 30px;
    margin-top: 20px;
   
    margin-left: 20px;
}

    .new-crt-head {
    line-height: 28px;
    font-weight: 700;
    color: white;
    font-family: 'Lato';
}
.con-of-crt-new-img {
    text-align: center;
    width: min-content;
    margin-top: 60px;
    padding: 10px;
    margin-left: auto;
    margin-right: auto;
    border-radius: 50%;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
    }

    .crt-new-auta-con:hover{
cursor: pointer;
    }

   .auta-dis-on-dash {
    width: 200px;
    padding: 24px 16px;
    border-radius: 10px;
    background: white;
    margin-right: 30px;
    height: 200px;
    padding-bottom: 0px;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px;
    
    margin-top: 20px;
   margin-left: 20px;    
}

.auta-dis-on-dash:hover{
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
cursor: pointer;

}
.main-con-name {
    flex: auto;
    min-height: 116px;
    display: inline-grid;
    width: 100%;
}
    
    span.bdg-tp-btn {
    margin-left: auto;
    font-size: 12px;
    background: rgb(245, 249, 248);
    padding: 2px 10px;
    border-radius: 10px;
    color: rgb(2, 80, 65);
    font-family: 'Lato';
    font-weight: 600;
    letter-spacing: .4px;
    height: fit-content;
}
.def-name-con-crd {
    display: inline-flex;

}
.ico-of-act-lst {
    width: 40%;
    margin: auto;
    text-align: center;
    padding: 10px;
    width: fit-content;
    border-radius: 10px;
    background: #f2f2f2;
    transition:.4s;
    }

    img.ico-img-src {
    height: 25px;
}
    .def_stat-of-dt {
    padding: 16px 0px;
    display: inline-flex;
    width: 100%;
    height: 60px;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    
}
    .con-of-cnt-data {
    padding: 5.5px 10px;
    background: rgba(0, 0, 0, 0.07);
    border-radius: 5px;
    color: rgb(38, 38, 39);
    width: 60%;
    text-align: center;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    }

    .con-of-dp-data {
    width: 40%;
}

button#dropdownMenuButton {
    background: no-repeat;
    border: none;
    height: 32px;
    padding: 5.5px;
    float: right;
    }

.all-auta-con {
    padding: 0px 24px;
    display: inline-flex;

}
.dropdown-toggle::after{
    display: none;
}

.dropdown-menu.show{
    border: none;
    border-radius: 10px;
}

a.com-for-lnk {
    text-decoration: none;
    color: #00000091;
    }
    .marg-for-temp{
        margin-left: 0px;
        margin-right: 30px;
    }
    .img-temp-of-mark{
        width: 168px;
        height: 166px;
    }










  .ip-by-def-dsg {
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;


  }

  .ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #524d52;
    box-shadow: 0 0 0 3px #bdb2bd4d;

    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;

  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

.btn-blck-in-auta-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(38, 38, 39);
    color: rgb(255, 255, 255);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
    font-family: 'lato';
}

.btn-blck-in-auta-fcs:hover{
    background-color: rgb(71, 71, 71);
    transition: all 0.2s ease 0s;
}

.btn-blck-non-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(227, 227, 227);
    color: rgb(38, 38, 39);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
}

.btn-blck-non-fcs:hover{
    background-color: rgb(231, 231, 231);
    transition: all 0.2s ease 0s;
    color: black;
}

.modal-content{
    border-radius: 8px;
}

.btn-blck-non-fcs:focus{
    color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;
}
.btn-blck-non-fcs:active{

color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;

}


.con-of-temp-lst {
    display: inline-flex;
    width: 100%;
    padding: 5px 10px;
    border-radius: 10px;
    margin-bottom: 10px;
    }

    .con-of-temp-lst:hover {
    background: #f2f2f28a;
    cursor: pointer;
}

.con-of-temp-lst>div {
    width: 50%;
    }

    span.temp-name {
    font-size: 14px;
}

span.crt-data-of-tmp {
    font-size: 10px;
    }
.row{
    margin-left: 0px;
    margin-right: 0px;
}








.btn-primary.focus, .btn-primary:focus{

    color: #fff;
    box-shadow: 0 0 0 0.2rem rgb(105 109 113 / 50%);
    background-color: rgb(38, 38, 39);
    border-color: rgb(38, 38, 39);

}





.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000e8;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
    z-index: 100000000;
}

#cncl-err-msg:hover{


cursor: pointer;


}



.vert-cent-div {
 
  height: min-content;
  text-align: center;
  
  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
    
  margin: auto;
}

.switch-dis{
    display: none;
}






button:disabled,
button[disabled]{
  
  background-color: #cccccc !important;
  color: #666666 !important;
  border: none;
  cursor: not-allowed;
}



.data-head-of-img-fold {
    margin-top: 20px;
    display: inline-flex;
    width: 100%;
    margin-bottom: 20px;
    }

    .main-con-of-img-con {
    width: 100%;
    height: calc(100vh - 8vh - 76px);
    overflow: scroll;
    padding: 30px;
}

.back-btn-to-fold {
    padding: 10px;
    background: #ff008a;
    border-radius: 100px;
    font-size: 12px;
    color: white;
    font-weight: 700;
    margin-left: auto;
    margin-right: auto;
    }

    .con-of-srch-img {
    width: 50%;
}

.con-of-act-img {
    display: inline-flex;
    width: 30%;
    }

    .back-btn-to-fold.color-of-opt-btn {
    padding: 6px;
    background: #c3c2c2;
    border: 0px;
    transition: .4s;
}

.auta-dis-on-dash.img-con-of-fold {
    position: relative;
    padding: 0px;
    border-radius: 0px;
    display: flex;
    justify-content: center;
    margin-right: auto;
    margin-left: 20px;
}


.fl-of-eml-and-lg {
    display: inline-flex;

}
   img.img-tag-for-con {
    width: auto;
    height: auto;
    position: absolute;
    top: 0;
    bottom: 0;
    max-height: 100%;
    max-width: 100%;
    margin: auto;
}

.back-btn-to-fold.color-of-opt-btn:hover {
    cursor: pointer;
    background: #c3c2c28f;
    }
    button.back-btn-to-fold.color-of-opt-btn:focus {
    outline: none;
}

.main-con-of-img-con{
    display: inline-flex;
}

.btn-mdl-act-sel {
    border-radius: 100px !important;
    color: black;
    font-weight: 500;
    font-size: 12px;
    margin-top: 20px;
    text-align: left;
    width: fit-content;
    }

    .btn-mdl-act-sel.active >svg {
    fill: white;
}

.btn-mdl-act-sel >svg {
    fill: black;
    }

    .btn-mdl-act-sel>svg{
        margin-right: 10px;
    }

    .btn-mdl-act-sel:hover svg{
        fill:blue;
    }

    .btn-mdl-act-sel.active:hover svg{
        fill:white;
    }

    .midd-sel-img {
    padding: 40px;
    border: 1px dashed;
    width: fit-content;
    padding: 40px;
    height: 100px;
    
    border-radius: 10px;

}
img.ico-img-hov {
    padding: 5px;
    border-radius: 10px;
}

img.ico-img-hov:hover{
background: #29252530;
cursor:pointer;
}
.edt_save_btn:hover{
cursor:pointer;
}
.midd-sel-img:hover{
    cursor: pointer;
}

img.img-pre-tg-img {
    width: 100%;
    height: auto;
    max-height: 100px;
    border-radius: 10px;

    }

    .img-con-pre {
    width: 98px;
    margin-right: 0px;
    height: 100px;
    position: relative;
    margin-right: 10px;
    margin-top: 10px;
}

#upload_img_form{
    display: inline-flex;
}

.con-of-all-srch {
    width: 600px;
    }

    .con-of-srch-img-thumb {
    border-top-right-radius: 10px;
}

img.img-of-con-srch {
    height: 200px;
    max-width: 250px;
    }

    .btn-con-of-dwn {
    padding: 10px;
    text-align: center;
}

    .full-swn-btn {
    width: fit-content;
    margin-right: 10px;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    margin-top: 10px;
    padding: 0px;
    border-radius: 10px;
}

.active_img_act {
    border: 3px solid blue;
    box-shadow: rgb(0 0 0 / 25%) 0px 14px 28px, rgb(0 0 0 / 22%) 0px 10px 10px;
    }

button.close {
    background: no-repeat;
    border: none;
    }


    th {
    font-weight: 600;
    font-size: 13px;
}

td {
    font-size: 12px;
    }


    .cp-round:after{
        border-top: solid 3px #564f4e;


    }
.img_editor-con{
    display: none;
}

    .tui-image-editor-header{
        display: none;
    }

    #tui-image-editor-container {
    width: 100% !important;
    height: calc(100vh - 52px) !important;
    top: 0px;
    position: fixed;
}

.save-fl-bar-con {
    width: 100%;
    height: 52px;
    background: #171717;
    margin-top: calc(100vh - 52px) !important;
    padding: 10px;
    text-align: right;
    }

    .ico-of-act-lst:hover{
        background:black !important;
    }



.not-fd-act-camp{

  text-align: center;
    padding: 40px 0px;
}

.not-fd-txt-rec{
  width: 60%;
    margin: auto;
    padding: 40px 20px;
    font-size: 13px;
  
    color: #1b1919;
}


.card {
    padding: 0px;
    border-radius: 10px;
}
</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> 
  <!-- CSS Files -->

</head>
<div id="c"></div>
<body class="" style="background:#fff">




<div class="main-con-of-dash">



 <div class="sd-con-ico dsc-inln-flx" style="
">
    
    <div class="sd-hd-con"><img src="https://res.cloudinary.com/heptera/image/upload/v1611850905/landing/open-collective_1_m4opwf.svg" width="" style="
    padding: 2vh
    ">
</div>

<div class="icon-con-of-sd">

    <style>


#main-loader-containre-act{


    text-align: center;
    padding-top: 41vh;
  }

.main-loader-containre-act{
  text-align: center;padding-top: 41vh;height: 84vh;
}



</style>
<div class="icon-main-con">
<div class="con-ico com-for-lnk" data-for-serv="0" data-target-link="https://campign.auftera.com/campigns/all-campign" data-toggle="tooltip" data-placement="right" title="Sheduled Campigns"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1626278281/automation/schedule_send_black_24dp_wybxtb.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="contact/" data-target-link="https://contact.auftera.com/contact/#acl" data-toggle="tooltip" data-placement="right" title="Manage Contact List"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1628748461/email-crm/playlist_add_circle_black_24dp_eryixo.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="template/" data-target-link="https://template.auftera.com/template/" data-toggle="tooltip" data-placement="right" title="Manage Template"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1626278301/automation/web_black_24dp_kx5cze.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="studio/" data-target-link="https://studio.auftera.com/studio/" data-toggle="tooltip" data-placement="right" title="Browse Studio"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1626278284/automation/camera_black_24dp_ldwdgu.svg"></div>
<div class="con-ico" data-toggle="tooltip" data-placement="right" title="Launch Automation"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1627707060/automation/model_training_black_24dp_wjuu9i.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="social/" data-target-link="https://social.auftera.com/social/" data-toggle="tooltip" data-placement="right" title="Social Post"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1627537307/automation/share_black_24dp_wpgnni.svg"></div>
</div>
<script>


id='<?php echo $id;?>';
email='<?php echo $email;?>';

$(document).on('click','.com-for-lnk',function(){



$("#main-loader-containre").addClass("main-loader-containre-act");
$("#main-loader-containre").html('<div class="cp-spinner cp-round"></div>');

url_lnk=$(this).attr('data-target-link');
ses_path=$(this).attr('data-path-ses');


var sourceString = url_lnk.replace('http://','').replace('https://','').replace('www.','').split(/[/?#]/)[0];

if($(this).attr('data-for-serv')=='1'){

red_url="https://"+sourceString+"/"+ses_path+"confige/crt_ses.php?id="+id+"&email="+email+"&url_red="+url_lnk;

console.log(red_url);


}else if($(this).attr('data-for-serv')=='0'){



red_url=$(this).attr('data-target-link');





}

console.log(red_url);
window.location.href=red_url;


})
</script>


</div>
        
    
    </div>


<div class="main-con-of-crm dsc-inln-flx">


<div class='head-of-dash' >







<div class="dropdown" style="
    height: 8vh;
"> 
    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="
    height: 8vh;
"> 
       <svg width="30" height="30" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="color:white;"><path d="M7 7H9V9H7V7Z" fill="currentColor"></path><path d="M11 7H13V9H11V7Z" fill="currentColor"></path><path d="M17 7H15V9H17V7Z" fill="currentColor"></path><path d="M7 11H9V13H7V11Z" fill="currentColor"></path><path d="M13 11H11V13H13V11Z" fill="currentColor"></path><path d="M15 11H17V13H15V11Z" fill="currentColor"></path><path d="M9 15H7V17H9V15Z" fill="currentColor"></path><path d="M11 15H13V17H11V15Z" fill="currentColor"></path><path d="M17 15H15V17H17V15Z" fill="currentColor"></path></svg>
    </button> 
    <div class="dropdown-menu dropdown-menu-right" x-placement="bottom-end" style="position: absolute; transform: translate3d(905px, 53px, 0px); top: 0px; left: 0px; will-change: transform;">
<div class=" dropdown-header noti-title">
<h6 class="text-overflow m-0">admin@auftera.com</h6>
</div>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="account/" data-target-link="https://account.auftera.com/account/sites/add_sites/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 8C6.74028 8 7.38663 7.5978 7.73244 7H14C15.1046 7 16 7.89543 16 9C16 10.1046 15.1046 11 14 11H10C7.79086 11 6 12.7909 6 15C6 17.2091 7.79086 19 10 19H16.2676C16.6134 19.5978 17.2597 20 18 20C19.1046 20 20 19.1046 20 18C20 16.8954 19.1046 16 18 16C17.2597 16 16.6134 16.4022 16.2676 17H10C8.89543 17 8 16.1046 8 15C8 13.8954 8.89543 13 10 13H14C16.2091 13 18 11.2091 18 9C18 6.79086 16.2091 5 14 5H7.73244C7.38663 4.4022 6.74028 4 6 4C4.89543 4 4 4.89543 4 6C4 7.10457 4.89543 8 6 8Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Connected App </span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="account/" data-target-link="https://account.auftera.com/account/sender/add_sender/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 9C16 11.2091 14.2091 13 12 13C9.79086 13 8 11.2091 8 9C8 6.79086 9.79086 5 12 5C14.2091 5 16 6.79086 16 9ZM14 9C14 10.1046 13.1046 11 12 11C10.8954 11 10 10.1046 10 9C10 7.89543 10.8954 7 12 7C13.1046 7 14 7.89543 14 9Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M12 1C5.92487 1 1 5.92487 1 12C1 18.0751 5.92487 23 12 23C18.0751 23 23 18.0751 23 12C23 5.92487 18.0751 1 12 1ZM3 12C3 14.0902 3.71255 16.014 4.90798 17.5417C6.55245 15.3889 9.14627 14 12.0645 14C14.9448 14 17.5092 15.3531 19.1565 17.4583C20.313 15.9443 21 14.0524 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12ZM12 21C9.84977 21 7.87565 20.2459 6.32767 18.9878C7.59352 17.1812 9.69106 16 12.0645 16C14.4084 16 16.4833 17.1521 17.7538 18.9209C16.1939 20.2191 14.1881 21 12 21Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Sender Profile</span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="account/" data-target-link="https://account.auftera.com/account/smtp/add_smtp/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 6C8.44772 6 8 6.44772 8 7C8 7.55228 8.44772 8 9 8H15C15.5523 8 16 7.55228 16 7C16 6.44772 15.5523 6 15 6H9Z" fill="currentColor"></path><path d="M9 10C8.44772 10 8 10.4477 8 11C8 11.5523 8.44772 12 9 12H15C15.5523 12 16 11.5523 16 11C16 10.4477 15.5523 10 15 10H9Z" fill="currentColor"></path><path d="M13 17C13 17.5523 12.5523 18 12 18C11.4477 18 11 17.5523 11 17C11 16.4477 11.4477 16 12 16C12.5523 16 13 16.4477 13 17Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M4 5C4 3.34315 5.34315 2 7 2H17C18.6569 2 20 3.34315 20 5V19C20 20.6569 18.6569 22 17 22H7C5.34315 22 4 20.6569 4 19V5ZM7 4H17C17.5523 4 18 4.44772 18 5V19C18 19.5523 17.5523 20 17 20H7C6.44772 20 6 19.5523 6 19V5C6 4.44772 6.44771 4 7 4Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
SMTP Server </span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="0" data-path-ses="contact/" data-target-link="https://contact.auftera.com/contact/emb/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M9 3H3V9H5V5H9V3ZM3 21V15H5V19H9V21H3ZM15 3V5H19V9H21V3H15ZM19 15H21V21H15V19H19V15ZM7 7H11V11H7V7ZM7 13H11V17H7V13ZM17 7H13V11H17V7ZM13 13H17V17H13V13Z" fill="currentColor"></path></svg><span class="padding-left:10px;">
Integration </span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="dev/" data-target-link="https://dev.auftera.com/dev/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 14V20H10V18H6V14H4Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M9 9V15H15V9H9ZM13 11H11V13H13V11Z" fill="currentColor"></path><path d="M4 10V4H10V6H6V10H4Z" fill="currentColor"></path><path d="M20 10V4H14V6H18V10H20Z" fill="currentColor"></path><path d="M20 14V20H14V18H18V14H20Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
API</span></button>
<div class="dropdown-divider"></div>
<button class="dropdown-item comm_up_btn" data-for-serv="1" data-target-link="http://account.auftera.com/logout/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M11 19V22H13V19H14C16.2091 19 18 17.2091 18 15C18 12.7909 16.2091 11 14 11H13V7H15V9H17V5H13V2H11V5H10C7.79086 5 6 6.79086 6 9C6 11.2091 7.79086 13 10 13H11V17H9V15H7V19H11ZM13 17H14C15.1046 17 16 16.1046 16 15C16 13.8954 15.1046 13 14 13H13V17ZM11 11V7H10C8.89543 7 8 7.89543 8 9C8 10.1046 8.89543 11 10 11H11Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Plan</span></button>
<button class="dropdown-item comm_up_btn com" data-for-serv="1" data-target-link="http://account.auftera.com/logout/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.51428 20H4.51428C3.40971 20 2.51428 19.1046 2.51428 18V6C2.51428 4.89543 3.40971 4 4.51428 4H8.51428V6H4.51428V18H8.51428V20Z" fill="currentColor"></path><path d="M13.8418 17.385L15.262 15.9768L11.3428 12.0242L20.4857 12.0242C21.038 12.0242 21.4857 11.5765 21.4857 11.0242C21.4857 10.4719 21.038 10.0242 20.4857 10.0242L11.3236 10.0242L15.304 6.0774L13.8958 4.6572L7.5049 10.9941L13.8418 17.385Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Log Out</span></button>
</div>
 </div>









        </div>



<?php require("../../ajaxfile/phpfile/top_of_mngc_2.php");?>

       

<div id='main-loader-containre' class="main-con-of-pro-data" style="
    width: 100%;
    padding-top: 10vh;
    display:flex;
">

    <div class="main-con-of-pro-dt">






<div class="container row marg-bot" style="margin:auto;margin-bottom:20px;padding: 0px;background: white;">

  <div class="container" style="width:100%;border: 1px solid;border-radius: 10px;">
    <div class="card-init-count" style="
    border-right: 1px solid;
">

    <div class="coun_con" id="tot_count_res">1</div>
    <div class="count_type">Total Response</div></div>


    <div class="card-init-count" style="
">

    <div class="coun_con" id="opn_count_res">0</div>
    <div class="count_type">Open Response</div></div>
    <div class="card-init-count" style="border-left: 1px solid;">

    <div class="coun_con" id="clck_count_res">1</div>
    <div class="count_type">Click Response</div></div>
    

    
    
</div>
</div>



















    
        <div class="con-of-pro-txt-dt">
        
<div class='fl-of-eml-and-lg'>

        <div class="ico-of-email-dt">

  <span id="ico-txt-of-eml">R</span>
</div>

<div class="txt-of-full-email"><span id="eml-con-of-usr-pro">rahul@gmail.com</span>
<br>
<span class="dt-con-of-hy">Added <span id="con-eml-add-tm">8 days Ago</span> by <span id="eml-src-con">convertcsv (17).csv</span></span><br>
<span id="con-btn-of-stat" class="status_span subscribe" style="background-color: rgb(10, 86, 9); color: rgb(255, 255, 255);">subscribe</span>
</div>
        </div>
        






<div class='dt-fld-for-pro'>


<div class="ico-hod-edt-dlt" style="
    text-align: right;
    padding: 10px;
    width:80%;
">

<button class="btn-of-edt-con edt_btn_of_dt">

<img class="ico-img-hov" src='https://res.cloudinary.com/heptera/image/upload/v1630816391/addcontact/create_black_24dp_1_vcwetd.svg'>

</button><button class="btn-of-edt-con">
<img class="ico-img-hov" src='https://res.cloudinary.com/heptera/image/upload/v1629958065/addcontact/delete_black_24dp_1_blzkno.svg'>
</button>

</div>

<table style="width: 80%;">
  
  <tbody id='tb_bd_of_email_pro'>
    
  
</tbody></table>


</div>








        </div>
    
       <div class="con-of-ana-data">
        
    
    
    <div class="rnd-of-camp-ln">




      <div class="steps" id='all_camp_act_by_id'>
  <div class="cp-spinner cp-round" style="
    margin-left: 40px;
"></div>
  
</div>


        
    </div>
    
    
    </div>
    
    
    
        
        
    
    
    </div>
    
    


</div>





















</div>

</div>












<script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>

 <script src="../../select_opt/jsfile/bundel.min.js"></script>


<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-throttle-debounce/1.1/jquery.ba-throttle-debounce.min.js"></script>
            
  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
 
  
  
</body>


<script type="text/javascript">


data_of_pro="";
data_of_camp="";


all_open_camp_cnt=0;
all_clk_camp_cnt=0;


$(document).ready(function(){


init_data_of_pro();

})



function init_data_of_pro() {


	$("#tot_count_res").html('<div class="cp-spinner cp-round"></div>');
$("#opn_count_res").html('<div class="cp-spinner cp-round"></div>');
$("#clck_count_res").html('<div class="cp-spinner cp-round"></div>');


$.ajax({
                url : "./ajaxfile/select_contact_pro.php",
                type: "GET",
                data : "filt_tag=mk"
        }).done(function(response){ 

data_of_pro=response;

console.log(data_of_pro);
get_all_camp_data();




});





}


function get_all_camp_data(){


$.ajax({
                url : "./ajaxfile/get_all_camp_data.php",
                type: "GET",
                data : "filt_tag=mk"
        }).done(function(response){ 


data_of_camp=response;







str_init_tbl();


str_init_activity_data();

});



}











timeAgo = (date) => {
            var ms = (new Date()).getTime() - date.getTime();
            var seconds = Math.floor(ms / 1000);
            var minutes = Math.floor(seconds / 60);
        var hours = Math.floor(minutes / 60);
        var days = Math.floor(hours / 24);
        var months = Math.floor(days / 30);
        var years = Math.floor(months / 12);
    
        if (ms === 0) {
            return 'Just now';
        } if (seconds < 60) {
            return seconds + ' seconds Ago';
        } if (minutes < 60) {
            return minutes + ' minutes Ago';
        } if (hours < 24) {
            return hours + ' hours Ago';
        } if (days < 30) {
            return days + ' days Ago';
        } if (months < 12) {
            return months + ' months Ago';
        } else {
            return years + ' years Ago';
        }
    
    }







function str_of_app_act(dt_tm,act,sub){


	camp_red_name=sub;
	sub=sub.split("^")[1];

str_of_app='<div class="step step-open"> <div class="step-header"> <div class="header" style=" ">'+dt_tm+'</div><div class="act-of-camp">'+act+'</div><div class="sub_of_camp">'+sub+'</div> </div> </div>';



return str_of_app;
}



function get_act_of_camp(act_id){


if(act_id>2){


all_clk_camp_cnt+=1;
 return "Click"


}else if(act_id>1){
  all_open_camp_cnt+=1;

  return "opened";
}else if(act_id>0){
 
 return "Sended";
}


}



function str_init_activity_data(){

console.log("ravi");
data_for_get=JSON.parse(data_of_camp)['data'];

console.log(data_for_get);

str_of_get_camp_act="";
if(typeof data_for_get !== 'undefined'){
for (var i = 0; i < data_for_get.length; i++) {
  

sub_ln=data_for_get[i]['subject'];

for (var j = 0; j < data_for_get[i]['activity'].length; j++) {



  console.log(data_for_get[i]['activity'][j]);


tm_dt_frm_db=timeAgo(new Date(data_for_get[i]['activity'][j]['act_date']));


act=get_act_of_camp(data_for_get[i]['activity'][j]['act']);

str_of_get_camp_act=str_of_app_act(tm_dt_frm_db,act,sub_ln)+str_of_get_camp_act;


  
};


};




}else{

str_of_get_camp_act='<div class="not-fd-act-camp" style=" "> <img src="https://res.cloudinary.com/heptera/image/upload/v1630815943/addcontact/undraw_Business_analytics_re_tfh3_srhjxc.svg" style="width: 40%;"><div class="not-fd-txt-rec" style=" "> Not Found Any Activity For This Contact </div> </div>';

}





$("#tot_count_res").html(all_open_camp_cnt+all_clk_camp_cnt);
$("#opn_count_res").html(all_open_camp_cnt);
$("#clck_count_res").html(all_clk_camp_cnt);



$("#all_camp_act_by_id").html(str_of_get_camp_act);


}





function sub_stat_enco(sub_flg){

if(sub_flg==1){
                sub_stat="subscribe";
                colr_stat="#0a5609";
        }else if(sub_flg==2){
                sub_stat="un-subscribe";
                colr_stat="#dc1a7d";
        }else if(sub_flg==3){

                sub_stat="none-subscribe";
                colr_stat="#d20c0c";
        }else if(sub_flg==4){
                sub_stat="bounced";
                colr_stat="#be1adc";

	}else if(sub_flg==5){
		sub_stat="VIP";
		colr_stat="#2a0e9c";
	}


$("#con-btn-of-stat").html(sub_stat);
$("#con-btn-of-stat").css("background-color",colr_stat);

}





function str_init_tbl(){




len_of_camp_arr=JSON.parse(data_of_camp)['camp_num'];

jsn_dec_data=JSON.parse(data_of_pro);




i=0;

console.log(jsn_dec_data);

len_of_arr=Object.keys(jsn_dec_data).length;

limit_of=len_of_arr-len_of_camp_arr;
str_ret="";




$("#eml-con-of-usr-pro").html(jsn_dec_data['email']);
$("#con-eml-add-tm").html(timeAgo(new Date(jsn_dec_data['crt_date'])));
$("#eml-src-con").html(jsn_dec_data['source']);
$("#ico-txt-of-eml").html(jsn_dec_data['email'][0].toUpperCase());
sub_stat_enco(jsn_dec_data['substatus']);



for (const [key, value] of Object.entries(jsn_dec_data)) {

	console.log(key);

if(i<limit_of-11){

  str_ret+="<tr><td class='fld-name'  id=''>"+key+"</td> <td trg-name='"+key+"' class='fld-val fld_js_trg' >"+value+"</td></tr>";

  i+=1;

}else{

break;

}

}



$("#tb_bd_of_email_pro").html(str_ret);




}





$(document).on('click','.edt_btn_of_dt',function(){


$('.fld_js_trg').map(function() {
   

ip_plc_hld=$(this).html();

$(this).empty();

$(this).html('<input class="ip-by-def-dsg"  type="text" style="padding-left:10px;height:40px;width:100%;" value="'+ip_plc_hld+'">');




});


$(this).html('save');
$(this).removeClass('edt_btn_of_dt');
$(this).addClass('edt_save_btn');


})

jsn_data_save={};


$(document).on('click','.edt_save_btn',function(){



$('.fld_js_trg').map(function() {
   
app_key=$(this).attr('trg-name');
app_val=$(this).children('.ip-by-def-dsg').val();

jsn_data_save[app_key]=app_val;

});

up_db_of_profile();




})


function up_db_of_profile(){


console.log(jsn_data_save);



$.ajax({
            url: './ajaxfile/update_pro_data.php',
            type: 'post',
            data: {data:JSON.stringify(jsn_data_save)}
        }).done(function(response){ 

console.log(response);


if(response==1){

init_data_of_pro();
$(".edt_save_btn").html("<img class='ico-img-hov' src='https://res.cloudinary.com/heptera/image/upload/v1630816391/addcontact/create_black_24dp_1_vcwetd.svg'>");
$(".edt_save_btn").addClass('edt_btn_of_dt');
$(".edt_save_btn").removeClass('edt_save_btn');


}else{



}

});


}

</script>




</html>












