
<?php
session_start();

require("../confige/fileconfige.php");

 $url_main="auftera.com";

$id=$_SESSION['id'];
$email=$_SESSION['email'];
?>






<html><head>




<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1628745601/loader_ww3kdih.css">


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">




<style type="text/css">


.sd-con-ico.dsc-inln-flx {
    width: 8%;
    height: 100%;
}

.tooltip-arrow {
    
    }


[data-popper-placement="right"]>.tooltip-arrow{

transform: none !important;
    top: 8px !important;

}
.main-con-of-crm.dsc-inln-flx {
    width: 92%;
    height: 100%;
    float: right;
    background: #fafafa;
    overflow: scroll;
}

    .dsc-inln-flx {
    display: inline-block;
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

    .icon-con-of-sd {
    height: 90vh;
    width: 100%;
}

.icon-main-con {
    height: auto;
    width: 100%;
    position: relative;
    top: 50%;
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    }

    .con-ico {
    padding: 20px;
    text-align: center;
}

img.con-of-ico-img {
    height: 30px;
    }




.con-of-main-splt {
    width: 20%;
    height: 100vh;
    display: inline-block;

}
.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

   
h2.head-od-dt-shw {
    margin: 0px;
    }


button.btn-of-drk-back {
    height: 6vh;
    width: 100%;
    background: #125ef6;
    border: 0px;
    border-radius: 5px;
    color: white;
}

.con-of-dt-sel-ele {
    height: 80vh;
    width: 100%;
    overflow: scroll;
    }

    .container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 15px;
}
a.com-for-lnk {
    text-decoration: none;
    color: black;
    }

    h2.head-od-dt-shw {
    margin: 0px;
    font-family: lato;
    font-size: 15px;
    font-weight: bolder;
}
.con-of-main-splt {
    width: 20%;
    height: 100vh;
    background: #e5eafc30;
    }


    .eml-add-main-con {
    width: 29%;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    font-size: 16px;
    
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }
    input.srch-ip-fld {
    width: 100%;
    height: 3vh;
    border: none;
    font-family: 'Lato';
    font-weight: 500;
    color: #c7ccd7;
}
.con-of-full-email-dt {
    width: 100%;
    height: 90vh;
    }

    .img-eml-ico-con {
    font-family: 'Lato';
    padding: 15px;
    border-radius: 50%;
    background: pink;
    margin-right: 10px;
    color: #ca1938;
}
.sub-ln-of-email-txt {
    width: 240px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-family: 'Lato';
    color: #908c8c;
    font-size: 13px;
}
input.srch-ip-fld:focus{
    outline: none;
    border: none;
}

    .fnt-ico-sel {
    width: 20px;
    text-align: center;
}

.con-of-cht-usr {
    width: 50%;
    display: inline-block;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    border-left: 1px solid #f2f2f2;
    }





.con-ico:hover{
    cursor: pointer;
}

.head-of-dash{
    background: #4a154b;
    text-align: right;
    border-bottom-left-radius: 50px;
}


.dropdown-menu .dropdown-item {
    padding: .5rem 1rem;
    font-size: 13px;
    font-weight: 600;
}

button.dropdown-item.comm_up_btn:hover {
    background: #0d66d6;
    color: white;
    }

    .dropdown-header {
    padding: .5rem 1rem;
    color: #f6f9fc;
    font-size: .625rem;
    text-transform: uppercase;
    font-weight: 700;
}
.dropdown-header {
    display: block;
    padding: .5rem 1rem;
    margin-bottom: 0;
    font-size: 0.875rem;
    color: #8898aa;
    white-space: nowrap;
    }
    .dropdown-menu {
    padding: 10px !important;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px !important;
}

.dropdown-item {
    border-radius: 10px;
    }

h6, .h6 {
    font-size: 0.625rem !important;
}


.head-of-inn-con {
    padding: 24px;
}
.all-auta-con {
    padding: 0px 24px;
    }
    span.nm-auta-con {
    font-size: 16px;
    font-weight: 500;
    font-family: 'lato';
    color: #00000080;
}

.crt-new-auta-con {
    width: 200px;
    background: rgb(143 4 175);
    padding: 24px 16px;
    border-radius: 10px;
    height: 200px;
    margin-right: 30px;
    margin-top: 20px;
   
    margin-left: 20px;
}

    .new-crt-head {
    line-height: 28px;
    font-weight: 700;
    color: white;
    font-family: 'Lato';
}
.con-of-crt-new-img {
    text-align: center;
    width: min-content;
    margin-top: 60px;
    padding: 10px;
    margin-left: auto;
    margin-right: auto;
    border-radius: 50%;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
    }

    .crt-new-auta-con:hover{
cursor: pointer;
    }

   .auta-dis-on-dash {
    width: 200px;
    padding: 24px 16px;
    border-radius: 10px;
    background: white;
    margin-right: 30px;
    height: 200px;
    padding-bottom: 0px;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px;
    
    margin-top: 20px;
   margin-left: 20px;    
}

.auta-dis-on-dash:hover{
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
cursor: pointer;

}
.main-con-name {
    flex: auto;
    min-height: 116px;
    display: inline-grid;
    width: 100%;
}
    
    span.bdg-tp-btn {
    margin-left: auto;
    font-size: 12px;
    background: rgb(245, 249, 248);
    padding: 2px 10px;
    border-radius: 10px;
    color: rgb(2, 80, 65);
    font-family: 'Lato';
    font-weight: 600;
    letter-spacing: .4px;
    height: fit-content;
}
.def-name-con-crd {
    display: inline-flex;

}
.ico-of-act-lst {
    width: 40%;
    margin: auto;
    text-align: center;
    padding: 10px;
    width: fit-content;
    border-radius: 10px;
    background: #f2f2f2;
    transition:.4s;
    }

    img.ico-img-src {
    height: 25px;
}
    .def_stat-of-dt {
    padding: 16px 0px;
    display: inline-flex;
    width: 100%;
    height: 60px;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    
}
    .con-of-cnt-data {
    padding: 5.5px 10px;
    background: rgba(0, 0, 0, 0.07);
    border-radius: 5px;
    color: rgb(38, 38, 39);
    width: 60%;
    text-align: center;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    }

    .con-of-dp-data {
    width: 40%;
}

button#dropdownMenuButton {
    background: no-repeat;
    border: none;
    height: 32px;
    padding: 5.5px;
    float: right;
    }

.all-auta-con {
    padding: 0px 24px;
    display: inline-flex;

}
.dropdown-toggle::after{
    display: none;
}

.dropdown-menu.show{
    border: none;
    border-radius: 10px;
}

a.com-for-lnk {
    text-decoration: none;
    color: #00000091;
    }
    .marg-for-temp{
        margin-left: 0px;
        margin-right: 30px;
    }
    .img-temp-of-mark{
        width: 168px;
        height: 166px;
    }










  .ip-by-def-dsg {
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;


  }

  .ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #524d52;
    box-shadow: 0 0 0 3px #bdb2bd4d;

    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;

  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

.btn-blck-in-auta-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(38, 38, 39);
    color: rgb(255, 255, 255);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
    font-family: 'lato';
}

.btn-blck-in-auta-fcs:hover{
    background-color: rgb(71, 71, 71);
    transition: all 0.2s ease 0s;
}

.btn-blck-non-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(227, 227, 227);
    color: rgb(38, 38, 39);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
}

.btn-blck-non-fcs:hover{
    background-color: rgb(231, 231, 231);
    transition: all 0.2s ease 0s;
    color: black;
}

.modal-content{
    border-radius: 8px;
}

.btn-blck-non-fcs:focus{
    color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;
}
.btn-blck-non-fcs:active{

color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;

}


.con-of-temp-lst {
    display: inline-flex;
    width: 100%;
    padding: 5px 10px;
    border-radius: 10px;
    margin-bottom: 10px;
    }

    .con-of-temp-lst:hover {
    background: #f2f2f28a;
    cursor: pointer;
}

.con-of-temp-lst>div {
    width: 50%;
    }

    span.temp-name {
    font-size: 14px;
}

span.crt-data-of-tmp {
    font-size: 10px;
    }
.row{
    margin-left: 0px;
    margin-right: 0px;
}








.btn-primary.focus, .btn-primary:focus{

    color: #fff;
    box-shadow: 0 0 0 0.2rem rgb(105 109 113 / 50%);
    background-color: rgb(38, 38, 39);
    border-color: rgb(38, 38, 39);

}





.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000e8;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
    z-index: 100000000;
}

#cncl-err-msg:hover{


cursor: pointer;


}



.vert-cent-div {
 
  height: min-content;
  text-align: center;
  
  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
    
  margin: auto;
}

.switch-dis{
    display: none;
}






button:disabled,
button[disabled]{
  
  background-color: #cccccc !important;
  color: #666666 !important;
  border: none;
  cursor: not-allowed;
}



.data-head-of-img-fold {
    margin-top: 20px;
    display: inline-flex;
    width: 100%;
    margin-bottom: 20px;
    }

    .main-con-of-img-con {
    width: 100%;
    height: calc(100vh - 8vh - 76px);
    overflow: scroll;
    padding: 30px;
}

.back-btn-to-fold {
    padding: 10px;
    background: #ff008a;
    border-radius: 100px;
    font-size: 12px;
    color: white;
    font-weight: 700;
    margin-left: auto;
    margin-right: auto;
    }

    .con-of-srch-img {
    width: 50%;
}

.con-of-act-img {
    display: inline-flex;
    width: 30%;
    }

    .back-btn-to-fold.color-of-opt-btn {
    padding: 6px;
    background: #c3c2c2;
    border: 0px;
    transition: .4s;
}

.auta-dis-on-dash.img-con-of-fold {
    position: relative;
    padding: 0px;
    border-radius: 0px;
    display: flex;
    justify-content: center;
    margin-right: auto;
    margin-left: 20px;
}
   img.img-tag-for-con {
    width: auto;
    height: auto;
    position: absolute;
    top: 0;
    bottom: 0;
    max-height: 100%;
    max-width: 100%;
    margin: auto;
}

.back-btn-to-fold.color-of-opt-btn:hover {
    cursor: pointer;
    background: #c3c2c28f;
    }
    button.back-btn-to-fold.color-of-opt-btn:focus {
    outline: none;
}

.main-con-of-img-con{
    display: inline-flex;
}

.btn-mdl-act-sel {
    border-radius: 100px !important;
    color: black;
    font-weight: 500;
    font-size: 12px;
    margin-top: 20px;
    text-align: left;
    width: fit-content;
    }

    .btn-mdl-act-sel.active >svg {
    fill: white;
}

.btn-mdl-act-sel >svg {
    fill: black;
    }

    .btn-mdl-act-sel>svg{
        margin-right: 10px;
    }

    .btn-mdl-act-sel:hover svg{
        fill:blue;
    }

    .btn-mdl-act-sel.active:hover svg{
        fill:white;
    }

    .midd-sel-img {
    padding: 40px;
    border: 1px dashed;
    width: fit-content;
    padding: 40px;
    height: 100px;
    
    border-radius: 10px;

}

.midd-sel-img:hover{
    cursor: pointer;
}

img.img-pre-tg-img {
    width: 100%;
    height: auto;
    max-height: 100px;
    border-radius: 10px;

    }

    .img-con-pre {
    width: 98px;
    margin-right: 0px;
    height: 100px;
    position: relative;
    margin-right: 10px;
    margin-top: 10px;
}

#upload_img_form{
    display: inline-flex;
}

.con-of-all-srch {
    width: 600px;
    }

    .con-of-srch-img-thumb {
    border-top-right-radius: 10px;
}

img.img-of-con-srch {
    height: 200px;
    max-width: 250px;
    }

    .btn-con-of-dwn {
    padding: 10px;
    text-align: center;
}

    .full-swn-btn {
    width: fit-content;
    margin-right: 10px;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    margin-top: 10px;
    padding: 0px;
    border-radius: 10px;
}

.active_img_act {
    border: 3px solid blue;
    box-shadow: rgb(0 0 0 / 25%) 0px 14px 28px, rgb(0 0 0 / 22%) 0px 10px 10px;
    }

button.close {
    background: no-repeat;
    border: none;
    }


    th {
    font-weight: 600;
    font-size: 13px;
}

td {
    font-size: 12px;
    }


    .cp-round:after{
        border-top: solid 3px #564f4e;


    }
.img_editor-con{
    display: none;
}

    .tui-image-editor-header{
        display: none;
    }

    #tui-image-editor-container {
    width: 100% !important;
    height: calc(100vh - 52px) !important;
    top: 0px;
    position: fixed;
}

.save-fl-bar-con {
    width: 100%;
    height: 52px;
    background: #171717;
    margin-top: calc(100vh - 52px) !important;
    padding: 10px;
    text-align: right;
    }

    .ico-of-act-lst:hover{
        background:black !important;
    }

    table#data-tbl-name {
    width: 80%;
    margin: auto;
    background-color: rgb(255, 255, 255);
    border-radius: 8px;
    box-shadow: rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 8%) 0px 2px 4px;
}

th {
    font-size: 14px;
    font-weight: 400;
    padding: 15px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.07);
    color: rgb(120 120 150);
    font-family: 'Lato';
    }

    td {
    padding: 20px 30px;
    font-size: 13px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.07);
}


span.badge.badge-primary.bdg-in-tbl {
    font-size: 12px;
    background: #66339914;
    border: 1px solid #663399f7;
    border-radius: 50px;
    color: #370d61;
    font-weight: 400;
    font-family: 'Lato';
    letter-spacing: 1px;
}

button.btn-con-main-txt-ico {
    background: no-repeat;
    border: none;
    width: 54px;
    height: 54px;
    padding: 0px;
    border-radius: 50%;
    transition: .2s;
    margin-right: 10px;
    }

    button.btn-con-main-txt-ico:hover {
    background: #00008b26;
}
span.txt-of-btn {
    font-size: 10px;
    }

    .crt_tag_con {
    margin-top: 20px;
    color: black;
    font-weight: 500;
    font-family: 'Lato';
}

.btn_con_of_db {
    text-align: right;
    }

    .btn-act-of-upp {
    width: 80%;
    margin: auto;
    padding: 30px 0px;
}





















.select-wrapper {
        margin: auto;
        max-width: 600px;
        width: calc(100% - 40px);
      }

      .select-pure__select {
        align-items: center;
        background: white;
margin:10px;      
  border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: none;
        box-sizing: border-box;
        color: #363b3e;
        cursor: pointer;
        display: flex;
        font-size: 16px;
        font-weight: 500;
        justify-content: left;
        min-height: 44px;
        padding: 5px 10px;
        position: relative;
        transition: 0.2s;
        width: 300px;
      }

      .select-pure__options {
        border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: #363b3e;
        display: none;
        left: 0;
        max-height: 220px;
        overflow-y: scroll;
        position: absolute;
        top: 50px;
        width: 100%;
        z-index: 5;
      }

      .select-pure__select--opened .select-pure__options {
        display: block;
      }

      .select-pure__option {
        background: #fff;
        border-bottom: 1px solid #e4e4e4;
        box-sizing: border-box;
        height: 44px;
        line-height: 25px;
        padding: 10px;
      }

      .select-pure__option--selected {
        color: #e4e4e4;
        cursor: initial;
        pointer-events: none;
      }

      .select-pure__option--hidden {
        display: none;
      }

      .select-pure__selected-label {

  align-items: 'center';
       
  border-radius: 4px;
font-size:13px;
        color: #5a2977;
    background: rgba(90, 41, 119, 0.11);
        cursor: initial;
        display: inline-flex;
        justify-content: 'center';
        margin: 5px 10px 5px 0;
        padding: 3px 7px;
      }

      .select-pure__selected-label:last-of-type {
        margin-right: 0;
      }

      .select-pure__selected-label i {
        cursor: pointer;
        display: inline-block;
        margin-left: 7px;
      }

      .select-pure__selected-label img {
        cursor: pointer;
        display: inline-block;
        height: 18px;
        margin-left: 7px;
        width: 14px;
      }

      .select-pure__selected-label i:hover {
        color: black;
      }

      .select-pure__autocomplete {
        background: #f9f9f8;
        border-bottom: 1px solid #e4e4e4;
        border-left: none;
        border-right: none;
        border-top: none;
        box-sizing: border-box;
        font-size: 16px;
        outline: none;
        padding: 10px;
        width: 100%;
      }

      .select-pure__placeholder--hidden {
        display: none;
      }







.ip_fl_con {
    padding: 10px;
}



span.find_lst_cnt {
    padding: 10px;
    background: green;
    color: white;
    font-weight: 600;
    border-radius: 20px;
    font-size: 10px;
}



input#chooseFile {
    margin-bottom: 20px;
}

</style>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

<body style="
    margin: 0px;
">





<div class="vert-cent-div err-menu-cls-dsg" id="err_msg_dt_trg" style="display: none;">
<span id="con-of-err-msg"></span>
<span class="cls-err-menu" id="cncl-err-msg">
<i class="fal fa-times-circle" style="
    padding: 6px;
"></i>
</span>
</div>


<div class="main-con-of-dash">

     <?php require("../confige/header/theme-2.0-side.php");?>
    <div class="main-con-of-crm dsc-inln-flx">
         <?php    require("../confige/header/header-new.php");?>
     

<?php require("../ajaxfile/phpfile/top_of_mngc_2.php");?>

       
    
 <div class="main-auta-con" id='main-loader-containre'>
    
<div class="switch-dis" id='fold-cnt-con' style='display:block;'>

    <div class="head-of-inn-con">
        <span class="nm-auta-con">Tag Managment</span>
    
    </div>


    <div class="btn-act-of-upp">

    <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" data-toggle="modal" data-target="#crt_new_tag_mdl" style="
">Add Tag</button>
    
   
    <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" data-toggle="modal" data-target="#blck_tag_mdl" style="
">Bulk Tag</button>

</div>


<table id="data-tbl-name">
 <tbody><tr>
    <th>Tag Name

    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-sort-alpha-down" viewBox="0 0 16 16" style="
    margin-left: 10px;
    fill: black;
    padding: 2px;
    background: #f2f2f2;
    border-radius: 2px;
">
  <path fill-rule="evenodd" d="M10.082 5.629 9.664 7H8.598l1.789-5.332h1.234L13.402 7h-1.12l-.419-1.371h-1.781zm1.57-.785L11 2.687h-.047l-.652 2.157h1.351z"></path>
  <path d="M12.96 14H9.028v-.691l2.579-3.72v-.054H9.098v-.867h3.785v.691l-2.567 3.72v.054h2.645V14zM4.5 2.5a.5.5 0 0 0-1 0v9.793l-1.146-1.147a.5.5 0 0 0-.708.708l2 1.999.007.007a.497.497 0 0 0 .7-.006l2-2a.5.5 0 0 0-.707-.708L4.5 12.293V2.5z"></path>
</svg>


</th>
    
    <th>


   

</th>
  </tr>

   </tbody><tbody id="insight_tag_data"><tr> <td><span class="icon-of-tbl"><div class="cp-spinner cp-round"></div></span></td> <td></td>  </tr></tbody></table>


</div>




    
    
</div>




 












    
    </div>




   


</div>





<div class="modal" id="blck_tag_mdl" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Rename of <span id="rnm-tag-name-spn"></span></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <span class="autocomplete-select"></span>




    <form method="POST" action="./bulktag/ajaxfile/act_bulk_tag.php" id="subfileform"  enctype="multipart/form-data">
<div class="ip_fl_con" style="width;100%;">
    <input type="file" name="file" id="chooseFile" required="" style="font-weight:500;">
  </div>

<div class='btn-con-sub'>


</div>
</form>
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="sub_btn_add_blc_tg">Add Tag</button>
      </div>
    </div>
  </div>
</div>




<div class="modal" id="rnm_new_tag_mdl" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Rename of <span id="rnm-tag-name-spn"></span></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="rename_tag_name_ip" placeholder="Enter New name">
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="rename_tag_btn">Rename Tag</button>
      </div>
    </div>
  </div>
</div>





<div class="modal" id="crt_new_tag_mdl" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">New Tag </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="new_tag_name_ip" placeholder="Enter New name">
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="new_tag_btn">Create Tag</button>
      </div>
    </div>
  </div>
</div>













<div class="modal" id="del_auta_crt_mdl" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Delete Tag</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="del_val_ip" placeholder="Enter DELETE And Click">
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="del_tag_btn_fin">Delete Tag</button>
      </div>
    </div>
  </div>
</div>






</body></html>

<script src="../select_opt/jsfile/bundel.min.js"></script>




<script type="text/javascript">

id='<?php echo $id;?>';

url_main='<?php echo $url_main;?>';

str_app="";








function append_tag(item, index){
  let op = json.filter(e=> e.value == item);
  
$("#tag_ver_con").append("<span class='select-pure__selected-label'>"+op[0]['label']+"</span>");


}

arr_of_all_tg_lbl=[];


value2=[];


function init_sel_tag_dt(){





var autocomplete = new SelectPure(".autocomplete-select", {
        options: arr_of_all_tg_lbl,
        value: [],
        multiple: true,
        autocomplete: true,
        icon: "fa fa-times",
        onChange: value => { value2=[];value2.push(value);},
        classNames: {
          select: "select-pure__select",
          dropdownShown: "select-pure__select--opened",
          multiselect: "select-pure__select--multiple",
          label: "select-pure__label",
          placeholder: "select-pure__placeholder",
          dropdown: "select-pure__options",
          option: "select-pure__option",
          autocompleteInput: "select-pure__autocomplete",
          selectedLabel: "select-pure__selected-label",
          selectedOption: "select-pure__option--selected",
          placeholderHidden: "select-pure__placeholder--hidden",
          optionHidden: "select-pure__option--hidden",
        }
      });

}











res_json_arr="";



function init_arr_of_lst_dt(){
    event.preventDefault(); //prevent default action 
    var post_url = $("#subfileform").attr("action"); //get form action url
    var request_method = $("#subfileform").attr("method"); //get form GET/POST method
    var form_data = $("#subfileform").serialize(); //Encode form elements for submission
   
   form_dt=$("#subfileform");
    $.ajax({
        url:post_url,
   method:"POST",
   data:new FormData(form_dt[0]),
   contentType:false,
   cache:false,
   processData:false,
   beforeSend: function () {
        
      
        },
   
    }).done(function(response){ //

        console.log(response);

        res_json_arr=response;

        json_arr_get=JSON.parse(response);
        console.log(json_arr_get.length);


$(".ip_fl_con").append("<span class='find_lst_cnt'>"+json_arr_get.length+" Emails Found</span>")



    });


}



$(document).on('change','#chooseFile',function(){


init_arr_of_lst_dt();
})


$(document).on("click",'#sub_btn_add_blc_tg',function(){

    if(value2.length>0){

        if(res_json_arr==""){
err_msg_data("Select CSV File");

        }else{

            append_load_in_all_btn("#sub_btn_add_blc_tg");

chg_tag_in_db();

}

}else{


    err_msg_data("Select Valid Tag");
}

})

function chg_tag_in_db(){

    tag_get=JSON.stringify(value2);


    $.ajax({
                url : "./bulktag/ajaxfile/get_all_user_tag.php",
                type: "POST",
                data : "mail_list="+res_json_arr+"&tag_list="+tag_get
        }).done(function(response2){ 

update_tag_into_db(response2);

        });
}






function init_str_of_tag_act(tag_arr){





    for(const val of tag_arr){

loc_arr={};

        loc_arr['value']=val[2];
        loc_arr['label']=val[0];



if(val[1]==null){

tag_crt="By Default";

}else{

    var d = new Date(val[1]);
    tag_crt=d.toUTCString();
}
    str_app+='<tr> <td class="name_con"><span class="badge badge-primary bdg-in-tbl">'+val[0]+'</span><br><div class="crt_tag_con">'+tag_crt+'</div> </td> <td class="btn_con_tag"> <div class="btn_con_of_db"> <button class="btn-con-main-txt-ico"> <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 8.88916C13.6569 8.88916 15 10.2323 15 11.8892C15 13.1954 14.1652 14.3066 13 14.7185V19.8892H11V14.7185C9.83481 14.3066 9 13.1954 9 11.8892C9 10.2323 10.3431 8.88916 12 8.88916ZM12 10.8892C12.5523 10.8892 13 11.3369 13 11.8892C13 12.4414 12.5523 12.8892 12 12.8892C11.4477 12.8892 11 12.4414 11 11.8892C11 11.3369 11.4477 10.8892 12 10.8892Z" fill="currentColor"></path><path d="M7.05019 6.93938C5.78348 8.20612 5 9.9561 5 11.8891C5 14.0666 5.99426 16.0119 7.55355 17.2957L8.97712 15.8721C7.7757 14.9589 7 13.5146 7 11.8891C7 10.5084 7.55962 9.25841 8.46441 8.35359L7.05019 6.93938Z" fill="currentColor"></path><path d="M15.5355 8.35348C16.4403 9.25831 17 10.5083 17 11.8891C17 13.5146 16.2243 14.959 15.0228 15.8722L16.4463 17.2958C18.0057 16.012 19 14.0666 19 11.8891C19 9.95604 18.2165 8.20602 16.9497 6.93927L15.5355 8.35348Z" fill="currentColor"></path><path d="M1 11.8891C1 8.85152 2.23119 6.10155 4.22176 4.11095L5.63598 5.52516C4.00733 7.15383 3 9.40381 3 11.8891C3 14.3743 4.00733 16.6243 5.63597 18.2529L4.22175 19.6672C2.23119 17.6766 1 14.9266 1 11.8891Z" fill="currentColor"></path><path d="M19.7781 19.6673C21.7688 17.6767 23 14.9266 23 11.8891C23 8.85147 21.7688 6.10145 19.7781 4.11084L18.3639 5.52505C19.9926 7.15374 21 9.40376 21 11.8891C21 14.3744 19.9926 16.6244 18.3639 18.2531L19.7781 19.6673Z" fill="currentColor"></path></svg> <br> <span class="txt-of-btn">campign</span> </button> <button class="btn-con-main-txt-ico rename_tag_old" data-trg-db="'+val[0]+'" id="'+val[2]+'" data-toggle="modal" data-target="#rnm_new_tag_mdl"> <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.99255 11.0159C4.44027 11.0159 3.99255 10.5682 3.99255 10.0159C3.99255 9.6585 4.18004 9.3449 4.46202 9.16807L7.14964 6.48045C7.54016 6.08993 8.17333 6.08993 8.56385 6.48045C8.95438 6.87098 8.95438 7.50414 8.56385 7.89467L7.44263 9.0159L14.9926 9.01589C15.5448 9.01589 15.9926 9.46361 15.9926 10.0159C15.9926 10.5682 15.5448 11.0159 14.9926 11.0159L5.042 11.0159C5.03288 11.016 5.02376 11.016 5.01464 11.0159H4.99255Z" fill="currentColor"></path><path d="M19.0074 12.9841C19.5597 12.9841 20.0074 13.4318 20.0074 13.9841C20.0074 14.3415 19.82 14.6551 19.538 14.8319L16.8504 17.5195C16.4598 17.9101 15.8267 17.9101 15.4361 17.5195C15.0456 17.129 15.0456 16.4958 15.4361 16.1053L16.5574 14.9841H9.00745C8.45516 14.9841 8.00745 14.5364 8.00745 13.9841C8.00745 13.4318 8.45516 12.9841 9.00745 12.9841L18.958 12.9841C18.9671 12.984 18.9762 12.984 18.9854 12.9841H19.0074Z" fill="currentColor"></path></svg> <br> <span class="txt-of-btn">Rename</span> </button> <button class="btn-con-main-txt-ico del_tag_btn" data-trg-db="'+val[0]+'" id="'+val[2]+'" data-toggle="modal" data-target="#del_auta_crt_mdl"> <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M17 5V4C17 2.89543 16.1046 2 15 2H9C7.89543 2 7 2.89543 7 4V5H4C3.44772 5 3 5.44772 3 6C3 6.55228 3.44772 7 4 7H5V18C5 19.6569 6.34315 21 8 21H16C17.6569 21 19 19.6569 19 18V7H20C20.5523 7 21 6.55228 21 6C21 5.44772 20.5523 5 20 5H17ZM15 4H9V5H15V4ZM17 7H7V18C7 18.5523 7.44772 19 8 19H16C16.5523 19 17 18.5523 17 18V7Z" fill="currentColor"></path><path d="M9 9H11V17H9V9Z" fill="currentColor"></path><path d="M13 9H15V17H13V9Z" fill="currentColor"></path></svg> <br> <span class="txt-of-btn">Delete</span> </button><button class="btn-con-main-txt-ico exp_tag" onclick="location.href=\'../export/fin_export.php?tag_send=12\'"> <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16.9498 5.96781L15.5356 7.38203L13 4.84646V17.0421H11V4.84653L8.46451 7.38203L7.05029 5.96781L12 1.01807L16.9498 5.96781Z" fill="currentColor"></path><path d="M5 20.9819V10.9819H9V8.98193H3V22.9819H21V8.98193H15V10.9819H19V20.9819H5Z" fill="currentColor"></path></svg> <br> <span class="txt-of-btn">Export</span> </button> </div> </td> </tr>';

arr_of_all_tg_lbl.push(loc_arr);
}

console.log(arr_of_all_tg_lbl);

$("#insight_tag_data").html(str_app);

init_sel_tag_dt();

}


$(document).on("click",".del_tag_btn",function(){


 old_tag=$(this).attr("id");



});
$(document).on("click","#del_tag_btn_fin",function(){


del_ip_val=$("#del_val_ip").val();

if(del_ip_val=="DELETE"){

    new_val="";

append_load_in_all_btn("#del_tag_btn_fin");

    
        update_tag_val(old_tag+",",new_val);

    }else{

        err_msg_data("Eneter DELETE excatly");
    }

})






$(document).on("click","#new_tag_btn",function(){


var new_tag_name=$("#new_tag_name_ip").val();

if(new_tag_name.length>0){

create_new_tag(new_tag_name);

}else{
    err_msg_data("Enter Valid Tag Name");
}

});
function create_new_tag(geted_name){


  append_load_in_all_btn("#new_tag_btn");


    $.ajax({
                url : "./ajaxfile/crt_new_tag.php",
                type: "POST",
                data : "new_tag="+geted_name
        }).done(function(response){ 


 append_txt_of_lds("#new_tag_btn");
        if(response==1){
       
         location.reload();

    }else{

err_msg_data("Please Enter Unique Tag");

    }

       


        }); 




}






    

function update_tag_val(old_tag,new_val){

$.ajax({
  type: "POST",
  url: "./ajaxfile/rename_tag.php",
  data: {old_tag_name:old_tag,new_tag_name:new_val}
}).done(function(response1) {

append_txt_of_lds("#del_tag_btn_fin");

append_txt_of_lds("#rename_tag_btn");

   


if(new_val==""){

    

    
update_tag_into_db(response1);

old_tag=old_tag.substring(0,old_tag.length - 1)
del_tag_fr_db(old_tag);

}else{

if(response1==1){

location.reload();

}else{
    err_msg_data("Enter tag Name Unique");
}




}







});



}





function del_tag_fr_db(old_tag){



$.ajax({
                url : "./ajaxfile/rem_ele_db.php",
                type: "POST",
                data : "tag_id="+old_tag
        }).done(function(response){ 

        console.log(response);


        }); 

}







function update_tag_into_db(data_json_tag){

  

$.ajax({
                url : "../mngc/ajaxfile/update_tag.php",
                type: "POST",
                data : "requestoflist="+data_json_tag+"&get_stat_act="+"tag"
        }).done(function(response){ 



console.log(response);

location.reload();

    });


}





$(document).on("click","#rename_tag_btn",function(){
new_val="";

var new_val=$("#rename_tag_name_ip").val();


if(new_val.length>0){

append_load_in_all_btn("#rename_tag_btn");



update_tag_val(old_tag_glo,new_val);

}else{
    err_msg_data("Enter Valid Name");
}

});
old_tag_glo="";



$(document).on('click','.rename_tag_old',function(){

    old_tag_glo=$(this).attr("id");

tag_name_def=$(this).attr('data-trg-db');

$("#rnm-tag-name-spn").html(tag_name_def);


})

function init_all_tag_act_tbl(id){


$.ajax({
                url : "./ajaxfile/get_all_tag.php",
                type: "POST",
                data : {usr_id:id}
        }).done(function(response){ 

console.log(response);

init_str_of_tag_act(JSON.parse(response));


        });

}





$(document).ready(function(){




init_all_tag_act_tbl(id);


setTimeout(function(){ $('[data-toggle="tooltip"]').tooltip(); }, 5000);



})




function append_load_in_all_btn(selector){




append_txt_that_get_clck=$(selector).html();

$(selector).prop("disabled",true);

$(selector).html('<div class="cp-spinner cp-round"></div>');

}



function append_txt_of_lds(selector){

$(selector).prop("disabled",false);

$(selector).html(append_txt_that_get_clck);


}


err_msg_data("Welcome To Studio");


function err_msg_data(message){


$("#con-of-err-msg").html(message);

$("#err_msg_dt_trg").css('display','inline-block');



setTimeout(
    function() {


      $("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');
      
    }, 5000);


}


$(document).on('click','#cncl-err-msg',function(){


$("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

})




</script>
