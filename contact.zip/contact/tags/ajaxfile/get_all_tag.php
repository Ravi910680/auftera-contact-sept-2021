<?php

require("../../confige/managetag.php");
$array_of_tag = array();

$id=$_POST['usr_id'];

$tag_tbl_name="tag".$id;
$select_tag = "select * from ".$tag_tbl_name;
$result = $mngtag->query($select_tag);


while($row = $result->fetch_assoc()) {
        $temp_array=array();

        array_push($temp_array,$row["tag"],$row['date'],$row['id']);       
        array_push($array_of_tag,$temp_array);
    }

    $geted_tag_array=$array_of_tag;

    echo json_encode($geted_tag_array);

?>
