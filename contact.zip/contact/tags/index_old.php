<?php
session_start();

    $mail=$_SESSION["email"];
    $id=$_SESSION["id"];

    $lst_name=$_SESSION['listname'];

require("../confige/fileconfige.php");
require("../confige/managetag.php");
$array_of_tag = array();

$tag_tbl_name="tag".$id;
$select_tag = "select * from ".$tag_tbl_name;
$result = $mngtag->query($select_tag);


while($row = $result->fetch_assoc()) {
        $temp_array=array();

        array_push($temp_array,$row["tag"],$row['date'],$row['id']);       
        array_push($array_of_tag,$temp_array);
    }

    $geted_tag_array=$array_of_tag;

?>
    <!DOCTYPE html>
<html lang="en">

<style type="text/css">
.bottom-btn{
  text-align: center;
    height: 40px;
 background: #5a297747;
    color: #5a2977;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;

    padding-left: 20px;
    padding-right: 20px;
}
.not-fd-data{
  text-align: center;
padding: 40px;
    background: white;
    border-radius: 4px;

}




.txt-not-fd{
  padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
}

body{

}
.bottom-btn:hover{
  cursor: pointer;
}

.main-con {
    padding: 20px 0px 70px 0px;

    }

    a.hr-tag-con {
    color: #4a154b;
    font-size: 15px;

  }








button.btn_hover_clr {
    
        background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    color: #1a73e8;
    font-size: 13px;
    font-weight: 500;
    background: white;
  }

  

button.btn_hover_clr:hover {
    background: #e8f0fe;
    cursor: pointer;
  }



button.btn_of_act {
    background: #540a47;
    font-size: 13px;
    border-radius: 5px;
    color: white;
    padding: 5px 15px;
    border: none;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    margin-right: 20px;
}



</style>
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">

<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet"> 


 <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />
 <link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1603531914/norm_used/loader_ww3kih.css">

<?php require("../confige/header/header.php");?>

<?php require("../ajaxfile/phpfile/top_of_mngc.php");?>




<div id="main-loader-containre">


<div class="container" style="width:100%;padding:120px 0px 0px 0px;">






<div class="main-con">
    
        <div class="">
            <a class="hr-tag-con" href="../../addcontact/"><i class="fal fa-chevron-left" aria-hidden="true" style="
    padding-right: 10px;
"></i>Back To Manage List</a>
        
        </div>
    
    </div>




</div>



<style type="text/css">
.btn_con_tag{
	padding:20px;
width: 20%;

}
.crt_tag_con{
	margin-top: 10px;
	font-weight: 500;
}
.name_con{
width:70%;
}
.chk_con{
width: 10%;
}








.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}







.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid #5a2977;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: #5a2977 transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
















.table{

	width:80%;
}
a.dropdown-item{
	padding: 10px;
}
a.dropdown-item:hover {
    color: #5a2977;
    background: rgba(90, 41, 119, 0.11);

    }
    .badge-primary{
font-size: 15px;
    	 color: #5a2977;
    background: rgba(90, 41, 119, 0.11);
    }

    .btn-outline-light{
    	font-weight: 500;
    	color: #5a2977;
    background: rgba(90, 41, 119, 0.11);
    }
    .dropdown-item{
    	font-weight: 500;
    	color: #212529ad;
    }








button.btn-con-main-txt-ico {
    background: no-repeat;
    border: none;
    width: 54px;
    height: 54px;
    padding: 0px;
    border-radius: 50%;
    transition: .2s;
    margin-right: 10px;
  }

  span.txt-of-btn {
    font-size: 10px;
  }

  button.btn-con-main-txt-ico:hover {
    background: #00008b26;

  }







































.modal-2 {
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 0vh;
  background-color: transparent;
  overflow: hidden;
  transition: background-color 0.25s ease;
  z-index: 9999;
}
.modal-2.open {
  position: fixed;
  width: 100%;
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.5);
  transition: background-color 0.25s;
}
.modal-2.open > .content-wrapper {
  transform: scale(1);
}
.modal-2 .content-wrapper {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  width: 40%;
  margin: 0;
  padding: 2.5rem;
  background-color: white;
  border-radius: 0.3125rem;
  box-shadow: 0 0 2.5rem rgba(0, 0, 0, 0.5);
  transform: scale(0);
  transition: transform 0.25s;
  transition-delay: 0.15s;
}
.modal-2 .content-wrapper .close {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 2.5rem;
  height: 2.5rem;
  border: none;
  background-color: transparent;
  font-size: 1.5rem;
  transition: 0.25s linear;
}
.modal-2 .content-wrapper .close:before, .modal-2 .content-wrapper .close:after {
  position: absolute;
  content: '';
  width: 1.25rem;
  height: 0.125rem;
  background-color: black;
}
.modal-2 .content-wrapper .close:before {
  transform: rotate(-45deg);
}
.modal-2 .content-wrapper .close:after {
  transform: rotate(45deg);
}
.modal-2 .content-wrapper .close:hover:before, .modal-2 .content-wrapper .close:hover:after {
  background-color: tomato;
}
.modal-2 .content-wrapper .modal-2-header {
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  margin: 0;
  padding: 0 0 1.25rem;
}
.modal-2 .content-wrapper .modal-2-header h2 {
  font-size: 1.5rem;
  font-weight: bold;
}
.modal-2 .content-wrapper .content {
    position: relative;
    display: flex;
    text-align: center;
    color: #504b4b;
  }
.modal-2 .content-wrapper .content p {
  font-size: 0.875rem;
  line-height: 1.75;
}
.modal-2 .content-wrapper .modal-2-footer {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  width: 100%;
  margin: 0;
  padding: 1.875rem 0 0;
}
.modal-2 .content-wrapper .modal-2-footer .action {
  position: relative;
  margin-left: 0.625rem;
  padding: 0.625rem 1.25rem;
  border: none;
  background-color: slategray;
  border-radius: 0.25rem;
  color: white;
  font-size: 0.87rem;
  font-weight: 300;
  overflow: hidden;
  z-index: 1;
}
.modal-2 .content-wrapper .modal-2-footer .action:before {
  position: absolute;
  content: '';
  top: 0;
  left: 0;
  width: 0%;
  height: 100%;
  background-color: rgba(255, 255, 255, 0.2);
  transition: width 0.25s;
  z-index: 0;
}
.modal-2 .content-wrapper .modal-2-footer .action:first-child {
  background-color: #2ecc71;
}
.modal-2 .content-wrapper .modal-2-footer .action:last-child {
  background-color: #e74c3c;
}
.modal-2 .content-wrapper .modal-2-footer .action:hover:before {
  width: 100%;
}






.modal-2-header h2{

  color: black;
}


.modal-2{

}



</style>


<div class="container" style='max-width:80%;'>
<div class="row" style="padding: 20px 0px;margin:0px;">

<div class="" style="width:50%;font-size: 20px;font-weight: 700;color: #5a2977f2;">
Tag
</div>

<div class="" style="width:50%;text-align:right;">

<button class="btn_of_act crt_new_tag_mdl_trg" data-modal-trigger="crt_new_tag_mdl" style="
    height: fit-content;

">Create Tag<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" style='margin-left:10px;' class="bi bi-bookmark-plus" viewBox="0 0 16 16">
  <path d="M2 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v13.5a.5.5 0 0 1-.777.416L8 13.101l-5.223 2.815A.5.5 0 0 1 2 15.5V2zm2-1a1 1 0 0 0-1 1v12.566l4.723-2.482a.5.5 0 0 1 .554 0L13 14.566V2a1 1 0 0 0-1-1H4z"/>
  <path d="M8 4a.5.5 0 0 1 .5.5V6H10a.5.5 0 0 1 0 1H8.5v1.5a.5.5 0 0 1-1 0V7H6a.5.5 0 0 1 0-1h1.5V4.5A.5.5 0 0 1 8 4z"/>
</svg></button>

<button class="btn_of_act com-for-lnk" data-for-serv="0" data-target-link="http://localhost/html/dash/main/addcontact/bulktag"  style="
   
    height: fit-content;
    
">Bulk Tag<svg xmlns="http://www.w3.org/2000/svg" width="16" style='margin-left:10px;' height="16" fill="currentColor" class="bi bi-bookmarks" viewBox="0 0 16 16">
  <path d="M2 4a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v11.5a.5.5 0 0 1-.777.416L7 13.101l-4.223 2.815A.5.5 0 0 1 2 15.5V4zm2-1a1 1 0 0 0-1 1v10.566l3.723-2.482a.5.5 0 0 1 .554 0L11 14.566V4a1 1 0 0 0-1-1H4z"/>
  <path d="M4.268 1H12a1 1 0 0 1 1 1v11.768l.223.148A.5.5 0 0 0 14 13.5V2a2 2 0 0 0-2-2H6a2 2 0 0 0-1.732 1z"/>
</svg></button>
</div>

 </div>
</div>

<?php  if(count($geted_tag_array)==0){


?>




<div class="container not-fd-data" style="margin-top:60px;
">

<img src="https://image.flaticon.com/icons/svg/902/902079.svg" height="64" style="
">
<div class="txt-not-fd">
You Haven't Any Template Right Now. But dont Worry It's very Easzy to Create With heptera|<sub>edito</sub>
  </div>

<button class="bottom-btn crt_new_tag_mdl_trg"  data-modal-trigger="crt_new_tag_mdl" style="float:none;"><i class="far fa-edit" aria-hidden="true" style="
    padding-right: 10px;
"></i>create tag</button>
</div>




<?php

    }else{
?>
<table class="container table">
  

  <tbody>

<?php





foreach ($geted_tag_array as $key => $value) {
	
	

	?>


    <tr>
      
      <td class="name_con"><span class="badge badge-primary"><?php echo $value[0]; ?></span><br><div class="crt_tag_con">created
<?php echo $value[1];?></div>
      </td>
      
      






<td class="btn_con_tag">

      <div class="btn_con_of_db">
          
          


<button class="btn-con-main-txt-ico">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 8.88916C13.6569 8.88916 15 10.2323 15 11.8892C15 13.1954 14.1652 14.3066 13 14.7185V19.8892H11V14.7185C9.83481 14.3066 9 13.1954 9 11.8892C9 10.2323 10.3431 8.88916 12 8.88916ZM12 10.8892C12.5523 10.8892 13 11.3369 13 11.8892C13 12.4414 12.5523 12.8892 12 12.8892C11.4477 12.8892 11 12.4414 11 11.8892C11 11.3369 11.4477 10.8892 12 10.8892Z" fill="currentColor"></path><path d="M7.05019 6.93938C5.78348 8.20612 5 9.9561 5 11.8891C5 14.0666 5.99426 16.0119 7.55355 17.2957L8.97712 15.8721C7.7757 14.9589 7 13.5146 7 11.8891C7 10.5084 7.55962 9.25841 8.46441 8.35359L7.05019 6.93938Z" fill="currentColor"></path><path d="M15.5355 8.35348C16.4403 9.25831 17 10.5083 17 11.8891C17 13.5146 16.2243 14.959 15.0228 15.8722L16.4463 17.2958C18.0057 16.012 19 14.0666 19 11.8891C19 9.95604 18.2165 8.20602 16.9497 6.93927L15.5355 8.35348Z" fill="currentColor"></path><path d="M1 11.8891C1 8.85152 2.23119 6.10155 4.22176 4.11095L5.63598 5.52516C4.00733 7.15383 3 9.40381 3 11.8891C3 14.3743 4.00733 16.6243 5.63597 18.2529L4.22175 19.6672C2.23119 17.6766 1 14.9266 1 11.8891Z" fill="currentColor"></path><path d="M19.7781 19.6673C21.7688 17.6767 23 14.9266 23 11.8891C23 8.85147 21.7688 6.10145 19.7781 4.11084L18.3639 5.52505C19.9926 7.15374 21 9.40376 21 11.8891C21 14.3744 19.9926 16.6244 18.3639 18.2531L19.7781 19.6673Z" fill="currentColor"></path></svg>
              <br>
              <span class="txt-of-btn">campign</span>
          
          </button>



<button class="btn-con-main-txt-ico rename_tag_old" id="<?php echo $value[2];?>" data-modal-trigger="rnm_new_tag_mdl" >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.99255 11.0159C4.44027 11.0159 3.99255 10.5682 3.99255 10.0159C3.99255 9.6585 4.18004 9.3449 4.46202 9.16807L7.14964 6.48045C7.54016 6.08993 8.17333 6.08993 8.56385 6.48045C8.95438 6.87098 8.95438 7.50414 8.56385 7.89467L7.44263 9.0159L14.9926 9.01589C15.5448 9.01589 15.9926 9.46361 15.9926 10.0159C15.9926 10.5682 15.5448 11.0159 14.9926 11.0159L5.042 11.0159C5.03288 11.016 5.02376 11.016 5.01464 11.0159H4.99255Z" fill="currentColor"></path><path d="M19.0074 12.9841C19.5597 12.9841 20.0074 13.4318 20.0074 13.9841C20.0074 14.3415 19.82 14.6551 19.538 14.8319L16.8504 17.5195C16.4598 17.9101 15.8267 17.9101 15.4361 17.5195C15.0456 17.129 15.0456 16.4958 15.4361 16.1053L16.5574 14.9841H9.00745C8.45516 14.9841 8.00745 14.5364 8.00745 13.9841C8.00745 13.4318 8.45516 12.9841 9.00745 12.9841L18.958 12.9841C18.9671 12.984 18.9762 12.984 18.9854 12.9841H19.0074Z" fill="currentColor"></path></svg>
              <br>
              <span class="txt-of-btn">Rename</span>
          
          </button>



<button class="btn-con-main-txt-ico del_tag_btn" data-modal-trigger="del_mdl_tag" id="<?php echo $value[2];?>">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M17 5V4C17 2.89543 16.1046 2 15 2H9C7.89543 2 7 2.89543 7 4V5H4C3.44772 5 3 5.44772 3 6C3 6.55228 3.44772 7 4 7H5V18C5 19.6569 6.34315 21 8 21H16C17.6569 21 19 19.6569 19 18V7H20C20.5523 7 21 6.55228 21 6C21 5.44772 20.5523 5 20 5H17ZM15 4H9V5H15V4ZM17 7H7V18C7 18.5523 7.44772 19 8 19H16C16.5523 19 17 18.5523 17 18V7Z" fill="currentColor"></path><path d="M9 9H11V17H9V9Z" fill="currentColor"></path><path d="M13 9H15V17H13V9Z" fill="currentColor"></path></svg>
              <br>
              <span class="txt-of-btn">Delete</span>
          
          </button><button class="btn-con-main-txt-ico exp_tag" onclick="location.href='../export/fin_export.php?tag_send=<?php echo $value[2];?>'">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16.9498 5.96781L15.5356 7.38203L13 4.84646V17.0421H11V4.84653L8.46451 7.38203L7.05029 5.96781L12 1.01807L16.9498 5.96781Z" fill="currentColor"></path><path d="M5 20.9819V10.9819H9V8.98193H3V22.9819H21V8.98193H15V10.9819H19V20.9819H5Z" fill="currentColor"></path></svg>
              <br>
              <span class="txt-of-btn">Export</span>
          
          </button>
   
    
      </div>  


</td>





    </tr>
   
   
 

	<?php


}




?>
 </tbody>
</table>
<?php

    }?>

  </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>














<div class="modal-2" data-modal="del_mdl_tag" id="del_mdl_tag">
  <article class="content-wrapper" style="
    width: auto;
">
     
    
    

<div class="head-line-of-mdl" style="
    margin-right: auto;
    color:black;
">
    <h4>Delete Tag</h4>




</div>



   


<div class="btn-con-del-camp" style="
    width: 100%;
    font-size: 13px;
    font-weight: 500;
">

Allow To Delete Tag Permanentaly.


   
</div>


    <button class="btn-theme-dsg " id="del_tag_btn_fin" style="
    margin-top: 20px;
">Delete Tag</button>

<button class="btn-theme-dsg  del_mdl_cls" mdl-cls-tp="del_mdl_tag" style="background:white;color:#350835;border:1px solid #350835;">Cancel,Keep It </button>
 
  </article>
</div>




<div class="modal-2" data-modal="rnm_new_tag_mdl" id='rnm_new_tag_mdl'>
  <article class="content-wrapper">
     
    
    

<div class="head-line-of-mdl" style="
    margin-right: auto;
    color:black;
">
    <h4>Rename Tag</h4>

</div>

   


<div class="btn-con-del-camp" style="
    width: 100%;
">

   <input class="ip-by-def-dsg" id="rename_tag_name_ip" name="nameofnewlist" type="text" style="max-width:100%;" required="">
    
   
    
</div>


    <button class="btn-theme-dsg " id="rename_tag_btn" style="">Rename Tag</button>
 <button class="btn-theme-dsg  del_mdl_cls" mdl-cls-tp="rnm_new_tag_mdl" style="background:white;color:#350835;border:1px solid #350835;">Cancel,Keep It As It Is</button>
 
  </article>
</div>






<div class="modal-2" data-modal="crt_new_tag_mdl" id='crt_new_tag_mdl'>
  <article class="content-wrapper">
     
    
    

<div class="head-line-of-mdl" style="
    margin-right: auto;
    color:black;
">
    <h4>Create New Tag</h4>

   
</div>

   


<div class="btn-con-del-camp" style="
    width: 100%;
">

   <input class="ip-by-def-dsg" id="new_tag_name_ip" name="nameofnewlist" type="text" style="max-width:100%;" required="">
    
   
    
</div>


    <button class="btn-theme-dsg " id="new_tag_btn" style="">Create New Tag</button>

    <button class="btn-theme-dsg  del_mdl_cls" mdl-cls-tp="crt_new_tag_mdl" style="background:white;color:#350835;border:1px solid #350835;">Not Create Yet </button>
 
 
  </article>
</div>










<script type="text/javascript">


	    old_tag_glo="";












$(document).ready(function(){












id_now_path= window.location.href.split('#');
    console.log(id_now_path.length);
    for(i=0;i<id_now_path.length-1;i++){
	    if(i==0){
	    $("#"+id_now_path[i+1]).addClass("txt-of-opt-active");
	    }else{


                

		    $("#"+id_now_path[i+1]).addClass("txt-of-opt-active");





		    $("#"+id_now_path[i+1]).css("border-bottom","none");
	    }

    }

});






















    

$(document).on("click","#rename_tag_btn",function(){
new_val="";

var new_val=$("#rename_tag_name_ip").val();

append_load_in_all_btn("#rename_tag_btn");

update_tag_val(old_tag_glo,new_val);

});



$(document).on("click",".rename_tag_old",function(){

old_tag_glo=$(this).attr("id");


modalEvent(this);


});


old_tag="";
$(document).on("click",".del_tag_btn",function(){


 old_tag=$(this).attr("id");


 modalEvent(this);

});
$(document).on("click","#del_tag_btn_fin",function(){
console.log( old_tag);
	new_val="";

append_load_in_all_btn("#del_tag_btn_fin");

	
        update_tag_val(old_tag+",",new_val);

})

function update_tag_val(old_tag,new_val){

$.ajax({
  type: "POST",
  url: "./ajaxfile/rename_tag.php",
  data: {old_tag_name:old_tag,new_tag_name:new_val}
}).done(function(response1) {


	console.log(response1);
if(new_val==""){
update_tag_into_db(response1);

old_tag=old_tag.substring(0,old_tag.length - 1)
del_tag_fr_db(old_tag);




}


location.reload();

append_txt_of_lds("#del_tag_btn_fin");

append_txt_of_lds("#rename_tag_btn");



});



}







function update_tag_into_db(data_json_tag){

  

$.ajax({
                url : "../mngc/ajaxfile/update_tag.php",
                type: "POST",
                data : "requestoflist="+data_json_tag+"&get_stat_act="+"tag"
        }).done(function(response){ 



console.log(response);

location.reload();

	});


}





function del_tag_fr_db(old_tag){



$.ajax({
                url : "./ajaxfile/rem_ele_db.php",
                type: "POST",
                data : "tag_id="+old_tag
        }).done(function(response){ 

        console.log(response);


        }); 

}














$(document).on("click","#new_tag_btn",function(){


var new_tag_name=$("#new_tag_name_ip").val();

console.log(new_tag_name);

create_new_tag(new_tag_name);

});
function create_new_tag(geted_name){


  append_load_in_all_btn("#new_tag_btn");


	$.ajax({
                url : "./ajaxfile/crt_new_tag.php",
                type: "POST",
                data : "new_tag="+geted_name
        }).done(function(response){ 

        console.log(response);

        append_txt_of_lds("#new_tag_btn");

        location.reload();


        }); 




}












function modalEvent(button) {

  
    const trigger = button.getAttribute('data-modal-trigger');
    const modal = document.querySelector(`[data-modal=${trigger}]`);
   
    
    
    
    

    modal.classList.toggle('open');
  
  
}



$(document).on('click',".del_mdl_cls",function(){


tp_of_mdl=$(this).attr("mdl-cls-tp");

$("#"+tp_of_mdl).removeClass("open");


})











$(document).on('click','.crt_new_tag_mdl_trg',function(){


modalEvent(this);

})






append_txt_that_get_clck="";



function append_load_in_all_btn(selector){




append_txt_that_get_clck=$(selector).html();

$(selector).prop("disabled",true);

$(selector).html('<div class="cp-spinner cp-round"></div>');

}



function append_txt_of_lds(selector){

$(selector).prop("disabled",false);

$(selector).html(append_txt_that_get_clck);


}







</script>



