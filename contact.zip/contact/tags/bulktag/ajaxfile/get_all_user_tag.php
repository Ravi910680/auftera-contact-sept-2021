<?php
session_start();
require("../../../confige/fileconfige.php");
$lst_name=$_SESSION["listname"];

$get_tag_data=json_decode($_POST["tag_list"]);

$get_mail_data=json_decode($_POST['mail_list']);
$fin_res_arr=array();

foreach ($get_mail_data as $key => $value) {
	$tag_str="";
	$sel_query_usr="select * from `".$lst_name."` where email='".$value."'";
$result = $conn3->query($sel_query_usr);


while($row = $result->fetch_assoc()) {
if($result->num_rows > 0){

		$tag_str.=$row['tag'];
		

for($j=0;$j<count($get_tag_data[0]);$j++) {

if (strpos($tag_str, $get_tag_data[0][$j].",")=== false) {


$tag_str.=$get_tag_data[0][$j].",";
	}
}

}

}

$fin_res_arr[$value]=$tag_str;


}

$json_arr=json_encode($fin_res_arr);
echo $json_arr;

?>
