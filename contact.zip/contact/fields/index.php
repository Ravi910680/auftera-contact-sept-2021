<?php
session_start();


$id=$_SESSION['id'];
$email=$_SESSION['email'];

function get_str_of_opt($var_of_tp){

$arr_of_tp=array("text","date","int");

$str_of_rt="<select id='stat_of_tp' class='ip-by-def-dsg' style='max-width:100%;width:100%;'>";

foreach ($arr_of_tp as $value) {
  
if($value==$var_of_tp){
  $flg_of_stat="Selected";
}else{

$flg_of_stat="";

}


$str_of_rt.="<option value='".$value."'".$flg_of_stat." >".$value."</option>";


}

$str_of_rt.="</select>";



return $str_of_rt;
}














function get_email_col($list_id){
require("../confige/fileconfige.php");


  $get_col_query="SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='list_contacts' AND `TABLE_NAME`='".$list_id."' ORDER BY ordinal_position";

  $query = $conn3->query($get_col_query);

while($row = $query->fetch_assoc()){


  $result[] = $row;
}

// Array of all column names
$columnArr = array_column($result, 'COLUMN_NAME');

return $columnArr;



}













function get_col_type($list_id,$col_get){
require("../confige/fileconfige.php");

$columnArr=array();

$i=0;


while(count($col_get)>$i){




      $get_col_query="SELECT `DATA_TYPE` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE  `TABLE_NAME`='".$list_id."' AND COLUMN_NAME ='".$col_get[$i]."'";
        $query = $conn3->query($get_col_query);

while($row = $query->fetch_assoc()){
$data_type=$row['DATA_TYPE'];

  if($data_type=='varchar'){

                $dt_tp='text';
        }else if($data_type=='date'){
                $dt_tp='date';
        }else if ($data_type=='bigint' || $data_type=='int'){
                $dt_tp='int';
        }









array_push($columnArr,$dt_tp);
}

$i+=1;

}


return $columnArr;

}
















require("../confige/fileconfige.php");
require("../ajaxfile/phpfile/mysql_to_ip.php");

require("../confige/camp_confige.php");




$lst_name=$_SESSION['listname'];
$get_camp_data="select * from camp_contact_tbl where list_id='$lst_name'";





$result = $camp_name_conn->query($get_camp_data);



$cnt_camp=$result->num_rows;





$get_col=get_email_col($_SESSION['listname']);


$get_col=array_slice($get_col,0,count($get_col)-$cnt_camp-11);


$mail=$_SESSION["email"];



?>




<html>
<head>




<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1628745601/loader_ww3kdih.css">


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1628745601/loader_ww3kdih.css">



<style type="text/css">












.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid #fff;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: #fff transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}





















#new_fld_tp select{
height: 40px;
    margin: 20px 0px;
    width: 20%;
}























.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;










}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{

border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#007c89;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}
button:focus{
    outline:none;
}












.dlt_trg_icn{
font-size:20px !important;
text-align:center;
}




















body{
font-family: 'lato';
       
}

.head_add_sub {
   color:#000000e0; 
    padding-bottom: 20px;
    font-size: 20px;
    font-weight: 600;
}

input[type="checkbox"] { display: none; }

input[type="checkbox"] + label {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 20px;
  font: 14px/20px 'Open Sans', Arial, sans-serif;
  color: #ddd;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}

.table>:not(caption)>*>*{
  border-bottom: 0px;
}
input[type="checkbox"] + label:last-child { margin-bottom: 0; }

input[type="checkbox"] + label:before {
  content: '';
  display: block;
  width: 20px;
  height: 20px;
  border: 1px solid black;
  position: absolute;
  left: 0;
  top: 0;
  opacity: .6;
  -webkit-transition: all .12s, border-color .08s;
  transition: all .12s, border-color .08s;
}

input[type="checkbox"]:checked + label:before {
  width: 10px;
  top: -5px;
  left: 5px;
  border-radius: 0;
  opacity: 1;
  border-top-color: transparent;
  border-left-color: transparent;
  -webkit-transform: rotate(45deg);
  transform: rotate(45deg);
}

.head-fr-any {
    padding: 20px 0px;
    letter-spacing: -0.02rem;
    color: #000000e0;
}
.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
                   float: right;
    padding-left: 20px;
    padding-right: 20px;
}
.bottom-btn:hover{
        cursor: pointer;
}

.fld_name_sty{
height: 40px;
    border-radius: 5px;
    border: 1px solid #f2f2f2;
    width: 200px;
    font-size: 15px;
    padding: 10px;
}
.mrg-tag-sty {
    font-size: 16px;
    font-weight: 700;
    height: 40px;
}


















#main-loader-containre-act{


    text-align: none !important;
    
  }

.main-loader-containre-act{
  text-align: center !important;padding-top: 41vh;height: 84vh;
}


button.btn_of_act {
    background: #540a47;
    font-size: 13px;
    border-radius: 5px;
    color: white;
    padding: 5px 15px;
    border: none;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    margin-right: 20px;
}



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

button:hover{

cursor:pointer;
}
.dlt_trg_icn:hover{

cursor:pointer;
}









.sd-con-ico.dsc-inln-flx {
    width: 8%;
    height: 100%;
}

.tooltip-arrow {
    
    }


[data-popper-placement="right"]>.tooltip-arrow{

transform: none !important;
    top: 8px !important;

}
.main-con-of-crm.dsc-inln-flx {
    width: 92%;
    height: 100%;
    float: right;
    background: #fafafa;
    overflow: scroll;
}

    .dsc-inln-flx {
    display: inline-block;
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

    .icon-con-of-sd {
    height: 90vh;
    width: 100%;
}

.icon-main-con {
    height: auto;
    width: 100%;
    position: relative;
    top: 50%;
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    }

    .con-ico {
    padding: 20px;
    text-align: center;
}

img.con-of-ico-img {
    height: 30px;
    }




.con-of-main-splt {
    width: 20%;
    height: 100vh;
    display: inline-block;

}
.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

   
h2.head-od-dt-shw {
    margin: 0px;
    }


button.btn-of-drk-back {
    height: 6vh;
    width: 100%;
    background: #125ef6;
    border: 0px;
    border-radius: 5px;
    color: white;
}

.con-of-dt-sel-ele {
    height: 80vh;
    width: 100%;
    overflow: scroll;
    }

    .container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 15px;
}
a.com-for-lnk {
    text-decoration: none;
    color: black;
    }

    h2.head-od-dt-shw {
    margin: 0px;
    font-family: lato;
    font-size: 15px;
    font-weight: bolder;
}
.con-of-main-splt {
    width: 20%;
    height: 100vh;
    background: #e5eafc30;
    }


    .eml-add-main-con {
    width: 29%;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    font-size: 16px;
    
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }
    input.srch-ip-fld {
    width: 100%;
    height: 3vh;
    border: none;
    font-family: 'Lato';
    font-weight: 500;
    color: #c7ccd7;
}
.con-of-full-email-dt {
    width: 100%;
    height: 90vh;
    }

    .img-eml-ico-con {
    font-family: 'Lato';
    padding: 15px;
    border-radius: 50%;
    background: pink;
    margin-right: 10px;
    color: #ca1938;
}
.sub-ln-of-email-txt {
    width: 240px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-family: 'Lato';
    color: #908c8c;
    font-size: 13px;
}
input.srch-ip-fld:focus{
    outline: none;
    border: none;
}

    .fnt-ico-sel {
    width: 20px;
    text-align: center;
}

.con-of-cht-usr {
    width: 50%;
    display: inline-block;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    border-left: 1px solid #f2f2f2;
    }





.con-ico:hover{
    cursor: pointer;
}

.head-of-dash{
    background: #4a154b;
    text-align: right;
    border-bottom-left-radius: 50px;
}


.dropdown-menu .dropdown-item {
    padding: .5rem 1rem;
    font-size: 13px;
    font-weight: 600;
}

button.dropdown-item.comm_up_btn:hover {
    background: #0d66d6;
    color: white;
    }

    .dropdown-header {
    padding: .5rem 1rem;
    color: #f6f9fc;
    font-size: .625rem;
    text-transform: uppercase;
    font-weight: 700;
}
.dropdown-header {
    display: block;
    padding: .5rem 1rem;
    margin-bottom: 0;
    font-size: 0.875rem;
    color: #8898aa;
    white-space: nowrap;
    }
    .dropdown-menu {
    padding: 10px !important;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px !important;
}

.dropdown-item {
    border-radius: 10px;
    }

h6, .h6 {
    font-size: 0.625rem !important;
}


.head-of-inn-con {
    padding: 24px;
}
.all-auta-con {
    padding: 0px 24px;
    }
    span.nm-auta-con {
    font-size: 16px;
    font-weight: 500;
    font-family: 'lato';
    color: #00000080;
}

.crt-new-auta-con {
    width: 200px;
    background: rgb(143 4 175);
    padding: 24px 16px;
    border-radius: 10px;
    height: 200px;
    margin-right: 30px;
    margin-top: 20px;
   
    margin-left: 20px;
}

    .new-crt-head {
    line-height: 28px;
    font-weight: 700;
    color: white;
    font-family: 'Lato';
}
.con-of-crt-new-img {
    text-align: center;
    width: min-content;
    margin-top: 60px;
    padding: 10px;
    margin-left: auto;
    margin-right: auto;
    border-radius: 50%;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
    }

    .crt-new-auta-con:hover{
cursor: pointer;
    }

   .auta-dis-on-dash {
    width: 200px;
    padding: 24px 16px;
    border-radius: 10px;
    background: white;
    margin-right: 30px;
    height: 200px;
    padding-bottom: 0px;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px;
    
    margin-top: 20px;
   margin-left: 20px;    
}

.auta-dis-on-dash:hover{
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
cursor: pointer;

}
.main-con-name {
    flex: auto;
    min-height: 116px;
    display: inline-grid;
    width: 100%;
}
    
    span.bdg-tp-btn {
    margin-left: auto;
    font-size: 12px;
    background: rgb(245, 249, 248);
    padding: 2px 10px;
    border-radius: 10px;
    color: rgb(2, 80, 65);
    font-family: 'Lato';
    font-weight: 600;
    letter-spacing: .4px;
    height: fit-content;
}
.def-name-con-crd {
    display: inline-flex;

}
.ico-of-act-lst {
    width: 40%;
    margin: auto;
    text-align: center;
    padding: 10px;
    width: fit-content;
    border-radius: 10px;
    background: #f2f2f2;
    transition:.4s;
    }

    img.ico-img-src {
    height: 25px;
}
    .def_stat-of-dt {
    padding: 16px 0px;
    display: inline-flex;
    width: 100%;
    height: 60px;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    
}
    .con-of-cnt-data {
    padding: 5.5px 10px;
    background: rgba(0, 0, 0, 0.07);
    border-radius: 5px;
    color: rgb(38, 38, 39);
    width: 60%;
    text-align: center;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    }

    .con-of-dp-data {
    width: 40%;
}

button#dropdownMenuButton {
    background: no-repeat;
    border: none;
    height: 32px;
    padding: 5.5px;
    float: right;
    }

.all-auta-con {
    padding: 0px 24px;
    display: inline-flex;

}
.dropdown-toggle::after{
    display: none;
}

.dropdown-menu.show{
    border: none;
    border-radius: 10px;
}

a.com-for-lnk {
    text-decoration: none;
    color: #00000091;
    }
    .marg-for-temp{
        margin-left: 0px;
        margin-right: 30px;
    }
    .img-temp-of-mark{
        width: 168px;
        height: 166px;
    }



.btn:hover{

box-shadow: none !important;

}






  .ip-by-def-dsg {
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;


  }


.get_val_data.ip-by-def-dsg{
  width: 200px;
  height: 40px;
}
  .ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #524d52;
    box-shadow: 0 0 0 3px #bdb2bd4d;

    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;

  }

.mrg-tag-sty {
    font-weight: 700;
    width: fit-content;
    height: fit-content;
    padding: 5px 10px;
    background: #130b794f;
    color: #130b79;
    border-radius: 10px;
    border: 2px solid #130b79;
    font-size: 12px;
  }


button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

.btn-blck-in-auta-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(38, 38, 39);
    color: rgb(255, 255, 255);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
    font-family: 'lato';
}

.btn-blck-in-auta-fcs:hover{
    background-color: rgb(71, 71, 71);
    transition: all 0.2s ease 0s;
}

.btn-blck-non-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(227, 227, 227);
    color: rgb(38, 38, 39);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
}

.btn-blck-non-fcs:hover{
    background-color: rgb(231, 231, 231);
    transition: all 0.2s ease 0s;
    color: black;
}

.modal-content{
    border-radius: 8px;
}

.btn-blck-non-fcs:focus{
    color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;
}
.btn-blck-non-fcs:active{

color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;

}


.con-of-temp-lst {
    display: inline-flex;
    width: 100%;
    padding: 5px 10px;
    border-radius: 10px;
    margin-bottom: 10px;
    }

    .con-of-temp-lst:hover {
    background: #f2f2f28a;
    cursor: pointer;
}

.con-of-temp-lst>div {
    width: 50%;
    }

    span.temp-name {
    font-size: 14px;
}

span.crt-data-of-tmp {
    font-size: 10px;
    }
.row{
    margin-left: 0px;
    margin-right: 0px;
}








.btn-primary.focus, .btn-primary:focus{

    color: #fff;
    box-shadow: 0 0 0 0.2rem rgb(105 109 113 / 50%);
    background-color: rgb(38, 38, 39);
    border-color: rgb(38, 38, 39);

}





.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000e8;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
    z-index: 100000000;
}

#cncl-err-msg:hover{


cursor: pointer;


}



.vert-cent-div {
 
  height: min-content;
  text-align: center;
  
  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
    
  margin: auto;
}

.switch-dis{
    display: none;
}






button:disabled,
button[disabled]{
  
  background-color: #cccccc !important;
  color: #666666 !important;
  border: none;
  cursor: not-allowed;
}



.data-head-of-img-fold {
    margin-top: 20px;
    display: inline-flex;
    width: 100%;
    margin-bottom: 20px;
    }

    .main-con-of-img-con {
    width: 100%;
    height: calc(100vh - 8vh - 76px);
    overflow: scroll;
    padding: 30px;
}

.back-btn-to-fold {
    padding: 10px;
    background: #ff008a;
    border-radius: 100px;
    font-size: 12px;
    color: white;
    font-weight: 700;
    margin-left: auto;
    margin-right: auto;
    }

    .con-of-srch-img {
    width: 50%;
}

.con-of-act-img {
    display: inline-flex;
    width: 30%;
    }

    .back-btn-to-fold.color-of-opt-btn {
    padding: 6px;
    background: #c3c2c2;
    border: 0px;
    transition: .4s;
}

.auta-dis-on-dash.img-con-of-fold {
    position: relative;
    padding: 0px;
    border-radius: 0px;
    display: flex;
    justify-content: center;
    margin-right: auto;
    margin-left: 20px;
}
   img.img-tag-for-con {
    width: auto;
    height: auto;
    position: absolute;
    top: 0;
    bottom: 0;
    max-height: 100%;
    max-width: 100%;
    margin: auto;
}

.back-btn-to-fold.color-of-opt-btn:hover {
    cursor: pointer;
    background: #c3c2c28f;
    }
    button.back-btn-to-fold.color-of-opt-btn:focus {
    outline: none;
}

.main-con-of-img-con{
    display: inline-flex;
}

.btn-mdl-act-sel {
    border-radius: 100px !important;
    color: black;
    font-weight: 500;
    font-size: 12px;
    margin-top: 20px;
    text-align: left;
    width: fit-content;
    }

    .btn-mdl-act-sel.active >svg {
    fill: white;
}

.btn-mdl-act-sel >svg {
    fill: black;
    }

    .btn-mdl-act-sel>svg{
        margin-right: 10px;
    }

    .btn-mdl-act-sel:hover svg{
        fill:blue;
    }

    .btn-mdl-act-sel.active:hover svg{
        fill:white;
    }

    .midd-sel-img {
    padding: 40px;
    border: 1px dashed;
    width: fit-content;
    padding: 40px;
    height: 100px;
    
    border-radius: 10px;

}

.midd-sel-img:hover{
    cursor: pointer;
}

img.img-pre-tg-img {
    width: 100%;
    height: auto;
    max-height: 100px;
    border-radius: 10px;

    }

    .img-con-pre {
    width: 98px;
    margin-right: 0px;
    height: 100px;
    position: relative;
    margin-right: 10px;
    margin-top: 10px;
}

#upload_img_form{
    display: inline-flex;
}

.con-of-all-srch {
    width: 600px;
    }

    .con-of-srch-img-thumb {
    border-top-right-radius: 10px;
}

img.img-of-con-srch {
    height: 200px;
    max-width: 250px;
    }

    .btn-con-of-dwn {
    padding: 10px;
    text-align: center;
}

    .full-swn-btn {
    width: fit-content;
    margin-right: 10px;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    margin-top: 10px;
    padding: 0px;
    border-radius: 10px;
}

.active_img_act {
    border: 3px solid blue;
    box-shadow: rgb(0 0 0 / 25%) 0px 14px 28px, rgb(0 0 0 / 22%) 0px 10px 10px;
    }

button.close {
    background: no-repeat;
    border: none;
    }


    th {
    font-weight: 600;
    font-size: 13px;
}

td {
    font-size: 12px;
    }


    .cp-round:after{
        border-top: solid 3px #564f4e;


    }
.img_editor-con{
    display: none;
}

    .tui-image-editor-header{
        display: none;
    }

    #tui-image-editor-container {
    width: 100% !important;
    height: calc(100vh - 52px) !important;
    top: 0px;
    position: fixed;
}
th {
    font-size: 14px !important;
    font-weight: 400 !important;
    padding: 15px !important;
    border-bottom: 1px solid rgba(0, 0, 0, 0.07) !important;
    color: rgb(120 120 150) !important;
    font-family: 'Lato' !important;
    }

.save-fl-bar-con {
    width: 100%;
    height: 52px;
    background: #171717;
    margin-top: calc(100vh - 52px) !important;
    padding: 10px;
    text-align: right;
    }

    .ico-of-act-lst:hover{
        background:black !important;
    }

    table#data-tbl-name {
    width: 80%;
    margin: auto;
    background-color: rgb(255, 255, 255);
    border-radius: 8px;
    box-shadow: rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 8%) 0px 2px 4px;
}

th {
    font-size: 14px;
    font-weight: 400;
    padding: 15px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.07);
    color: rgb(120 120 150);
    font-family: 'Lato';
    }

    td {
    padding: 20px 30px !important;
    font-size: 13px !important;
    border-bottom: 1px solid rgba(0, 0, 0, 0.07) !important;
}


span.badge.badge-primary.bdg-in-tbl {
    font-size: 12px;
    background: #66339914;
    border: 1px solid #663399f7;
    border-radius: 50px;
    color: #370d61;
    font-weight: 400;
    font-family: 'Lato';
    letter-spacing: 1px;
}

button.btn-con-main-txt-ico {
    background: no-repeat;
    border: none;
    width: 54px;
    height: 54px;
    padding: 0px;
    border-radius: 50%;
    transition: .2s;
    margin-right: 10px;
    }

    button.btn-con-main-txt-ico:hover {
    background: #00008b26;
}
span.txt-of-btn {
    font-size: 10px;
    }

    .crt_tag_con {
    margin-top: 20px;
    color: black;
    font-weight: 500;
    font-family: 'Lato';
}

.btn_con_of_db {
    text-align: right;
    }

    .btn-act-of-upp {
    width: 80%;
    margin: auto;
    padding: 30px 0px;
}





















.select-wrapper {
        margin: auto;
        max-width: 600px;
        width: calc(100% - 40px);
      }

      .select-pure__select {
        align-items: center;
        background: white;
margin:10px;      
  border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: none;
        box-sizing: border-box;
        color: #363b3e;
        cursor: pointer;
        display: flex;
        font-size: 16px;
        font-weight: 500;
        justify-content: left;
        min-height: 44px;
        padding: 5px 10px;
        position: relative;
        transition: 0.2s;
        width: 300px;
      }

      .select-pure__options {
        border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: #363b3e;
        display: none;
        left: 0;
        max-height: 220px;
        overflow-y: scroll;
        position: absolute;
        top: 50px;
        width: 100%;
        z-index: 5;
      }

      .select-pure__select--opened .select-pure__options {
        display: block;
      }

      .select-pure__option {
        background: #fff;
        border-bottom: 1px solid #e4e4e4;
        box-sizing: border-box;
        height: 44px;
        line-height: 25px;
        padding: 10px;
      }

      .select-pure__option--selected {
        color: #e4e4e4;
        cursor: initial;
        pointer-events: none;
      }

      .select-pure__option--hidden {
        display: none;
      }

      .select-pure__selected-label {

  align-items: 'center';
       
  border-radius: 4px;
font-size:13px;
        color: #5a2977;
    background: rgba(90, 41, 119, 0.11);
        cursor: initial;
        display: inline-flex;
        justify-content: 'center';
        margin: 5px 10px 5px 0;
        padding: 3px 7px;
      }

      .select-pure__selected-label:last-of-type {
        margin-right: 0;
      }

      .select-pure__selected-label i {
        cursor: pointer;
        display: inline-block;
        margin-left: 7px;
      }

      .select-pure__selected-label img {
        cursor: pointer;
        display: inline-block;
        height: 18px;
        margin-left: 7px;
        width: 14px;
      }

      .select-pure__selected-label i:hover {
        color: black;
      }

      .select-pure__autocomplete {
        background: #f9f9f8;
        border-bottom: 1px solid #e4e4e4;
        border-left: none;
        border-right: none;
        border-top: none;
        box-sizing: border-box;
        font-size: 16px;
        outline: none;
        padding: 10px;
        width: 100%;
      }

      .select-pure__placeholder--hidden {
        display: none;
      }







.ip_fl_con {
    padding: 10px;
}



span.find_lst_cnt {
    padding: 10px;
    background: green;
    color: white;
    font-weight: 600;
    border-radius: 20px;
    font-size: 10px;
}

.btn_end_con {
    width: 80%;
    margin: auto;
    padding: 20px 0px;
  }


input#chooseFile {
    margin-bottom: 20px;
}
</style>
</head>
<body>



<div class="vert-cent-div err-menu-cls-dsg" id="err_msg_dt_trg" style="display: none;">
<span id="con-of-err-msg"></span>
<span class="cls-err-menu" id="cncl-err-msg">
<i class="fal fa-times-circle" style="
    padding: 6px;
"></i>
</span>
</div>

<div class="main-con-of-dash">


 
 <?php require("../confige/header/theme-2.0-side.php");?>
    <div class="main-con-of-crm dsc-inln-flx">
         <?php    require("../confige/header/header-new.php");?>


<?php require("../ajaxfile/phpfile/top_of_mngc_2.php");?>

       
    

<div id="main-loader-containre">




<div class='form_sub_data ' style='padding-top:30px;'>






<table class="table" id='data-tbl-name'>
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Field name</th>
      <th scope="col">Type</th>
      <th scope="col">Merge Tag</th>
      <th scope="col"></th>
    </tr>
  </thead>

<tbody>
   



<?php



for($i=0;$i<count($get_col);$i++){


$get_col_query="SELECT DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = '".$lst_name."' AND COLUMN_NAME = '".$get_col[$i]."'";
$query = $conn3->query($get_col_query);


       $dt_of_colm=$query->fetch_assoc();

if($i!=0){
$org_ip_dt=get_mysql_to_ip($dt_of_colm['DATA_TYPE']);
}else{
$org_ip_dt='email';
}
    
?>

 <tr>
      <th scope="row"><?php echo $i;?></th>
      <td><input  class='get_val_data ip-by-def-dsg' id='<?php echo $get_col[$i];?>' type='text' value='<?php echo $get_col[$i];?>' <?php  if($org_ip_dt=="email"){echo "disabled";}?>/>   </td>
      <td id='<?php echo $get_col[$i];?>dt_tp'><?php  if($org_ip_dt!=="email"){ echo  '<select id="stat_of_tp" class="ip-by-def-dsg" value="int" style="max-width: 100px;width:100%;height: 40px;margin: 0px;"><option value="text" selected="">text</option><option value="date">date</option><option value="int">int</option></select>';}else{echo "<select id='stat_of_tp' class='ip-by-def-dsg' style='max-width: 100px;width:100%;height: 40px;margin: 0px;'><option value='emai'>email</option></select>";}?></td>
      <td><div class="mrg-tag-sty">:<?php echo $get_col[$i];?>:</div></td>
       <td class=''><div class='dlt_trg_icn' id='<?php echo $get_col[$i];?>' data-toggle="modal" data-target="#mdl_del_fld"><i class="far fa-trash-alt"></i></div></td>
    </tr>
<?php





}





?>


</tbody>
</table>

<div class='btn_end_con' style="margin-bottom:20px;">

 <button class="btn_of_act sb_frm_dt" id="sub_comp_data" type="submit" style="float: none;background: ##1b4e07;">Save Changes <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-save2" viewBox="0 0 16 16" style="
    margin-left: 10px;
">
  <path d="M2 1a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H9.5a1 1 0 0 0-1 1v4.5h2a.5.5 0 0 1 .354.854l-2.5 2.5a.5.5 0 0 1-.708 0l-2.5-2.5A.5.5 0 0 1 5.5 6.5h2V2a2 2 0 0 1 2-2H14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h2.5a.5.5 0 0 1 0 1H2z"></path>
</svg></button>



<button class="btn_of_act crt_new_fld_mdl"   data-toggle="modal" data-target="#crt_new_fld_in_tbl"style="float: none;background: #0e4167;">Add Fields<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-square-dotted" viewBox="0 0 16 16" style="
    margin-left: 10px;
">
  <path d="M2.5 0c-.166 0-.33.016-.487.048l.194.98A1.51 1.51 0 0 1 2.5 1h.458V0H2.5zm2.292 0h-.917v1h.917V0zm1.833 0h-.917v1h.917V0zm1.833 0h-.916v1h.916V0zm1.834 0h-.917v1h.917V0zm1.833 0h-.917v1h.917V0zM13.5 0h-.458v1h.458c.1 0 .199.01.293.029l.194-.981A2.51 2.51 0 0 0 13.5 0zm2.079 1.11a2.511 2.511 0 0 0-.69-.689l-.556.831c.164.11.305.251.415.415l.83-.556zM1.11.421a2.511 2.511 0 0 0-.689.69l.831.556c.11-.164.251-.305.415-.415L1.11.422zM16 2.5c0-.166-.016-.33-.048-.487l-.98.194c.018.094.028.192.028.293v.458h1V2.5zM.048 2.013A2.51 2.51 0 0 0 0 2.5v.458h1V2.5c0-.1.01-.199.029-.293l-.981-.194zM0 3.875v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zM0 5.708v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zM0 7.542v.916h1v-.916H0zm15 .916h1v-.916h-1v.916zM0 9.375v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zm-16 .916v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zm-16 .917v.458c0 .166.016.33.048.487l.98-.194A1.51 1.51 0 0 1 1 13.5v-.458H0zm16 .458v-.458h-1v.458c0 .1-.01.199-.029.293l.981.194c.032-.158.048-.32.048-.487zM.421 14.89c.183.272.417.506.69.689l.556-.831a1.51 1.51 0 0 1-.415-.415l-.83.556zm14.469.689c.272-.183.506-.417.689-.69l-.831-.556c-.11.164-.251.305-.415.415l.556.83zm-12.877.373c.158.032.32.048.487.048h.458v-1H2.5c-.1 0-.199-.01-.293-.029l-.194.981zM13.5 16c.166 0 .33-.016.487-.048l-.194-.98A1.51 1.51 0 0 1 13.5 15h-.458v1h.458zm-9.625 0h.917v-1h-.917v1zm1.833 0h.917v-1h-.917v1zm1.834-1v1h.916v-1h-.916zm1.833 1h.917v-1h-.917v1zm1.833 0h.917v-1h-.917v1zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z"></path>
</svg></button>


</div>
</div>


</div>


</div>


</div>







<div class="modal" id="mdl_del_fld" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Delete Fields</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="del_val_ip" placeholder="Enter DELETE And Click">
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="del_fld_fin">Delete Fields</button>
      </div>
    </div>
  </div>
</div>










<div class="modal" id='crt_new_fld_in_tbl' tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Delete Tag</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
   <div class="btn-con-del-camp" style="
    width: 100%;
">

   <input class="ip-by-def-dsg" id="fld_name" name="nameofnewlist" type="text" style="max-width:100%;" required="">
    
   <div class='' id='new_fld_tp'>

<?php
echo get_str_of_opt("all");

?>


</div>
    
</div>
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="sb_frm_nw_fld">Create Field</button>
      </div>
    </div>
  </div>
</div>








</body>

<script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>


<script>





























$(document).on("click",".sb_frm_dt",function(){


append_load_in_all_btn(".sb_frm_dt");

  arr_of_json_obj=[];

$(".get_val_data").map(function(){

name_ext_val=$(this).attr("id");

new_name_val=$(this).val();
console.log(new_name_val);
get_tp_of_col=$("#"+name_ext_val+"dt_tp").children("#stat_of_tp").val();
loc_arr=[];

loc_arr[0]=name_ext_val;
loc_arr[1]=new_name_val;
loc_arr[2]=get_tp_of_col;

arr_of_json_obj.push(loc_arr);


});




myDataObject = new Object;
  myDataObject.Vehicles =arr_of_json_obj;;
  
str_json_dt= JSON.stringify(myDataObject);





$.ajax({
  type: "POST",
      
      url: "./ajaxfile/sb_frm_of_alter_col.php",
      data:{json_str:str_json_dt}
}).done(function(response1) {

append_txt_of_lds(".sb_frm_dt");

});

})

























function array1dToJson(a, p) {
      var i, s = '';
      for (i = 0; i < a.length; ++i) {
        if (typeof a[i] == 'string') {
          s += '"' + a[i] + '"';
        }
        else { // assume number type
          s += a[i];
        }
        if (i < a.length - 1) {
          s += ':';
        }
      }
      s += '';
      if (p) {
        return '{"' + p + '":' + s + '}';
      }
      return s;
    }












function array2dToJson(a, p, nl) {
      var i, j, s = '[{"' + p + '":{';
      nl = nl || '';
      for (i = 0; i < a.length; ++i) {
        s += nl + array1dToJson(a[i]);
        if (i < a.length - 1) {
          s += ',';
        }
      }
      s += nl + '}}]';
      return s;
    }







function modalEvent(button) {

  
    const trigger = button.getAttribute('data-modal-trigger');
    const modal = document.querySelector(`[data-modal=${trigger}]`);
   
    
    
    
    

    modal.classList.toggle('open');
  
  
}



$(document).on('click',".del_mdl_cls",function(){


tp_of_mdl=$(this).attr("mdl-cls-tp");

$("#"+tp_of_mdl).removeClass("open");


})






del_fld='';


$(document).on("click",".dlt_trg_icn",function(){
del_fld=$(this).attr("id");



});

$(document).on("click","#del_fld_fin",function(){


del_val=$("#del_val_ip").val();

console.log(del_fld=="email");

if(del_fld!="email"){



if(del_val=="DELETE"){


  append_load_in_all_btn("#del_fld_fin");


$.ajax({
  type: "POST",
  url: "./ajaxfile/del_fld.php",
  data: {fld_old_name:del_fld}
}).done(function(response1) {

        if(response1==1){
location.reload();

        }else{

  append_txt_of_lds("#del_fld_fin");

        }



});

}else{

  err_msg_data("Please Enter DELETE Excatly");
}
 
}else{


	err_msg_data("You Can Not Able To Delete");

}
});
















$(document).on("click","#sb_frm_nw_fld",function(){
 


append_load_in_all_btn("#sb_frm_nw_fld");

var fld_new_name=$("#fld_name").val();

var fld_new_tp=$("#new_fld_tp").children("#stat_of_tp").val();




$.ajax({
  type: "POST",
      
      url: "./ajaxfile/sb_frm_new_fld.php",
      data:{fld_name:fld_new_name,fld_tp:fld_new_tp}
}).done(function(response1) {


console.log(response1); 

append_txt_of_lds("#sb_frm_nw_fld");

   if(response1==1){
location.reload();

        }
});





});

append_txt_that_get_clck="";


function append_load_in_all_btn(selector){




append_txt_that_get_clck=$(selector).html();

$(selector).prop("disabled",true);

$(selector).html('<div class="cp-spinner cp-round"></div>');

}



function append_txt_of_lds(selector){

$(selector).prop("disabled",false);

$(selector).html(append_txt_that_get_clck);


}


err_msg_data("Welcome To Studio");


function err_msg_data(message){


$("#con-of-err-msg").html(message);

$("#err_msg_dt_trg").css('display','inline-block');



setTimeout(
    function() {


      $("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');
      
    }, 5000);


}


$(document).on('click','#cncl-err-msg',function(){


$("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

})




</script>


</html>


       

