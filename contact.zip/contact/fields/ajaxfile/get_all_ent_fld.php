<?php


function get_email_col($list_id){

require("../../confige/fileconfige.php");

        $get_col_query="SELECT `COLUMN_NAME`  FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='list_contacts' AND `TABLE_NAME`='".$list_id."' ORDER BY ordinal_position";

        $query = $conn3->query($get_col_query);

$ret_arr=array();

while($row = $query->fetch_assoc()){

	if($row['COLUMN_NAME']=="tag"){

return $ret_arr;
	}else{

		array_push($ret_arr,$row['COLUMN_NAME']);
	}
}

// Array of all column nam


}



print_r(json_encode(get_email_col($_GET['list_name'])));



?> 
