
<div class="modal fade" id="crt_new_fld" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" style='max-width:70%;' role="document">
    <div class="modal-content" style='height:600px;'>
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Create New Fields</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body">

<div style='width:100%;text-align:center;'>
<img src='https://res.cloudinary.com/heptera/image/upload/v1584210630/prototype_awfdzj.png' height='64'/>
<div class='modal-text' style='text-align:left'>
<h2 style='color:black;font-size:20px;letter-spacing:0.8px'>Create new Fields in <div id='tbl_name_def'></div></h2>
<p>Enter Unique Field name that Not Present in Table at this time</p>
<div style='padding:20px;'>

<label style='font-weight:450;color:black;letter-spacing:0.6px;'>New Field</label>
        <input class='modal-input' id="fld_name" name='' type='text' style='padding-left:10px;height:40px;width:100%;border:1px solid rgba(36,28,21,0.3);' required/>


<div class='' id='new_fld_tp'>

<?php
echo get_str_of_opt("all");

?>


</div>
<div style='color:red;font-weight:500;' class='res'></div>

          
         
<div style='padding-top:40px;text-align:center'>
<button class='bottom-btn' id='sb_frm_nw_fld'  type="submit" class="btn btn-primary"><div class="row"><div class="lds-ring" style='display:none' id='sb_fr_nw_fld'><div></div><div></div><div></div><div></div></div><div><div style="margin:0px 10px;">Create Field</div></div></div></button>
</div>       

</div>
</div>
</div> 
    
  </div>
    
    </div>
  </div>
</div>

<script>


$(document).on("click","#sb_frm_nw_fld",function(){
console.log("ravi");	
$("#sb_fr_nw_fld").css("display","inline-block")
var fld_new_name=$("#fld_name").val();

var fld_new_tp=$("#new_fld_tp").children("#stat_of_tp").val();




$.ajax({
  type: "POST",
      
      url: "./ajaxfile/sb_frm_new_fld.php",
      data:{fld_name:fld_new_name,fld_tp:fld_new_tp}
}).done(function(response1) {
	$("#sb_fr_nw_fld").css("display","none");
	 if(response1==1){
location.reload();

        }
});





});

</script>
