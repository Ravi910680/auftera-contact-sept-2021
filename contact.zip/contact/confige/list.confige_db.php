<?php



function create_db($conn,$db_name){




$sql = "CREATE DATABASE ".$db_name;
if ($conn->query($sql) === TRUE) {

echo "create db ".$db_name;

}




}



function create_tbl_in_db($conn,$sql){



if($conn->query($sql)==TRUE){

echo "create Table ";

}




}

$servername = "database-1.ckv23lvefwmm.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";





$account_conn = mysqli_connect($servername, $username, $password);




create_db($account_conn,"list_details");
create_db($account_conn,"list_contacts");

create_db($account_conn,"camp_analysis");







$sign_up_conn = mysqli_connect($servername, $username, $password,"list_details");


$sql_query="CREATE TABLE `data_impo` (
 `list_name` varchar(255) DEFAULT NULL,
 `import_src` varchar(255) DEFAULT NULL,
 `impo_count` int(11) DEFAULT NULL,
 `dt_ts` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1";


create_tbl_in_db($sign_up_conn,$sql_query);

$sql_query="CREATE TABLE `filedetails` (
 `filename` varchar(255) NOT NULL,
 `id` int(6) DEFAULT NULL,
 `extra` int(255) DEFAULT NULL,
 `flagsrc` tinyint(1) DEFAULT NULL,
 PRIMARY KEY (`filename`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";


create_tbl_in_db($sign_up_conn,$sql_query);


$sql_query="CREATE TABLE `segment_data` (
 `id` varchar(255) NOT NULL,
 `list_name` varchar(255) DEFAULT NULL,
 `date` date DEFAULT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";


create_tbl_in_db($sign_up_conn,$sql_query);









?>
