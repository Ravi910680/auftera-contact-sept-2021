<?php
session_start();
require("./../confige/fileconfige.php");

$id=$_SESSION["id"];

$query="SELECT * FROM filedetails WHERE id='$id'";
$result = $conn2->query($query);

if ($result->num_rows > 0) {
    // output data of each row
    ?>
<div style='text-align:left;padding:40px;' class="container">
<table class="table table-padding">
  <thead>
    <tr>
      <th scope="col" style='width:40%;'>list name</th>
      <th scope="col">ACTIVE USER</th>
      <th scope="col">add contact</th>
      <th scope="col">manage contact</th>
      <th scope="col">delet list</th>
      
    </tr>
  </thead>
  <tbody>

    <?php
    while($row = $result->fetch_assoc()) {
        
        
        ?>
        
  
    <tr>
      <td scope="row" class='first-col'><?php echo $row['filename'];?></td>
      <td><?php echo $row["extra"];?></td>

      <td id='<?php echo $row['filename'];?>' class='opt_on_list contact'>Add contact</td>
      <td id='<?php echo $row['filename'];?>' class='opt_on_list managecon'>Manage Contact</td>
      <td id='' class='dltc'>Delet Contact</td>
    </tr>
    
  

<?php
    }
?>
</tbody>
</table>
</div>
<?php
} else {
?>
<style>
.not-f-text{

width: 500px;
    margin: 0px auto;
    padding: 40px;
    font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;
}

.not-f-btn{

background:#0b646d;
border:none;
outline:none;
height:50px;
padding-left:10px;padding-right:10px;
font-weight:700;
color:white;
}
.not-f-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#0e7480;

}


</style>
<div class='not-f-text' >
Nothing in your List directory. if you make clustered list of user please create list.
</div>
<button data-toggle="modal" data-target="#crtlistname" class="not-f-btn" style="background:"><i class="fas fa-plus" style='padding-right:10px;'></i>create list</button>

<?php
}
?>
