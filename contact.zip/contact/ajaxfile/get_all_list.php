<?php

session_start();

$id=$_SESSION['id'];


function select_query($conn,$sel_query){


	$ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    

    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}



require("../confige/fileconfige.php");

$query="SELECT * FROM filedetails WHERE id='$id'";


print_r(json_encode(select_query($conn2,$query)));



    ?>
