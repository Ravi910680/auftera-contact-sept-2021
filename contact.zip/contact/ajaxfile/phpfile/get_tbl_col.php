<?php


require("../../confige/fileconfige.php");



?>
