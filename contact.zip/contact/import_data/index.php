
<?php
session_start();
require("../confige/fileconfige.php");


 $url_main="auftera.com";

$id=$_SESSION['id'];
$email=$_SESSION['email'];
?>






<html><head>




<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1628745601/loader_ww3kdih.css">


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">



<link type="text/css" href="https://uicdn.toast.com/tui-color-picker/v2.2.6/tui-color-picker.css" rel="stylesheet">
        <link rel="stylesheet" href="https://uicdn.toast.com/tui-image-editor/latest/tui-image-editor.css">



<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/fabric.js/3.6.0/fabric.js"></script>
        <script type="text/javascript" src="https://uicdn.toast.com/tui.code-snippet/v1.5.0/tui-code-snippet.min.js"></script>
        <script type="text/javascript" src="https://uicdn.toast.com/tui-color-picker/v2.2.6/tui-color-picker.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/1.3.3/FileSaver.min.js"></script>
        <script src="https://uicdn.toast.com/tui-image-editor/latest/tui-image-editor.js"></script>

<style type="text/css">


.sd-con-ico.dsc-inln-flx {
    width: 8%;
    height: 100%;
}

.tooltip-arrow {
    
    }


[data-popper-placement="right"]>.tooltip-arrow{

transform: none !important;
    top: 8px !important;

}
.main-con-of-crm.dsc-inln-flx {
    width: 92%;
    height: 100%;
    float: right;
    background: #fafafa;
    overflow: scroll;
}

    .dsc-inln-flx {
    display: inline-block;
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

    .icon-con-of-sd {
    height: 90vh;
    width: 100%;
}

.icon-main-con {
    height: auto;
    width: 100%;
    position: relative;
    top: 50%;
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    }

    .con-ico {
    padding: 20px;
    text-align: center;
}

img.con-of-ico-img {
    height: 30px;
    }




.con-of-main-splt {
    width: 20%;
    height: 100vh;
    display: inline-block;

}
.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

   
h2.head-od-dt-shw {
    margin: 0px;
    }


button.btn-of-drk-back {
    height: 6vh;
    width: 100%;
    background: #125ef6;
    border: 0px;
    border-radius: 5px;
    color: white;
}

.con-of-dt-sel-ele {
    height: 80vh;
    width: 100%;
    overflow: scroll;
    }

    .container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 15px;
}
a.com-for-lnk {
    text-decoration: none;
    color: black;
    }

    h2.head-od-dt-shw {
    margin: 0px;
    font-family: lato;
    font-size: 15px;
    font-weight: bolder;
}
.con-of-main-splt {
    width: 20%;
    height: 100vh;
    background: #e5eafc30;
    }


    .eml-add-main-con {
    width: 29%;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    font-size: 16px;
    
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }
    input.srch-ip-fld {
    width: 100%;
    height: 3vh;
    border: none;
    font-family: 'Lato';
    font-weight: 500;
    color: #c7ccd7;
}
.con-of-full-email-dt {
    width: 100%;
    height: 90vh;
    }

    .img-eml-ico-con {
    font-family: 'Lato';
    padding: 15px;
    border-radius: 50%;
    background: pink;
    margin-right: 10px;
    color: #ca1938;
}
.sub-ln-of-email-txt {
    width: 240px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-family: 'Lato';
    color: #908c8c;
    font-size: 13px;
}
input.srch-ip-fld:focus{
    outline: none;
    border: none;
}

    .fnt-ico-sel {
    width: 20px;
    text-align: center;
}

.con-of-cht-usr {
    width: 50%;
    display: inline-block;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    border-left: 1px solid #f2f2f2;
    }





.con-ico:hover{
    cursor: pointer;
}

.head-of-dash{
    background: #4a154b;
    text-align: right;
    border-bottom-left-radius: 50px;
}


.dropdown-menu .dropdown-item {
    padding: .5rem 1rem;
    font-size: 13px;
    font-weight: 600;
}

button.dropdown-item.comm_up_btn:hover {
    background: #0d66d6;
    color: white;
    }

    .dropdown-header {
    padding: .5rem 1rem;
    color: #f6f9fc;
    font-size: .625rem;
    text-transform: uppercase;
    font-weight: 700;
}
.dropdown-header {
    display: block;
    padding: .5rem 1rem;
    margin-bottom: 0;
    font-size: 0.875rem;
    color: #8898aa;
    white-space: nowrap;
    }
    .dropdown-menu {
    padding: 10px !important;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px !important;
}

.dropdown-item {
    border-radius: 10px;
    }

h6, .h6 {
    font-size: 0.625rem !important;
}


.head-of-inn-con {
    padding: 24px;
}
.all-auta-con {
    padding: 0px 24px;
    }
    span.nm-auta-con {
    font-size: 16px;
    font-weight: 500;
    font-family: 'lato';
    color: #00000080;
}

.crt-new-auta-con {
    width: 200px;
    background: rgb(143 4 175);
    padding: 24px 16px;
    border-radius: 10px;
    height: 200px;
    margin-right: 30px;
    margin-top: 20px;
   
    margin-left: 20px;
}

    .new-crt-head {
    line-height: 28px;
    font-weight: 700;
    color: white;
    font-family: 'Lato';
}
.con-of-crt-new-img {
    text-align: center;
    width: min-content;
    margin-top: 60px;
    padding: 10px;
    margin-left: auto;
    margin-right: auto;
    border-radius: 50%;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
    }

    .crt-new-auta-con:hover{
cursor: pointer;
    }

   .auta-dis-on-dash {
    width: 200px;
    padding: 24px 16px;
    border-radius: 10px;
    background: white;
    margin-right: 30px;
    height: 200px;
    padding-bottom: 0px;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px;
    
    margin-top: 20px;
   margin-left: 20px;    
}

.auta-dis-on-dash:hover{
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
cursor: pointer;

}
.main-con-name {
    flex: auto;
    min-height: 116px;
    display: inline-grid;
    width: 100%;
}
    
    span.bdg-tp-btn {
    margin-left: auto;
    font-size: 12px;
    background: rgb(245, 249, 248);
    padding: 2px 10px;
    border-radius: 10px;
    color: rgb(2, 80, 65);
    font-family: 'Lato';
    font-weight: 600;
    letter-spacing: .4px;
    height: fit-content;
}
.def-name-con-crd {
    display: inline-flex;

}
.ico-of-act-lst {
    width: 40%;
    margin: auto;
    text-align: center;
    padding: 10px;
    width: fit-content;
    border-radius: 10px;
    background: #f2f2f2;
    transition:.4s;
    }

    img.ico-img-src {
    height: 25px;
}
    .def_stat-of-dt {
    padding: 16px 0px;
    display: inline-flex;
    width: 100%;
    height: 60px;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    
}
    .con-of-cnt-data {
    padding: 5.5px 10px;
    background: rgba(0, 0, 0, 0.07);
    border-radius: 5px;
    color: rgb(38, 38, 39);
    width: 60%;
    text-align: center;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    }

    .con-of-dp-data {
    width: 40%;
}

button#dropdownMenuButton {
    background: no-repeat;
    border: none;
    height: 32px;
    padding: 5.5px;
    float: right;
    }

.all-auta-con {
    padding: 0px 24px;
    display: inline-flex;

}
.dropdown-toggle::after{
    display: none;
}

.dropdown-menu.show{
    border: none;
    border-radius: 10px;
}

a.com-for-lnk {
    text-decoration: none;
    color: #00000091;
    }
    .marg-for-temp{
        margin-left: 0px;
        margin-right: 30px;
    }
    .img-temp-of-mark{
        width: 168px;
        height: 166px;
    }










  .ip-by-def-dsg {
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;


  }

  .ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #524d52;
    box-shadow: 0 0 0 3px #bdb2bd4d;

    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;

  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

.btn-blck-in-auta-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(38, 38, 39);
    color: rgb(255, 255, 255);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
    font-family: 'lato';
}

.btn-blck-in-auta-fcs:hover{
    background-color: rgb(71, 71, 71);
    transition: all 0.2s ease 0s;
}

.btn-blck-non-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(227, 227, 227);
    color: rgb(38, 38, 39);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
}

.btn-blck-non-fcs:hover{
    background-color: rgb(231, 231, 231);
    transition: all 0.2s ease 0s;
    color: black;
}

.modal-content{
    border-radius: 8px;
}

.btn-blck-non-fcs:focus{
    color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;
}
.btn-blck-non-fcs:active{

color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;

}


.con-of-temp-lst {
    display: inline-flex;
    width: 100%;
    padding: 5px 10px;
    border-radius: 10px;
    margin-bottom: 10px;
    }

    .con-of-temp-lst:hover {
    background: #f2f2f28a;
    cursor: pointer;
}

.con-of-temp-lst>div {
    width: 50%;
    }

    span.temp-name {
    font-size: 14px;
}

span.crt-data-of-tmp {
    font-size: 10px;
    }
.row{
    margin-left: 0px;
    margin-right: 0px;
}








.btn-primary.focus, .btn-primary:focus{

    color: #fff;
    box-shadow: 0 0 0 0.2rem rgb(105 109 113 / 50%);
    background-color: rgb(38, 38, 39);
    border-color: rgb(38, 38, 39);

}





.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000e8;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
    z-index: 100000000;
}

#cncl-err-msg:hover{


cursor: pointer;


}



.vert-cent-div {
 
  height: min-content;
  text-align: center;
  
  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
    
  margin: auto;
}

.switch-dis{
    display: none;
}






button:disabled,
button[disabled]{
  
  background-color: #cccccc !important;
  color: #666666 !important;
  border: none;
  cursor: not-allowed;
}



.data-head-of-img-fold {
    margin-top: 20px;
    display: inline-flex;
    width: 100%;
    margin-bottom: 20px;
    }

    .main-con-of-img-con {
    width: 100%;
    height: calc(100vh - 8vh - 76px);
    overflow: scroll;
    padding: 30px;
}

.back-btn-to-fold {
    padding: 10px;
    background: #ff008a;
    border-radius: 100px;
    font-size: 12px;
    color: white;
    font-weight: 700;
    margin-left: auto;
    margin-right: auto;
    }

    .con-of-srch-img {
    width: 50%;
}

.con-of-act-img {
    display: inline-flex;
    width: 30%;
    }

    .back-btn-to-fold.color-of-opt-btn {
    padding: 6px;
    background: #c3c2c2;
    border: 0px;
    transition: .4s;
}

.auta-dis-on-dash.img-con-of-fold {
    position: relative;
    padding: 0px;
    border-radius: 0px;
    display: flex;
    justify-content: center;
    margin-right: auto;
    margin-left: 20px;
}
   img.img-tag-for-con {
    width: auto;
    height: auto;
    position: absolute;
    top: 0;
    bottom: 0;
    max-height: 100%;
    max-width: 100%;
    margin: auto;
}

.back-btn-to-fold.color-of-opt-btn:hover {
    cursor: pointer;
    background: #c3c2c28f;
    }
    button.back-btn-to-fold.color-of-opt-btn:focus {
    outline: none;
}

.main-con-of-img-con{
    display: inline-flex;
}

.btn-mdl-act-sel {
    border-radius: 100px !important;
    color: black;
    font-weight: 500;
    font-size: 12px;
    margin-top: 20px;
    text-align: left;
    width: fit-content;
    }

    .btn-mdl-act-sel.active >svg {
    fill: white;
}

.btn-mdl-act-sel >svg {
    fill: black;
    }

    .btn-mdl-act-sel>svg{
        margin-right: 10px;
    }

    .btn-mdl-act-sel:hover svg{
        fill:blue;
    }

    .btn-mdl-act-sel.active:hover svg{
        fill:white;
    }

    .midd-sel-img {
    padding: 40px;
    border: 1px dashed;
    width: fit-content;
    padding: 40px;
    height: 100px;
    
    border-radius: 10px;

}

.midd-sel-img:hover{
    cursor: pointer;
}

img.img-pre-tg-img {
    width: 100%;
    height: auto;
    max-height: 100px;
    border-radius: 10px;

    }

    .img-con-pre {
    width: 98px;
    margin-right: 0px;
    height: 100px;
    position: relative;
    margin-right: 10px;
    margin-top: 10px;
}

#upload_img_form{
    display: inline-flex;
}

.con-of-all-srch {
    width: 600px;
    }

    .con-of-srch-img-thumb {
    border-top-right-radius: 10px;
}

img.img-of-con-srch {
    height: 200px;
    max-width: 250px;
    }

    .btn-con-of-dwn {
    padding: 10px;
    text-align: center;
}

    .full-swn-btn {
    width: fit-content;
    margin-right: 10px;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    margin-top: 10px;
    padding: 0px;
    border-radius: 10px;
}

.active_img_act {
    border: 3px solid blue;
    box-shadow: rgb(0 0 0 / 25%) 0px 14px 28px, rgb(0 0 0 / 22%) 0px 10px 10px;
    }

button.close {
    background: no-repeat;
    border: none;
    }


    th {
    font-weight: 600;
    font-size: 13px;
}

td {
    font-size: 12px;
    }


    .cp-round:after{
        border-top: solid 3px #564f4e;


    }
.img_editor-con{
    display: none;
}

    .tui-image-editor-header{
        display: none;
    }

    #tui-image-editor-container {
    width: 100% !important;
    height: calc(100vh - 52px) !important;
    top: 0px;
    position: fixed;
}

.save-fl-bar-con {
    width: 100%;
    height: 52px;
    background: #171717;
    margin-top: calc(100vh - 52px) !important;
    padding: 10px;
    text-align: right;
    }

    .ico-of-act-lst:hover{
        background:black !important;
    }

    .not-fd-data{
  text-align: center;
padding: 40px;
    background: white;
    border-radius: 4px;

}




.txt-not-fd{
  padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
}

body{

}
.bottom-btn{
  text-align: center;
    height: 40px;
 background: #dea77f47;
    color: #e83105b0;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;

    padding-left: 20px;
    padding-right: 20px;
}
.bottom-btn:hover{
  cursor: pointer;
}

.name_con{
width:70%;
}
.chk_con{
width: 10%;
}
.table th, .table td{
border-top:none;
}

span.badge {
    font-size: 10px;
}







button.btn_hover_clr {
   

        background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    color: #1a73e8;
    font-size: 13px;
    font-weight: 500;
    background: white;
  }

  

button.btn_hover_clr:hover {
    background: #e8f0fe;
    cursor: pointer;
  }

a.hr-tag-con {
    color: #4a154b;
    font-size: 15px;
  }

  .main-con {
    padding: 20px 0px 70px 0px;
  }


.cnt-add-email-data{
  text-align: right;
}

span.badge.badge-primary {
    background: #0b5f22;
    font-size: 12px;
    padding: 5px 10px;
  }

  span.badge.badge-pill.badge-success {
    background: #870e88;
    font-size: 12px;
    padding: 10px;
    border-radius: 40px;
  }


table#data-tbl-name {
    width: 80%;
    margin: auto;
    background-color: rgb(255, 255, 255);
    border-radius: 8px;
    box-shadow: rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 8%) 0px 2px 4px;
}

th {
    font-size: 14px;
    font-weight: 400;
    padding: 15px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.07);
    color: rgb(120 120 150);
    font-family: 'Lato';
    }

    td {
    padding: 20px 30px;
    font-size: 13px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.07);
}

</style>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

<body style="
    margin: 0px;
">





<div class="vert-cent-div err-menu-cls-dsg" id="err_msg_dt_trg" style="display: none;">
<span id="con-of-err-msg"></span>
<span class="cls-err-menu" id="cncl-err-msg">
<i class="fal fa-times-circle" style="
    padding: 6px;
"></i>
</span>
</div>


<div class="main-con-of-dash">

    
    
     <?php require("../confige/header/theme-2.0-side.php");?>
    <div class="main-con-of-crm dsc-inln-flx">
         <?php    require("../confige/header/header-new.php");?>

     

<?php require("../ajaxfile/phpfile/top_of_mngc_2.php");?>

       
    
 <div class="main-auta-con" id='main-loader-containre'>
    
<div class="switch-dis" id='fold-cnt-con' style='display:block;'>

    <div class="head-of-inn-con">
        <span class="nm-auta-con">Import History</span>
    
    </div>





    

    <table id="data-tbl-name">
 <tbody><tr>
    <th>

    


</th><th>Contact Source</th><th>Number Of Contact</th>
    
    <th>


   

</th>
  </tr>

   </tbody><tbody id="app_of_impo_data"><tr> <td><span class="icon-of-tbl"><div class="cp-spinner cp-round"></div></span></td> <td></td>  </tr></tbody></table>


</div>



    
    
</div>




 












    
    </div>




   


</div>






</body></html>






<script type="text/javascript">

id='<?php echo $id;?>';

url_main='<?php echo $url_main;?>';







function init_str_of_impo (arr_dt) {
  
  if(arr_dt['impo_count']==0){

  }else{


  }



  return '<tr> <td class="btn_con_tag"> <img height="40" src="https://image.flaticon.com/icons/png/512/758/758930.png"> </td> <td class="name_con"><span class="badge badge-primary">'+arr_dt['import_src']+'</span><br><div class="crt_tag_con" style="padding-top:10px;color:black;">Imported '+arr_dt['dt_ts']+'</div> </td> <td class="cnt-add-email-data"> <span class="badge badge-pill badge-success"> '+arr_dt['impo_count']+'  contact added</span> </td> </tr>';


}

function app_str_of_tbl_impo(data){

  console.log(data);

str_app="";

for(const val of data){

  str_app+=init_str_of_impo(val);
}

$("#app_of_impo_data").html(str_app);

}

function init_data_of_impo_req(){


  $.ajax({
                url : "./ajaxfile/import_data.php",
                type: "POST"
        }).done(function(response){

res_en_dt=JSON.parse(response);


app_str_of_tbl_impo(JSON.parse(res_en_dt['arr_of_impo']));


        });
}

$(document).ready(function(){

init_data_of_impo_req();

})









function append_load_in_all_btn(selector){




append_txt_that_get_clck=$(selector).html();

$(selector).prop("disabled",true);

$(selector).html('<div class="cp-spinner cp-round"></div>');

}



function append_txt_of_lds(selector){

$(selector).prop("disabled",false);

$(selector).html(append_txt_that_get_clck);


}


err_msg_data("Welcome To Studio");


function err_msg_data(message){


$("#con-of-err-msg").html(message);

$("#err_msg_dt_trg").css('display','inline-block');



setTimeout(
    function() {


      $("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');
      
    }, 5000);


}


$(document).on('click','#cncl-err-msg',function(){


$("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

})




</script>
