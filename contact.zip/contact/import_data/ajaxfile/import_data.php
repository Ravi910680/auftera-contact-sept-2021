<?php
session_start();
require("../../confige/con_import.php");

$lst_name=$_SESSION['listname'];


$select_impo_data="select * from data_impo where list_name='".$lst_name."'";

$data_arr=$con_impo_conn->query($select_impo_data);

$res_data=array();

$res_data['cnt']=$data_arr->num_rows;

$res_arr_data=array();

if ($data_arr->num_rows > 0) {


 while($row = $data_arr->fetch_assoc()) {

array_push($res_arr_data, $row);

 }
	}


	$res_data['arr_of_impo']=json_encode($res_arr_data);

	print_r(json_encode($res_data));

?>
